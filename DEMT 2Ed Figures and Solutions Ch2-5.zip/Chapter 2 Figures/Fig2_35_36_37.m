%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 2.35,2.36,2.37
% Pd and Pf calculated by simulation using importance sampling
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
%rand('twister',1000)  % set state of random number generator

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numerical Calculation Parameters Setup
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%-------------------------------------------------------------
% mu(s) Parameters
%-------------------------------------------------------------
ds = 0.01;
s = [0:ds:1];
ns = length(s);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% H0 H1 pdfs. Define:
%    dx:        x integration delta
%    x:         x integration values
%    pxiH0:     evaluated as a function of x
%    pxiH1:     evaluated as a function of x
%    N:         number of observations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dx = 0.0002;
x= [dx/2:dx:6];
pxiH0 = wblpdf(x,1,2);
pxiH1 = wblpdf(x,3,3);

figure(1)
plot(x,pxiH0,'-')
hold on
plot(x,pxiH1,'--')
hold off
legend('p(R_{i}|H_0)','p(R_{i}|H_1)')
xlabel('R_{i}')
print -deps Fig2-35.eps
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numerical calculation of mu(s), mudot(s), muddot(s)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nx=length(x);
LR = pxiH1./pxiH0;
ind = find(LR~=0);
mui = zeros(1,ns);
mudoti = zeros(1,ns);
muddoti = zeros(1,ns);

for n=1:ns
    Int1 = sum((LR.^s(n)).*pxiH0)*dx;

    % log(x)*x^s = 0 when x=0
    f2 = zeros(1,nx);
    f2(ind) = log(LR(ind)).*(LR(ind).^s(n));
    Int2 = sum(f2.*pxiH0)*dx;

    % (log(x)^2)*x^s = 0 when x=0
    f3 = zeros(1,nx);
    f3(ind) = (log(LR(ind)).^2).*(LR(ind).^s(n));
    Int3 = sum(f3.*pxiH0)*dx;

    mui(n) = log(Int1);
    mudoti(n) = Int2/Int1;
    muddoti(n) = (Int1*Int3-Int2^2)/(Int1^2);
end

%----------------------------------------------------
% Plotting of mu_i(s), mudot_i(s), muddot_i(s)
%----------------------------------------------------

figure(2)
subplot(3,1,1)
plot(s,mui,'b')
xlabel('s')
title(['\mu_{i}(s)'])
axis([0 1 -0.9 0])

subplot(3,1,2)
plot(s,mudoti,'b')
xlabel('s')
title('\mu_{i}(s)')
text(0.482,8.8,'.')
axis([0 1 -4 6])

subplot(3,1,3)
plot(s,muddoti,'b')
xlabel('s')
title('\mu_{i}(s)')
text(0.478,32,'..')
axis([0 1 0 25])
print -deps Fig2-36.eps

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PFapprox, IFapprox vs. s. 
% Numerical determination of sopt, gamma
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------------------
% mu(s) Parameters
%-------------------------------------------------------------
ds = 0.01;
s = [0 0.2 0.3 0.4 0.5 0.575 0.65 0.7 0.73 0.76 0.78 0.8 0.815 0.83 0.845 0.86 0.87 0.88];
ns = length(s);
mui = zeros(1,ns);
mudoti = zeros(1,ns);
muddoti = zeros(1,ns);

for n=1:ns
    Int1 = sum((LR.^s(n)).*pxiH0)*dx;

    % log(x)*x^s = 0 when x=0
    f2 = zeros(1,nx);
    f2(ind) = log(LR(ind)).*(LR(ind).^s(n));
    Int2 = sum(f2.*pxiH0)*dx;

    % (log(x)^2)*x^s = 0 when x=0
    f3 = zeros(1,nx);
    f3(ind) = (log(LR(ind)).^2).*(LR(ind).^s(n));
    Int3 = sum(f3.*pxiH0)*dx;

    mui(n) = log(Int1);
    mudoti(n) = Int2/Int1;
    muddoti(n) = (Int1*Int3-Int2^2)/(Int1^2);
end

ls = ['-s';'-o';'-x';'-d';'-+';'-*';'.-';'--';'-.';'-b'];

figure(3)
for N=10:-1:1
    mu = N*mui;
    mudot = N*mudoti;
    muddot = N*muddoti;

    PFapprox_s = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));
    PMapprox_s = exp(mu+(1-s).*mudot+0.5*((1-s).^2).*muddot.*normcdf(-(1-s).*sqrt(muddot)));
    PDapprox_s = 1-PMapprox_s;
    semilogx(PFapprox_s,PDapprox_s,ls(N,:))
    hold on
end
hold off
legend('N=10','N=9','N=8','N=7','N=6','N=5','N=4','N=3','N=2','N=1','Location','EastOutside')
xlabel('P_{F}')
ylabel('P_{D}')
axis([1e-10,1 0.5 1])
print -deps Fig2-37.eps