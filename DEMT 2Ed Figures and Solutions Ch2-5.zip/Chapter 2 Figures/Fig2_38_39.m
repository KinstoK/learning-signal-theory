%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 2.38,39
% KLB  5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

x = [-1:0.01:2];

figure(1)
plot(x,exp(x),'--')
hold on
plot([-1 1 1 2],[0 0 exp(1) exp(1)])
set(gca,'XTick',[0],'Ytick',[0])
xlabel('$$l_{*}(X)$$','Interpreter','latex','Fontsize',12)
text(1,-0.2,'$$\gamma_{*}$$','Interpreter','latex','Fontsize',12)
text(1.2,exp(1.05),'$$I(l_{*}(X)\geq\gamma_{*})$$','Interpreter','latex','Fontsize',12)
text(1.55,exp(1.5),'$$e^{s[l_{*}(X)-\gamma_{*}]}$$','Interpreter','latex','Fontsize',12)
hold off
axis([-1 2 0 5])
print -deps Fig2-38.eps

figure(2)
plot(x,exp(-x),'--')
hold on
plot([-1 1 1 2],[exp(-1) exp(-1) 0 0 ])
xlabel('$$l_{*}(X)$$','Interpreter','latex','Fontsize',12)
text(1,-0.1,'$$\gamma_{*}$$','Interpreter','latex','Fontsize',12)
text(0,exp(-0.8),'$$I(l_{*}(X)<\gamma_{*})$$','Interpreter','latex','Fontsize',12)
text(-0.5,exp(0.6),'$$e^{-t[l_{*}(X)-\gamma_{*}]}$$','Interpreter','latex','Fontsize',12)
hold off
set(gca,'XTick',[0],'Ytick',[0])
axis([-1 2 0 3])
print -deps Fig2-39.eps