%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 2.45
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
clear all
close all
% note: need to set states of both rand and randn for betarnd
t=1251;
rand('twister',t)  % set state of uniform random number generator
randn('seed',t)    % set state of normal random number generator
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numerical Parameter Setup
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------------------
% Importance Sampling Confidence Interval Parameters
%-------------------------------------------------------------
alpha = 0.1;                   % percent tolerance for CI
c=2;                            % CI SD 2:95.45%

%-------------------------------------------------------------
% mu(s) Parameters
%-------------------------------------------------------------
ds = 0.01;
s = [0:ds:1];
ns = length(s);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define:
%    mui_a:     analytical expression for mu_i(s). 
%    mudoti_a:  analytical expression for mu_i(s).  
%    muddoti_a: analytical expression for mu_i(s). 
%    N:         number of observations
%    PF:        desired PF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mui_a = log(gamma(s+1))+log(gamma(2-s));
mudoti_a = psi(0,s+1)-psi(0,2-s);
muddoti_a = psi(1,s+1)+psi(1,2-s);
N=20;
PF = 1e-6;
 
mu = N*mui_a;
mudot = N*mudoti_a;
muddot = N*muddoti_a;

V = (alpha*PF/c)^2;    % desired simulation variance
PFapprox_s = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));
PMapprox_s = exp(mu+(1-s).*mudot+0.5*((1-s).^2).*muddot).*normcdf(-(1-s).*sqrt(muddot));

% Find sopt using linear interpolation
sopt(1) = interp1(log(PFapprox_s),s,log(PF));
% Find gammat using linear interpolation
gammat_c(1) = interp1(s,mudot,sopt(1));

mu_sopt_c = interp1(s,mu,sopt(1));
mudot_sopt_c = gammat_c(1);
muddot_sopt_c = interp1(s,muddot,sopt(1));

mu_sopt = N*(log(gamma(sopt(1)+1))+log(gamma(2-sopt(1))));
mudot_sopt = N*(psi(0,sopt(1)+1)-psi(0,2-sopt(1)));
muddot_sopt = N*(psi(1,sopt(1)+1)+psi(1,2-sopt(1)));
gammat(1) = mudot_sopt;

PFapprox = exp(mu_sopt-sopt(1)*mudot_sopt+0.5*(sopt(1)^2)*muddot_sopt)*normcdf(-sopt(1)*sqrt(muddot_sopt));
PMapprox = exp(mu_sopt+(1-sopt(1))*mudot_sopt+0.5*((1-sopt(1))^2)*muddot_sopt)*normcdf(-(1-sopt(1))*sqrt(muddot_sopt));

s = [[0.05:0.1:0.55] [0.6:0.05:0.8] [0.83:0.03:0.98]];
mu = N*(log(gamma(s+1))+log(gamma(2-s)));
mudot = N*(psi(0,s+1)-psi(0,2-s));
muddot = N*(psi(1,s+1)+psi(1,2-s));
gammat = mudot;

PFapprox = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));
PMapprox = exp(mu+(1-s).*mudot+0.5*((1-s).^2).*muddot).*normcdf(-(1-s).*sqrt(muddot));

IFapprox = exp(2*mu-2*s.*mudot+2*(s.^2).*muddot).*normcdf(-2*s.*sqrt(muddot));
IMapprox = exp(2*mu+2*(1-s).*mudot+2*((1-s).^2).*muddot).*normcdf(-2*(1-s).*sqrt(muddot));
KF = ceil(((c/alpha)^2)*(IFapprox-PFapprox.^2)./PFapprox.^2);
KM = ceil(((c/alpha)^2)*(IMapprox-PMapprox.^2)./PMapprox.^2);
Ksim = max([KF;KM]);

for n=1:length(s)

    IF_star =0;
    IM_star =0;
    D_star =0;
    A_star =0;
    K=Ksim(n);
    for k =1:K
        r_star = betarnd(s(n)+1,2-s(n),1,N);
        l_star = sum(log(r_star))-sum(log(1-r_star));
        W0 = exp(mu(n)-s(n)*l_star);
        W1 = exp(mu(n)+(1-s(n))*l_star);
        D_star = D_star+(l_star>=gammat(n))*W0;
        A_star = A_star+(l_star<gammat(n))*W1;
        IF_star = IF_star+(l_star>=gammat(n))*W0^2;
        IM_star = IM_star+(l_star<gammat(n))*W1^2;
    end
    IFhat = IF_star/K;
    IMhat = IM_star/K;
    PFhat(n) = max(0,min(1,D_star/K));
    PMhat(n) = max(0,min(1,A_star/K));


    PFstar_var = (IFhat-PFhat(n)^2)/K;
    PFstar_sd(n) = sqrt(PFstar_var);
    alphahatF = c*PFstar_sd(n)/PFhat(n);
    PMstar_var = (IMhat-PMhat(n)^2)/K;
    PMstar_sd(n) = sqrt(PMstar_var);
    alphahatM = c*PMstar_sd(n)/PMhat(n);
end
%%
figure(1)
semilogx(PFapprox_s,1-PMapprox_s)
xlabel('P_F')
ylabel('P_D')
hold on
semilogx(PFapprox,1-PMapprox,'-')
semilogx(PFhat,1-PMhat,'--+')
hold off
legend('Approx','Sim')

print -deps Fig2-45.eps
