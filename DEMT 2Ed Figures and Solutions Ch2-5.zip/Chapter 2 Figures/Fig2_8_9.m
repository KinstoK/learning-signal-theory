%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 2.8 and 2.9
% Example 2.4
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

%+++++++++++++++++++++++++++++++++++++++++++
% Figure 2.8 pdfs for different alpha
%+++++++++++++++++++++++++++++++++++++++++++
alpha = [1 2 3].';
ls = ['--';'-b';'-.'];
M = length(alpha);
sigma = 1;
b=sigma*sqrt(gamma(1./alpha)./gamma(3./alpha));
c=1./(2*b.*gamma(1+1./alpha));

r=[-4:0.01:4];
pN = zeros(M,length(r));
for j=1:M
    pN(j,:) = c(j)*exp(-abs(r/b(j)).^alpha(j));
end

% Figure 2.8
figure(1)
for j=1:M
    plot(r,pN(j,:),ls(j,:))
    hold on
end
hold off
xlabel('X')
ylabel('p_{n}(X)')
legend(['\alpha=' num2str(alpha(1))],['\alpha=' num2str(alpha(2))],['\alpha=' num2str(alpha(3))])
axis([-4 4 0 0.8])
print -deps Fig2-8.eps

%+++++++++++++++++++++++++++++++++++++++++++
% pdfs for different alpha
%+++++++++++++++++++++++++++++++++++++++++++
m=1;

lR_paren = zeros(M,length(r));
for j=1:M
    lR_paren(j,:) = abs(r+m/2).^alpha(j) - abs(r-m/2).^alpha(j);
    lR_paren(j,:) = lR_paren(j,:)/(b(j)^alpha(j));
end

% Figure 2.9
figure(2)
for j=1:M
plot(r,lR_paren(j,:),ls(j,:))
hold on
end
hold off
xlabel('R_i')
legend(['\alpha=' num2str(alpha(1))],['\alpha=' num2str(alpha(2))],...
    ['\alpha=' num2str(alpha(3))],'location','Northwest')
axis([-2 2 -3 3])
print -deps Fig2-9.eps

