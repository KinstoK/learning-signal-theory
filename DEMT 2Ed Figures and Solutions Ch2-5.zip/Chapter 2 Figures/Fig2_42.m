%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 2.42
% KLB 5/4/14

clear all
close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROC curve
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PFset = [1e-4 1e-6 1e-8 1e-10 1e-12];
nF = length(PFset);

% N, SNR
N=8;
SNR = [10:0.1:20];                % sigmas^2/sigman^2
sigman2 = 1;
sigmas2 = SNR*sigman2;
sigma1 =sqrt(sigmas2+sigman2);
sigma0 =sqrt(sigman2);

PD = zeros(nF,length(SNR));
for n=1:nF
    PF = PFset(n);
    gFN = gaminv(1-PF,N/2,1);
    gFN1 = gFN./(1+SNR);
    PD(n,:) = 1-gammainc(gFN1,N/2);
end
figure(1)
plot(SNR,PD)
xlabel('\sigma_{s}^{2}/\sigma_{n}^{2}')
ylabel('P_D')

SNRsim = [10:1:20];                % sigmas^2/sigman^2
ns = length(SNRsim);
% Confidence interval
alpha = 0.1;                   % percent tolerance for CI
c =2;                          % CI SD 2:95.45%
PFstar_hat = zeros(nF,ns);
PDstar_hat = zeros(nF,ns);

for n1 = 1:nF
    PF = PFset(n1);

    for n=1:ns
        % SNR, sigma
        SNR = SNRsim(n);                % m^2/sigma^2
        sigmas2 = SNR*sigman2;
        sigma1 =sqrt(sigmas2+sigman2);
        sigma0 =sqrt(sigman2);

        gFN = gaminv(1-PF,N/2,1);
        gFN1 = gFN./(1+SNR);
        gammat(n1,n) = gFN*(sigma1^2-sigma0^2)/(sigma1^2) +N*log(sigma0/sigma1);
        gammax(n1,n) = 2*gFN*sigma0^2;
        gammat2(n1,n) = gammax(n1,n)*(sigma1^2-sigma0^2)/(2*(sigma0^2)*(sigma1^2)) +N*log(sigma0/sigma1);

        PD = 1-gammainc(gFN1,N/2);
        PM(n1,n) = 1-PD;

        
        % sopt, mu(s)
        sopt(n1,n) = ((sigma1^2)/(sigma1^2-sigma0^2))*(1-N/(2*gFN));
        sopt2(n1,n) = ((sigma1^2)/(sigma1^2-sigma0^2))*(1-N*(sigma0^2)/gammax(n1,n));
        mu_sopt = (N/2)*log((sigma0^(2*sopt(n1,n)))*(sigma1^(2*(1-sopt(n1,n))))/(sopt(n1,n)*sigma0^2+(1-sopt(n1,n))*sigma1^2));

        % IF(s)
        cc = 1-N/(4*gFN);
        cc1 = 1-N/(4*gFN1);
        
        tmp1 = ((sopt(n1,n)*sigma0^2+(1-sopt(n1,n))*sigma1^2)/sigma1^2)^(-N/2);
        tmp2 = ((-sopt(n1,n)*sigma0^2+(1+sopt(n1,n))*sigma1^2)/sigma1^2)^(-N/2);
        tmp3 = gammax(n1,n)*(-sopt(n1,n)*sigma0^2+(1+sopt(n1,n))*sigma1^2)/(2*(sigma0^2)*(sigma1^2));
        
        IF(n1,n) = (((N/gFN)*cc)^(-N/2))*gammainc(2*gFN*cc,N/2,'upper');
        IF2(n1,n) = tmp1*tmp2*gammainc(tmp3,N/2,'upper');

        %IM(s)
        tmp1 = ((sopt(n1,n)*sigma0^2+(1-sopt(n1,n))*sigma1^2)/sigma0^2)^(-N/2);
        tmp2 = (((2-sopt(n1,n))*sigma0^2+(-1+sopt(n1,n))*sigma1^2)/sigma0^2)^(-N/2);
        tmp3 = gammax(n1,n)*((2-sopt(n1,n))*sigma0^2+(-1+sopt(n1,n))*sigma1^2)/(2*(sigma0^2)*(sigma1^2));
        IM(n1,n) = (((N/gFN1)*cc1)^(-N/2))*real(gammainc(2*gFN1*cc1,N/2));
        IM2(n1,n)=tmp1*tmp2*real(gammainc(tmp3,N/2));

        % Simulation Trials
        KFsim(n1,n) = ceil(((c/alpha)^2)*(IF(n1,n)-PF^2)/PF^2);
        KMsim(n1,n) = ceil(((c/alpha)^2)*(IM(n1,n)-PM(n1,n)^2)/PM(n1,n)^2);
        KF(n1,n) = ceil(((c/alpha)^2)*(PF-PF^2)/PF^2);
        KM(n1,n) = ceil(((c/alpha)^2)*(PM(n1,n)-PM(n1,n)^2)/PM(n1,n)^2);

        Ksim = max(KMsim(n1,n), KFsim(n1,n));

        D_star =0;
        A_star =0;
        for k =1:Ksim
            sigmastar = sigma0*sqrt(2*gFN/N);
            r_star = sigmastar*randn(1,N);
            l_star = (0.5*(sigma0^(-2)-sigma1^(-2)))*sum(r_star.^2)+N*log(sigma0/sigma1);
            W0 = exp(mu_sopt-sopt(n1,n)*l_star);
            W1 = exp(mu_sopt+(1-sopt(n1,n))*l_star);
            D_star = D_star+(l_star>=gammat(n1,n))*W0;
            A_star = A_star+(l_star<gammat(n1,n))*W1;

        end
        PFstar_hat(n1,n) = max(0,min(1,D_star/Ksim));
        PDstar_hat(n1,n) = 1-max(0,min(1,A_star/Ksim));
    end

end
figure(1)
hold on
plot(SNRsim,PDstar_hat,'*')
hold off
axis([10 20 0.5 1])

h=text(10.5,0.97,'P_{F}=10^{-4}');
set(h,'Rotation',8)
h=text(10.5,0.91,'P_{F}=10^{-6}');
set(h,'Rotation',15)
h=text(10.5,0.83,'P_{F}=10^{-8}');
set(h,'Rotation',30)
h=text(10.5,0.74,'P_{F}=10^{-10}');
set(h,'Rotation',35)
h=text(10.5,0.64,'P_{F}=10^{-12}');
set(h,'Rotation',40)

print -deps Fig2-42.eps
