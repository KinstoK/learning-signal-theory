%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 2.27
% Example 2.11
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
ls = ['--';'-b';'-.';'-b'];

alpha = 1;
sigma = [1 2 5 10];
M = length(sigma);
b=sigma*sqrt(gamma(1/alpha)/gamma(3/alpha));
a=1./(2*b.*gamma(1+1/alpha));

lNR=[0:0.01:8];
L = zeros(M,length(lNR));
for j=1:M
    L(j,:) = -log(sigma(j))-lNR/(b(j)^alpha);
end

x = zeros(1,M-1);
y=zeros(1,M-1);
for j=1:M-1
    [z,ind]=min(abs(L(j+1,:)-L(j,:)));
    x(j)=lNR(ind);
    y(j)=L(j,ind);
end

figure(1)
for j=1:M
    h(j)=plot(lNR,L(j,:),ls(j,:));
    hold on
end
lNR2=[0:1:8];
    L2 = -log(sigma(4))-lNR2/(b(4)^alpha);
    h(j+1)=plot(lNR2,L2,'+-');

plot(x,y,'o')
hold off
xlabel('$$\bar{l}_{N}(R)$$','Interpreter','Latex','Fontsize',12)
ylabel('$$l_j$$','Interpreter','Latex','Fontsize',12)
legend([h(1:3) h(5)],['\sigma=' num2str(sigma(1))],['\sigma=' num2str(sigma(2))],['\sigma=' num2str(sigma(3))],['\sigma=' num2str(sigma(4))])
ylim([-5 0])
print -deps Fig2-27.eps
