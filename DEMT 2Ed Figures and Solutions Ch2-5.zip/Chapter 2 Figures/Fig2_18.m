%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 2.18
% Example 2.8
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

N =10;
m=1;
sigma = 0.5;

alpha = [1.1 1.5 2];
b=sigma*sqrt(gamma(1./alpha)./gamma(3./alpha));
a=1./(2*b.*gamma(1+1./alpha));

dr = 0.01;
r=[-7:dr:7];
dL = 0.005;
L = [-15:dL:15];
nL = length(L);
Ltot = [N*L(1):dL:N*L(end)];

pRiH0=zeros(3,length(r));
pRiH1=zeros(3,length(r));
FRiH0=zeros(3,length(r));
FRiH1=zeros(3,length(r));
RL = zeros(3,nL);
pLiH0 = zeros(3,nL);
pLiH1 = zeros(3,nL);
FLiH0 = zeros(3,nL);
FLiH1 = zeros(3,nL);
pLNH0 = zeros(3,length(Ltot));
pLNH1 = zeros(3,length(Ltot));
PD = zeros(3,length(Ltot));
PF = zeros(3,length(Ltot));

for k=1:3

    pRiH0(k,:) = a(k)*exp(-abs((r+m/2)/b(k)).^alpha(k));
    pRiH1(k,:) = a(k)*exp(-abs((r-m/2)/b(k)).^alpha(k));

    FRiH0(k,:) = cumsum(pRiH0(k,:))*dr;
    FRiH1(k,:) = cumsum(pRiH1(k,:))*dr;

    lnr(k,:) = (abs((r+m/2)/b(k)).^alpha(k))-(abs((r-m/2)/b(k)).^alpha(k));

    % Inverse transformation R(L)
    for ii=1:nL
        if L(ii)< lnr(k,1)
            RL(k,ii) = r(1)+(L(ii)-lnr(k,1))*dr/(lnr(k,2)-lnr(k,1)); % slope of first two points
        elseif L(ii)>=lnr(k,end)
            RL(k,ii) = r(end)+(L(ii)-lnr(k,end))*dr/(lnr(k,end)-lnr(k,end-1));   % slope of last two points
        else
            ind = max(find(L(ii)>=lnr(k,:)));  % index of lnr<L(ii)
            RL(k,ii) = r(ind)+(L(ii)-lnr(k,ind))*dr/(lnr(k,ind+1)-lnr(k,ind));
        end
    end

    % CDF FLH0,FLH1
    for ii=1:nL
        if RL(k,ii)<r(1)
            FLiH0(k,ii) = max(0,FRiH0(k,1)+(RL(k,ii)-r(1))*(FRiH0(k,2)-FRiH0(k,1))/dr);
            FLiH1(k,ii) = max(0,FRiH1(k,1)+(RL(k,ii)-r(1))*(FRiH1(k,2)-FRiH1(k,1))/dr);
        elseif RL(k,ii)>=r(end)
            FLiH0(k,ii) = min(1,FRiH0(k,end)+(RL(k,ii)-r(end))*(FRiH0(k,end)-FRiH0(k,end-1))/dr);
            FLiH1(k,ii) = min(1,FRiH1(k,end)+(RL(k,ii)-r(end))*(FRiH1(k,end)-FRiH1(k,end-1))/dr);
        else
            ind = max(find(RL(k,ii)>=r));  % index of r<RL(ii)
            FLiH0(k,ii) = FRiH0(k,ind)+(RL(k,ii)-r(ind))*(FRiH0(k,ind+1)-FRiH0(k,ind))/dr;
            FLiH1(k,ii) = FRiH1(k,ind)+(RL(k,ii)-r(ind))*(FRiH1(k,ind+1)-FRiH1(k,ind))/dr;
        end
    end
    % pdfs
    pLiH0(k,:) = [0 diff(FLiH0(k,:))];
    pLiH1(k,:) = [0 diff(FLiH1(k,:))];

    % convolve to get pdfs of total likelihood
    tmp0=pLiH0(k,:);
    tmp1=pLiH1(k,:);
    for n=2:N
        tmp0 = conv(tmp0,pLiH0(k,:));
        tmp1=conv(tmp1,pLiH1(k,:));
    end
    pLNH0(k,:) = tmp0;
    pLNH1(k,:) = tmp1;
    
    % PF and PD
    PF(k,:) = 1-cumsum(pLNH0(k,:));
    PD(k,:) = 1-cumsum(pLNH1(k,:));

end


figure(1)
semilogx(PF(1,:),PD(1,:),'-.',PF(2,:),PD(2,:),'--',PF(3,:),PD(3,:),'-')
xlabel('P_F')
ylabel('P_D')
axis([1e-8 1e-2 0.7 1])
legend(['\alpha=' num2str(alpha(1))],['\alpha=' num2str(alpha(2))],['\alpha=' num2str(alpha(3))])
print -deps Fig2-18.eps
