%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 2.14
% Gamma pdf
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 1.0;
FS = 10;
ls = ['-k';'--';'-k';'-.'];

runsim = 1;      % 1 to run simulation, 0 to use saved data

S0 = 2;               % Inv Gamma density parameter beta0=S0; 
N0 = 10;               % Inv Gamma density paramemer alpha0=aN0-1

k = [1 2 3 5];                    % Gamma parameter k
theta = [2 2 2 1];              % Gamma parameter theta
nk = length(k);                    

A = [0:0.01:20];
pdf = zeros(nk,length(A));
for n=1:nk
    c=1/((theta(n)^k(n))*gamma(k(n)));
    pdf(n,:) = c*(A.^(k(n)-1)).*exp(-A/theta(n));
    h(n)=plot(A,pdf(n,:),ls(n,:),'linewidth',lw);
    hold on
end
AA=[0:1:20];
    c=1/((theta(1)^k(1))*gamma(k(1)));
pA =  c*(AA.^(k(1)-1)).*exp(-AA/theta(1));
h(n+1)=plot(AA,pA,'+','linewidth',lw);
h(n+2)=plot(AA(end-1:end),pA(end-1:end),'+-','linewidth',lw);

hold off
set(gca,'Fontsize',FS)
xlabel('$$L$$','Interpreter','Latex','Fontsize',12)
ylabel('$$p_{l}(L)$$','Interpreter','Latex','Fontsize',12)
legend([h(n+2) h(2:n)],['a=' num2str(k(1)) ', b=' num2str(theta(1))],...
['a=' num2str(k(2)) ', b=' num2str(theta(2))],...
['a=' num2str(k(3)) ', b=' num2str(theta(3))],...
['a=' num2str(k(4)) ', b=' num2str(theta(4))])


print -deps Fig2-14.eps




