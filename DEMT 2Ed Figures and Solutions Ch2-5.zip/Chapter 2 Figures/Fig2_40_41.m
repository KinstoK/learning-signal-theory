%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 2.40 and 2.41
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all 
close all
t=2346;
randn('seed',t)    % set state of normal random number generator
% N, SNR
N=40;
m=1;
SNR = 1;                % m^2/sigma^2
sigma =sqrt((m^2)/SNR);
d=sqrt(N*SNR);

% PF,PM,PD
PF = 1e-6;
zF = norminv(1-PF,0,1);
if zF>d
    disp('Threshold exceeds H1 mean')
    pause
elseif zF<0
    disp('Threshold below H0 mean')
    pause
end
gamma = (zF-d/2)*d;
PM = normcdf(gamma/d-d/2);
PD = 1-PM;

% Confidence interval
alpha = 0.1;                   % percent tolerance for CI
c =2;                          % CI SD 2:95.45%

% IF(s)
IF = normcdf(-2*zF)*exp(zF^2);

%IM(s)
IM = normcdf(2*(zF-d))*exp((zF-d)^2);

% sopt, mu(s)
sopt = zF/d;
mu_sopt = -sopt*(1-sopt)*(d^2)/2;


% simulation according to smallest probability
if PF<PM
    P =PF;
    I = IF;
else
    P = PM;
    I = IM;
end

% Simulation Trials
KF = ceil(((c/alpha)^2)*(1-PF)/PF);
KFsim = ceil(((c/alpha)^2)*(IF-PF^2)/PF^2);
KM = ceil(((c/alpha)^2)*(1-PM)/PM);
KMsim = ceil(((c/alpha)^2)*(IM-PM^2)/PM^2);

K = ceil(((c/alpha)^2)*(1-P)/P);
Ksim = ceil(((c/alpha)^2)*(I-P^2)/P^2);

PF_sd = sqrt(PF*(1-PF)/K);
PFstar_sd = sqrt((IF-PF^2)/Ksim);
PM_sd = sqrt(PM*(1-PM)/K);
PMstar_sd = sqrt((IM-PM^2)/Ksim);
CI_PF = PF+c*[-PF_sd PF_sd];
CI_PFstar = PF+c*[-PFstar_sd PFstar_sd];
CI_PM = PM+c*[-PM_sd PM_sd];
CI_PMstar = PM+c*[-PMstar_sd PMstar_sd];
CI_PDstar = PD+c*[-PMstar_sd PMstar_sd];

L = 1000;                      % Monte Carlo Trials Distribution of Sim Results

PFstar_hat = zeros(1,L);
PMstar_hat = zeros(1,L);
PDstar_hat = zeros(1,L);

for ll=1:L
   % ll
    D_star =0;
    A_star =0;
    for k =1:Ksim
        r_star = sigma*randn(1,N)+m*sopt;
        l_star = (sum(r_star)/(sigma*sqrt(N)))*d-(d^2)/2;
        W0 = exp(mu_sopt-sopt*l_star);
        W1 = exp(mu_sopt+(1-sopt)*l_star);
        D_star = D_star+(l_star>=gamma)*W0;
        A_star = A_star+(l_star<gamma)*W1;
    end
    PFstar_hat(ll) = D_star/Ksim;
    PMstar_hat(ll) = A_star/Ksim;
    PDstar_hat(ll) = 1-PMstar_hat(ll);
end


%mean(PFstar_hat)
%mean(PDstar_hat)
CI_PFstar
%CI_PMstar
CI_PDstar
[HistFs,bFs] = hist(PFstar_hat,([0:0.025:11*0.025]+0.85+0.025/2)*PF);
[HistMs,bMs] = hist(PMstar_hat);
[HistDs,bDs] = hist(PDstar_hat,([0:0.001:11*0.001]+0.936+0.001/2));

figure(1)
subplot(2,1,1)
bar(bFs,HistFs)
xlabel('Simulated P_{F}')
title(['P_{F}=' num2str(PF) ', K=',int2str(Ksim)])
xlim([0.85 1.15]*PF)
subplot(2,1,2)
bar(bDs,HistDs)
xlabel('Simulated P_{D}')
title(['P_{D}=' num2str(1-PM) ', K=',int2str(Ksim)])
xlim([0.936 0.948])
print -deps Fig2-40.eps

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROC curve
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dset = [3:0.5:9];
% N, m
N=40;
m=1;

% PF
PF = [1e-4 1e-6 1e-8 1e-10 1e-12];
nF = length(PF);

% Confidence interval
alpha = 0.1;                   % percent tolerance for CI
c =2;                          % CI SD 2:95.45%

for n1 = 1:nF
    zF = norminv(1-PF(n1),0,1);

    d = dset(find((dset>zF)&(dset<zF+norminv(0.9999))));     % zF<d
    nd = length(d);

    PFstar_hat = zeros(1,nd);
    PDstar_hat = zeros(1,nd);

    for n=1:nd
        % SNR, sigma
        SNR = (d(n)^2)/N;                % m^2/sigma^2
        sigma =sqrt((m^2)/SNR);

        gamma = (zF-d(n)/2)*d(n);
        PM = normcdf(gamma/d(n)-d(n)/2);
        PD = 1-PM;

        % IF(s)
        IF = normcdf(-2*zF)*exp(zF^2);

        %IM(s)
        IM = normcdf(2*(zF-d(n)))*exp((zF-d(n))^2);

        % sopt, mu(s)
        sopt = zF/d(n);
        mu_sopt = -sopt*(1-sopt)*(d(n)^2)/2;

        % Simulation Trials
        KFsim = ceil(((c/alpha)^2)*(IF-PF(n1)^2)/PF(n1)^2);
        KMsim = ceil(((c/alpha)^2)*(IM-PM^2)/PM^2);

        Ksim = max(KMsim, KFsim);

        D_star =0;
        A_star =0;
        for k =1:Ksim
            r_star = sigma*randn(1,N)+m*sopt;
            l_star = (sum(r_star)/(sigma*sqrt(N)))*d(n)-(d(n)^2)/2;
            W0 = exp(mu_sopt-sopt*l_star);
            W1 = exp(mu_sopt+(1-sopt)*l_star);
            D_star = D_star+(l_star>=gamma)*W0;
            A_star = A_star+(l_star<gamma)*W1;
        end
        PFstar_hat(n1,n) = D_star/Ksim;
        PDstar_hat(n1,n) = 1-A_star/Ksim;
    end
    
    % Analytical values
    dd = [3:0.01:9];
    PD = 1-normcdf(zF-dd);

    figure(2)
    plot(dd,dd-zF)
    hold on
    plot(d,norminv(PDstar_hat),'*')
    xlabel('d')
    ylabel('P_D')
    ylim(norminv([0.5 0.9999]))
    set(gca,'Ytick',norminv([0.5 0.7 0.9 0.98 0.99 0.999 0.9999]))
    set(gca,'YtickLabel',['   0.5';'   0.7';'   0.9';'  0.98';'  0.99';' 0.999';'0.9999'])
end
xlim([3.5 9])

hold off
h=text(4.95,1.5,'P_{F}=10^{-4}');
set(h,'Rotation',45)
h=text(6,1.5,'P_{F}=10^{-6}');
set(h,'Rotation',45)
h=text(6.8,1.5,'P_{F}=10^{-8}');
set(h,'Rotation',45)
h=text(7.6,1.5,'P_{F}=10^{-10}');
set(h,'Rotation',45)
h=text(8.25,1.5,'P_{F}=10^{-12}');
set(h,'Rotation',45)
print -deps Fig2-41.eps
