%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 2.43, 2.44, 2.46
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
% note: need to set states of both rand and randn for betarnd
t=7550;
rand('twister',t)  % set state of uniform random number generator
randn('seed',t)    % set state of normal random number generator
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numerical Parameter Setup
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------------------
% Importance Sampling Confidence Interval Parameters
%-------------------------------------------------------------
alpha = 0.1;                   % percent tolerance for CI
c = 2;                          % CI SD 2:95.45%
alphatol = 0.05*alpha;         % convergence criterion

%-------------------------------------------------------------
% mu(s) Parameters
%-------------------------------------------------------------
ds = 0.01;
s = [0:ds:1];
ns = length(s);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% H0 H1 pdfs. Define:
%    dx:        x integration delta
%    x:         x integration values
%    pxiH0:     evaluated as a function of x
%    pxiH1:     evaluated as a function of x
%    mui_a:     analytical expression for mu_i(s).
%    mudoti_a:  analytical expression for mu_i(s).
%    muddoti_a: analytical expression for mu_i(s).
%    N:         number of observations
%    PF:        desired PF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dx = 0.0001;
x= [dx/2:dx:1-dx/2];
pxiH0 = betapdf(x,1,2);
pxiH1 = betapdf(x,2,1);
mui_a = log(gamma(s+1))+log(gamma(2-s));
mudoti_a = psi(0,s+1)-psi(0,2-s);
muddoti_a = psi(1,s+1)+psi(1,2-s);
N=20;
PF = 1e-8;

figure(1)
subplot(1,2,1)
plot(x,pxiH0)
xlabel('R')
ylabel('p(R_{i}|H_{0})')
subplot(1,2,2)
plot(x,pxiH1)
xlabel('R')
ylabel('p(R_{i}|H_{1})')
print -deps Fig2-43.eps

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% numerical calculation of mu(s), mudot(s), muddot(s)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mu = N*mui_a;
mudot = N*mudoti_a;
muddot = N*muddoti_a;

V = (alpha*PF/c)^2;    % desired simulation variance
PFapprox_s = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));

% Find sopt using linear interpolation
sopt = interp1(log(PFapprox_s),s,log(PF));

mu_sopt = N*(log(gamma(sopt(1)+1))+log(gamma(2-sopt(1))));
mudot_sopt = N*(psi(0,sopt(1)+1)-psi(0,2-sopt(1)));
muddot_sopt = N*(psi(1,sopt(1)+1)+psi(1,2-sopt(1)));
gammat = mudot_sopt;

PFapprox = exp(mu_sopt-sopt(1)*mudot_sopt+0.5*(sopt(1)^2)*muddot_sopt)*normcdf(-sopt(1)*sqrt(muddot_sopt));
PMapprox = exp(mu_sopt+(1-sopt(1))*mudot_sopt+0.5*((1-sopt(1))^2)*muddot_sopt)*normcdf(-(1-sopt(1))*sqrt(muddot_sopt));

%%
sp=0.7;
ptilt = betapdf(x,sp+1,2-sp);
figure(2)
plot(x,ptilt)
xlabel('R')
print -deps Fig2-44.eps
%%

IFapprox = exp(2*mu_sopt-2*sopt(1)*mudot_sopt+2*(sopt(1)^2)*muddot_sopt)*normcdf(-2*sopt(1)*sqrt(muddot_sopt));
Ksim = ceil(((c/alpha)^2)*(IFapprox-PF^2)/PF^2);

PF_converged = 0;
K_converged=0;
iter=0;
clear PFhat PFstar_sd PFA

while ~PF_converged
    iter=iter+1;
    D_star =0;
    A_star =0;
    
    for k =1:Ksim
        r_star = betarnd(sopt(iter)+1,2-sopt(iter),1,N);
        l_star = sum(log(r_star))-sum(log(1-r_star));
        W0 = exp(mu_sopt-sopt(iter)*l_star);
        W1 = exp(mu_sopt+(1-sopt(iter))*l_star);
        D_star = D_star+(l_star>=gammat(iter))*W0;
        A_star = A_star+(l_star<gammat(iter))*W1;
    end
    PFhat(iter) = max(0,min(1,D_star/Ksim));
    PMhat = max(0,min(1,A_star/Ksim));
    PFA(iter) = exp(mu_sopt-sopt(iter)*mudot_sopt+0.5*(sopt(iter)^2)*muddot_sopt)*normcdf(-sopt(iter)*sqrt(muddot_sopt));
    
    if abs(PFhat(iter)-PF)<=alpha*PF
        PF_converged=1;
    else
        sopt(iter+1) = max(0,min(1,sopt(iter)+(log(PFhat(iter))-log(PF))/(sopt(iter)*muddot_sopt)));
        mu_sopt = N*(log(gamma(sopt(iter+1)+1))+log(gamma(2-sopt(iter+1))));
        mudot_sopt = N*(psi(0,sopt(iter+1)+1)-psi(0,2-sopt(iter+1)));
        muddot_sopt = N*(psi(1,sopt(iter+1)+1)+psi(1,2-sopt(iter+1)));
        gammat(iter+1) = mudot_sopt;
    end    
end
%%
figure(3)
h1=semilogy(s,PFapprox_s,'-');
hold on
a=axis;
plot([0 1],(1+alpha)*PF*[1 1],':k')
plot([0 1],(1-alpha)*PF*[1 1],':k')
xlabel('s')
ylabel('P_F(s)')
h2=plot(sopt,PFhat,'--*');
axis([0.89 0.91 7e-9 1.5e-8])
legend([h1 h2],'P_F(s)','P_{F} sim')
for n=1:iter
    h=text(sopt(n),PFhat(n)*1.03,int2str(n),'HorizontalAlignment','center');
end
text(0.907,(1-alpha)*PF,'(1-\alpha)P_{F}','VerticalAlignment','top');
text(0.907,(1+alpha)*PF,'(1+\alpha)P_{F}','VerticalAlignment','bottom');
plot(sopt(end),PFhat(end),'*r')
hold off
set(gca,'YTick',[0.7:0.1:1.5]*1e-8)
set(gca,'YTickLabel',['0.7e-8';'0.8e-8';'0.9e-8';'1.0e-8';'1.1e-8';'1.2e-8';'1.3e-8';'1.4e-8';'1.5e-8'])
print -deps Fig2-46.eps

