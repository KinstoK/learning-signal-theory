%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.37
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all 
close all

lw=1.5;
% N, SNR
N=10;
SNR = 1;                % zeta
v=[1 0.75 0];                     
sigman2 = 1;


%%
% Confidence interval
alpha_CI = 0.05;                   % percent tolerance for CI
c_CI = 2;                          % CI SD 2:95.45%

pmin = 0.1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROC curve
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% PF
s_sim = [0:0.05:1];
ns = length(s_sim);

nv=length(v);
PFstar_hat = zeros(ns,nv);
PDstar_hat = zeros(ns,nv);
IFstar_hat = zeros(ns,nv);
IMstar_hat = zeros(ns,nv);
alphaF = zeros(ns,nv);
alphaM = zeros(ns,nv);
PD = zeros(ns,nv);
PF = zeros(ns,nv);
PFapprox = zeros(ns,nv);
PMapprox = zeros(ns,nv);

for n=1:nv
    alpha = v(n)*SNR;
    as = sqrt(alpha*sigman2)*exp(j*0);
    beta = (1-v(n))*SNR;
    c_beta = 1+N*beta;
    
    for n1 = 1:ns
        sopt=s_sim(n1);
        c_sopt = 1+(1-sopt)*N*beta;
        
        if v(n)==1
            % find gt from PF
            d=sqrt(2*N*SNR);
            gt = (2*sopt-1)*(d^2)/2;
            PF(n1,n)=normcdf(-(gt/d+d/2));
            
            % Find PD/PM from gt
            PD(n1,n) = normcdf(-(gt/d-d/2));
            
            % IF(sopt), IM(sopt)
            IF = normcdf(-2*sopt*d)*exp((sopt*d)^2);
            IM = normcdf(2*(sopt-1)*d)*exp(((1-sopt)*d)^2);
            
            
        elseif v(n)==0
            gs = N*beta/c_sopt;            
            gt = gs-log(c_beta);
            PF(n1,n)=exp(-gs*c_beta/(N*beta));           
            PD(n1,n)=exp(-gs/(N*beta));
            tmp1=c_beta/c_sopt;
            tmp2=c_beta/(1+(1+sopt)*N*beta);
            tmp3=1/(1+(sopt-1)*N*beta);
            IF=tmp1*tmp2*exp(-gs*c_beta/(N*beta*tmp2));
            IM=(1/c_sopt)*tmp3*(1-exp(-gs/(N*beta*tmp3)));
            
        end
        
        mu_sopt = -N*alpha*sopt*(1-sopt)/c_sopt+(1-sopt)*log(c_beta)-log(c_sopt);
        mudot_sopt_gt = gt;
        mudot_sopt = (N*alpha/c_sopt^2)*(sopt-(1-sopt)*c_sopt) -log(c_beta)+(N*beta/c_sopt);
        gt=mudot_sopt;
        muddot_sopt = 2*N*alpha*c_beta/c_sopt^3+(N*beta/c_sopt)^2;
        
        PFapprox(n1,n) = exp(mu_sopt-sopt*mudot_sopt+0.5*(sopt^2)*muddot_sopt).*normcdf(-sopt*sqrt(muddot_sopt));
        IFapprox = exp(2*mu_sopt-2*sopt*mudot_sopt+2*(sopt^2)*muddot_sopt)*normcdf(-2*sopt*sqrt(muddot_sopt));
        PMapprox(n1,n) = exp(mu_sopt+(1-sopt)*mudot_sopt+0.5*((1-sopt)^2)*muddot_sopt)*normcdf(-(1-sopt)*sqrt(muddot_sopt));
        IMapprox = exp(2*mu_sopt+2*(1-sopt)*mudot_sopt+2*((1-sopt)^2)*muddot_sopt)*normcdf(-2*(1-sopt)*sqrt(muddot_sopt));
        
        PFm = min(pmin,PFapprox(n1,n));
        PMm = min(pmin,PMapprox(n1,n));
        
        KFapprox = ceil(((c_CI/alpha_CI)^2)*(IFapprox-PFapprox(n1,n)^2)/PFm^2);
        KMapprox = ceil(((c_CI/alpha_CI)^2)*(IMapprox-PMapprox(n1,n)^2)/PMm^2);
        Ksim = max(KFapprox,KMapprox);
        t_sopt = sopt/c_sopt;
        mx = as*t_sopt*sqrt(N);
        sigmax2=sigman2*(1+N*beta*t_sopt);

        D_star =0;
        A_star =0;
        D2_star =0;
        A2_star =0;
        for k =1:Ksim
            x_star = sqrt(sigmax2/2)*(randn+j*randn)+mx;
            lS = (abs(x_star)^2)*N*beta/(sigman2*c_beta);
            lD = 2*real(x_star*conj(as)*sqrt(N)/(sigman2*c_beta));
            l_star = lD+lS-log(c_beta)-N*alpha/c_beta;
            W0 = exp(mu_sopt-sopt*l_star);
            W1 = exp(mu_sopt+(1-sopt)*l_star);
            D_star = D_star+(l_star>=gt)*W0;
            A_star = A_star+(l_star<gt)*W1;
            D2_star = D2_star+(l_star>=gt)*W0^2;
            A2_star = A2_star+(l_star<gt)*W1^2;
        end
        PFstar_hat(n1,n) = D_star/Ksim;
        PDstar_hat(n1,n) = 1-A_star/Ksim;
        IFstar_hat(n1,n) = D2_star/Ksim;
        IMstar_hat(n1,n) = A2_star/Ksim;
        alphaF(n1,n)=c_CI*sqrt((IFstar_hat(n1,n)-PFstar_hat(n1,n)^2)/Ksim)/PFstar_hat(n1,n);
        alphaF2(n1,n)=c_CI*sqrt((IFstar_hat(n1,n)-PFstar_hat(n1,n)^2)/Ksim)/min(pmin,PFstar_hat(n1,n));
        alphaM(n1,n)=c_CI*sqrt((IMstar_hat(n1,n)-(1-PDstar_hat(n1,n))^2)/Ksim)/min(pmin,(1-PDstar_hat(n1,n)));
    end
    
end
%%
figure(1)
n=2;
semilogx(PF,PD,'-.','linewidth',lw)
hold on
semilogx(PFapprox,1-PMapprox,'--','linewidth',lw)
semilogx(PFstar_hat(:,1),PDstar_hat(:,1),'-*','linewidth',lw)
semilogx(PFstar_hat(:,2),PDstar_hat(:,2),'-*g','linewidth',lw)
semilogx(PFstar_hat(:,3),PDstar_hat(:,3),'-*r','linewidth',lw)
xlabel('P_{F}')
ylabel('P_{D}')
axis([1e-6 1 0.5 1])
title(['N*SNR=' num2str(N*SNR)])
legend(['\nu=' num2str(1) ' exact'],['\nu=' num2str(0) ' exact'],...
    ['\nu=' num2str(1) ' approx'],['\nu=' num2str(0) ' approx'],['\nu=' num2str(1) ' sim'],...
    'location','northwest')

h2=errorbar(PFstar_hat(:,1),PDstar_hat(:,1),alphaM(:,1).*(min(pmin,1-PDstar_hat(:,1))),'k');
h2=errorbar(PFstar_hat(:,2),PDstar_hat(:,2),alphaM(:,2).*(min(pmin,1-PDstar_hat(:,2))),'k');
h2=errorbar(PFstar_hat(:,3),PDstar_hat(:,3),alphaM(:,3).*(min(pmin,1-PDstar_hat(:,3))),'k');
hold off

figure(2)
n=2;
semilogy(PD,PF,'-.','linewidth',lw)
hold on
semilogy(PDstar_hat(:,1),PFstar_hat(:,1),'-*','linewidth',lw)
semilogx(PDstar_hat(:,2),PFstar_hat(:,2),'-*g','linewidth',lw)
semilogx(PDstar_hat(:,3),PFstar_hat(:,3),'-*r','linewidth',lw)
xlabel('P_{D}')
ylabel('P_{F}')
axis([0.5 1 1e-6 1 ])
title(['N*SNR=' num2str(N*SNR)])
legend(['\nu=' num2str(1) ' approx,exact'],['\nu=' num2str(0) ' exact'],['\nu=' num2str(1) ' sim'],...
    'location','northwest')

h2=errorbar(PDstar_hat(:,1),PFstar_hat(:,1),alphaF2(:,1).*(min(pmin,PFstar_hat(:,1))),'k');
h2=errorbar(PDstar_hat(:,2),PFstar_hat(:,2),alphaF2(:,2).*(min(pmin,PFstar_hat(:,2))),'k');
h2=errorbar(PDstar_hat(:,3),PFstar_hat(:,3),alphaF2(:,3).*(min(pmin,PFstar_hat(:,3))),'k');
hold off
set(gca,'Ydir','reverse')

%%
figure(3)
n=2;
h1a=semilogx(PFapprox(:,1),1-PMapprox(:,1),'-');
hold on
h2a=semilogx(PFapprox(:,2),1-PMapprox(:,2),'--');
h0a=semilogx(PFapprox(:,3),1-PMapprox(:,3),'--');
h0e=semilogx(PF(:,3),PD(:,3),'-');
h1s=semilogy(PFstar_hat(:,1),PDstar_hat(:,1),':o');
h2s=semilogx(PFstar_hat(:,2),PDstar_hat(:,2),':o');
h0s=semilogx(PFstar_hat(:,3),PDstar_hat(:,3),':o');
xlabel('P_{F}')
ylabel('P_{D}')
axis([1e-6 1 0.5 1])
title(['N*SNR=' num2str(N*SNR) ' dB'])
legend([h0e h0a h2s],'exact','approx','sim','location','northwest')
text(2e-3,0.96,'\nu=1','horizontalalignment','right')
text(6e-3,0.84,'\nu=0.75','horizontalalignment','right')
text(2e-2,0.72,'\nu=0','horizontalalignment','right')
hold off
print -deps Fig3-37.eps
