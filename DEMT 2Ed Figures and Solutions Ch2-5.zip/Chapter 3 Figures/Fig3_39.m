%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.39
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
lw=0.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.39
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% N, rho
N=10;
eta = 1;

SNR = 10.^([0:1:25]/10);             % E/sigma_0^2
ns = length(SNR);
beta = [2 5 10];
nb = length(beta);

PF = zeros(nb,ns);
PM = zeros(nb,ns);
Pe = zeros(nb,ns);
for n=1:nb
    gammat = 0.5*(N*log(beta(n))+4*SNR/(beta(n)-1));
    gamma0 = 2*(beta(n)/(beta(n)-1))*gammat;
    gamma1 =(2/(beta(n)-1))*gammat;

    lambda0 = 4*SNR/((beta(n)-1)^2);
    lambda1 = 4*beta(n)*SNR/((beta(n)-1)^2);

    for m=1:ns
        PF(n,m) = 1-ncx2cdf(gamma0(m),N,lambda0(m));
        PM(n,m) = ncx2cdf(gamma1(m),N,lambda1(m));
        Pe(n,m) = 0.5*(PF(n,m)+PM(n,m));
    end
end

d = 2*sqrt(SNR);
Pe0 = 1-normcdf(0.5*d,0,1);

SNRp = 10.^([0:2:20]/10);             % E/sigma_0^2

dp = 2*sqrt(SNRp);
Pe0p = 1-normcdf(0.5*dp,0,1);

figure
h(1)=loglog(SNR,Pe0,'-','linewidth',lw);
hold on
h(2)=loglog(SNR,Pe(1,:),'-','linewidth',lw);
h(3)=loglog(SNR,Pe(2,:),'-.','linewidth',lw);
h(4)=loglog(SNR,Pe(3,:),'--','linewidth',lw);
loglog(SNRp,Pe0p,'+','linewidth',lw);
h(1)=loglog(SNRp(1),Pe0p(1),'+-','linewidth',lw);

hold off
xlabel('E/\sigma_{0}^{2}','Fontsize',14)
ylabel('Pr(\epsilon)','Fontsize',14)
set(gca,'Fontsize',14)
axis([2 200 1e-10 1])
legend(h,'\beta=1',['\beta=' num2str(beta(1))],['\beta=' num2str(beta(2))],['\beta=' num2str(beta(3))])
title(['N=' int2str(N)])

print -deps Fig3-39.eps