%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 3.21, 3.22
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
lw=0.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.21
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N=5;
SNR=1;                     % |b|^2/sigma_w^2
INR = [0.01 0.2 100];
nI = length(INR);
Deltaw=[-1:0.01:1]*pi;
nw = length(Deltaw);
dsq = zeros(nI,nw);
for m=1:nI
    dsq(m,:) = 2*N*SNR*(1-((sinc(Deltaw*N/(2*pi))./sinc(Deltaw/(2*pi))).^2)*(N*INR(m)/(1+N*INR(m))));
end

figure(1)
h1=plot(Deltaw/pi,dsq(1,:),'--','linewidth',lw);
hold on
plot(Deltaw/pi,dsq(2,:),'-.','linewidth',lw);
plot(Deltaw/pi,dsq(3,:),'-','linewidth',lw);
hold off
xlabel('{\Delta}\omega/\pi')
ylabel('d^2')
title(['N=' int2str(N) ])
legend(['\sigma_{I}^{2}/\sigma_{w}^{2}=' num2str(INR(1))],['\sigma_{I}^{2}/\sigma_{w}^{2}=' num2str(INR(2))],...
       ['\sigma_{I}^{2}/\sigma_{w}^{2}=' num2str(INR(3))],'location','southeast')
ylim([0 11])
print -deps Fig3-21.eps

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.22
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SNR=1;                     % |b|^2/sigma_w^2
INR = 0.2;
N=[10 5 2];
nN = length(N);
Deltaw=[-1:0.01:1]*pi;
nw = length(Deltaw);
dsq = zeros(nN,nw);
for m=1:nN
    dsq(m,:) = 2*N(m)*SNR*(1-((sinc(Deltaw*N(m)/(2*pi))./sinc(Deltaw/(2*pi))).^2)*(N(m)*INR/(1+N(m)*INR)));
end

figure(2)
h1=plot(Deltaw/pi,dsq(1,:),'--','linewidth',lw);
hold on
plot(Deltaw/pi,dsq(2,:),'-.','linewidth',lw);
plot(Deltaw/pi,dsq(3,:),'-','linewidth',lw);
hold off
xlabel('{\Delta}\omega/\pi')
ylabel('d^2')
title(['\sigma_{I}^{2}/\sigma_{w}^{2}=' num2str(INR) ])
legend(['N=' int2str(N(1))],['N=' int2str(N(2))],...
       ['N=' int2str(N(3))],'location','southeast')
ylim([0 21])
print -deps Fig3-22.eps

