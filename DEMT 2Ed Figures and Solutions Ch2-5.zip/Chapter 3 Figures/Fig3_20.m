%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.20
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

N=10;
Delta_omega = [-1:0.01:1]*pi;

Bc = (1/N)*sin(N*Delta_omega/2)./sin(Delta_omega/2);
Bc(find(Delta_omega==0))=1;

figure(1)
plot(Delta_omega/pi,Bc,'linewidth',lw)
xlabel('\Delta\omega/\pi','Fontsize',FS)
ylabel('B_{c}(\Delta\omega)','Fontsize',FS)
title(['N=' int2str(N)])
grid on
set(gca,'Xtick',[-1:0.2:1])
set(gca,'Fontsize',FS)
print -deps Fig3-20.eps

