%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 3.14, 3.165, 3.16, 3.18
% KLB 5/4/14
% updated 3/26/10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
lw=0.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.14
% normalized eigenvalues vs |rho| for fixed N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% N, rho
N=4;
rho=[0:0.01:1];
nr = length(rho);
lambda = zeros(N,nr);

for n=1:nr
    K = toeplitz(rho(n).^[0:1:N-1]);
    [u,lam]=eig(K);                             % eigendecomposition
    [lam,ind]=sort(diag(lam),'descend');        % sort eigenvalues in descending order
    u = u(:,ind);                               % re-order eigenvectors to correspond to eigenvalues
    lambda(:,n)=lam;
end
figure(1)
h(1)=plot(abs(rho),lambda(1,:),'--','linewidth',lw);
hold on
plot(abs(rho),lambda(2,:),'-','linewidth',lw);
h(3)=plot(abs(rho),lambda(3,:),'-.','linewidth',lw);
h(4)=plot(abs(rho),lambda(4,:),'-','linewidth',lw);

rho=[0:0.1:1];
nr = length(rho);
lambda = zeros(N,nr);

for n=1:nr
    K = toeplitz(rho(n).^[0:1:N-1]);
    [u,lam]=eig(K);                             % eigendecomposition
    [lam,ind]=sort(diag(lam),'descend');        % sort eigenvalues in descending order
    u = u(:,ind);                               % re-order eigenvectors to correspond to eigenvalues
    lambda(:,n)=lam;
end
plot(abs(rho),lambda(2,:),'+','linewidth',lw)
h(2)=plot(abs(rho(end)),lambda(2,end),'-+','linewidth',lw);
hold off
xlabel('|\rho|')
ylabel('\lambda_{i}')
title(['N=' int2str(N)])
legend(h,'\lambda_{1}','\lambda_{2}','\lambda_{3}','\lambda_{4}','location','northwest')
print -deps Fig3-14.eps
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.15
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SNR=1;                     % |Delta m|^2/sigma^2
rho=[0.99 0.9 0.5 0];
nr = length(rho);
NN = [2:1:10];
nN = length(NN);
dsqmax = zeros(nr,nN);
dsqmin = zeros(nr,nN);

for N=NN
    lambda = zeros(N,nr);
    for n=1:nr
        K = toeplitz(rho(n).^[0:1:N-1]);
        [u,lam]=eig(K);                             % eigendecomposition
        [lam,ind]=sort(diag(lam),'descend');        % sort eigenvalues in descending order
        dsqmax(n,N-1) = SNR/lam(N);
        dsqmin(n,N-1) = SNR/lam(1);
    end
end

figure(2)
subplot(2,1,1)
semilogy(NN,dsqmax(1,:).','-','linewidth',lw)
hold on
semilogy(NN,dsqmax(2,:).','--','linewidth',lw)
semilogy(NN,dsqmax(3,:).','-.','linewidth',lw)
semilogy(NN,dsqmax(4,:).','-+','linewidth',lw)
hold off
xlabel('N')
title('d^{2}_{max}=1/\lambda_{N}')
ylabel('d^{2}')
legend(['\rho=' num2str(rho(1))],['\rho=' num2str(rho(2))],...
       ['\rho=' num2str(rho(3))],['\rho=' num2str(rho(4))],'location','Eastoutside')
ylim([0.1 500])

subplot(2,1,2)
semilogy(NN,dsqmin(1,:).','-','linewidth',lw)
hold on
semilogy(NN,dsqmin(2,:).','--','linewidth',lw)
semilogy(NN,dsqmin(3,:).','-.','linewidth',lw)
semilogy(NN,dsqmin(4,:).','-+','linewidth',lw)
hold off
xlabel('N')
title('d^{2}_{min}=1/\lambda_{1}')
ylabel('d^{2}')
legend(['\rho=' num2str(rho(1))],['\rho=' num2str(rho(2))],...
       ['\rho=' num2str(rho(3))],['\rho=' num2str(rho(4))],'location','Eastoutside')
ylim([0.1 10])
print -deps Fig3-15.eps
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.16
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SNR=1;                     % |Delta m|^2/sigma^2
N=10;
rho=[[0:0.01:0.99] 0.999];
nr = length(rho);
dsqmin = zeros(1,nr);
dsqmax = zeros(1,nr);

for n=1:nr
    K = toeplitz(rho(n).^[0:1:N-1]);
    [u,lam]=eig(K);                             % eigendecomposition
    [lam,ind]=sort(diag(lam),'descend');        % sort eigenvalues in descending order
    dsqmax(n) = SNR/lam(N);
    dsqmin(n) = SNR/lam(1);
end

figure(3)
semilogy(abs(rho),dsqmax,'linewidth',lw)
hold on
semilogy(abs(rho),dsqmin,'--r','linewidth',lw)
hold off
xlabel('|\rho|')
ylabel('d^2')
title(['N=' int2str(N)])
legend('d^{2}_{max}=1/\lambda_{N}','d^{2}_{min}=1/\lambda_{1}','location','northwest')
ylim([0.1 1000])
print -deps Fig3-16.eps

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.18
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SINR=1;                     % |Delta m|^2/(sigma_I^{2}+sigma_n^2)
N=10;
rho=[[0:0.01:0.99] 0.999];
nr = length(rho);
dsqmin = zeros(1,nr);
dsqmax = zeros(1,nr);
INR = [0.01 1 100];
nI = length(INR);
for m=1:nI
    sigman2 = 1/(SINR*(1+INR(m)));
    sigmaI2 = INR(m)*sigman2;
    for n=1:nr
        K = toeplitz(rho(n).^[0:1:N-1]);
        [u,lam]=eig(K);                             % eigendecomposition
        [lam,ind]=sort(diag(lam),'descend');        % sort eigenvalues in descending order
        dsqmax(m,n) = SNR/(sigman2+sigmaI2*lam(N));
        dsqmin(m,n) = SNR/(sigman2+sigmaI2*lam(1));
    end
end

figure(4)
h1=semilogy(abs(rho),dsqmax,'linewidth',lw);
hold on
h2=semilogy(abs(rho),dsqmin,'--','linewidth',lw);
hold off
xlabel('|\rho|')
ylabel('d^2')
title(['N=' int2str(N)])
legend([h1(1) h2(1)],'d^{2}_{max}','d^{2}_{min}','location','northwest')
ylim([0.1 1000])
text(1.01,0.1,'\sigma_{I}^{2}/\sigma_{w}^{2}=100')
text(1.01,0.19,'\sigma_{I}^{2}/\sigma_{w}^{2}=1')
text(1.01,1,'\sigma_{I}^{2}/\sigma_{w}^{2}=0.01')
text(1.01,100,'\sigma_{I}^{2}/\sigma_{w}^{2}=100')
text(1.01,2,'\sigma_{I}^{2}/\sigma_{w}^{2}=1')
print -deps Fig3-18.eps


