%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 3.28, 3.29
% KLB 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
lw=0.5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.28
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N=4;
SNRdB=[-3:3:6];
SNR = 10.^(SNRdB/10);                   % sigma_s^2/sigma_n^2
ns = length(SNR);
rho=[0.7 0.9];
nr = length(rho);
thresh = [0:0.25:25];
nt = length(thresh);
PFC = zeros(nr+2,ns,nt);
PDC = zeros(nr+2,ns,nt);
topt = zeros(nr+2,ns,nt);

% rho = 0,1
for s=1:ns
    PF = gammainc(thresh*(1+SNR(s))/SNR(s),N,'upper');
    PD = gammainc(thresh/SNR(s),N,'upper');
    PFC(1,s,:)=PF;
    PDC(1,s,:)=PD;
    PF = exp(-thresh*(1+N*SNR(s))/(N*SNR(s)));
    PD = exp(-thresh/(N*SNR(s)));
    PFC(nr+2,s,:)=PF;
    PDC(nr+2,s,:)=PD;
end

for n=1:nr
    K = toeplitz(rho(n).^[0:1:N-1]);
    [u,lam]=eig(K);                            % eigendecomposition
    xi=sort(diag(lam),'descend');              % sort eigenvalues in descending order
    
    for s=1:ns
        PF = zeros(1,nt);
        PD = zeros(1,nt);
        
        alpha0 = SNR(s)*xi./(SNR(s)*xi+1);              % alpha on H0
        alpha1 = SNR(s)*xi;                             % alpha on H1
        A0 = (repmat(alpha0,1,N)-repmat(alpha0.',N,1)); % Aik = (alpha_i-alpha_k)
        A1 = (repmat(alpha1,1,N)-repmat(alpha1.',N,1)); % Aik = (alpha_i-alpha_k)
        b0=zeros(N,1);
        b1=zeros(N,1);
        for i=1:N
            A0(i,i)= alpha0(i);                        % change zeros on diagonal to alpha_i
            b0(i)  = 1/prod(A0(i,:)/alpha0(i));        % ith weight
            A1(i,i)= alpha1(i);                        % change zeros on diagonal to alpha_i
            b1(i)  = 1/prod(A1(i,:)/alpha1(i));        % ith weight
            
            PF = PF+b0(i)*exp(-thresh/(alpha0(i)));
            PD = PD+b1(i)*exp(-thresh/(alpha1(i)));
        end
        PFC(n+1,s,:)=PF;
        PDC(n+1,s,:)=PD;
    end  
end

figure(1)
for s=1:ns
    subplot(2,2,s)
    plot(squeeze(PFC(1,s,:)),squeeze(PDC(1,s,:)),'--','linewidth',lw)
    hold on
    plot(squeeze(PFC(2,s,:)),squeeze(PDC(2,s,:)),':','linewidth',lw)
    plot(squeeze(PFC(3,s,:)),squeeze(PDC(3,s,:)),'-.','linewidth',lw)
    plot(squeeze(PFC(4,s,:)),squeeze(PDC(4,s,:)),'-','linewidth',lw)
    hold off
    xlabel('P_{F}')
    ylabel('P_{D}')
    axis([0 1 0 1])
    title(['N=' int2str(N) ', SNR=' num2str(SNRdB(s)) ' dB'])
    legend(['|\rho|= 0'],['|\rho|= ' num2str(abs(rho(1)))],...
        ['|\rho|= ' num2str(abs(rho(2)))],['|\rho|= 1'],...
        'location','southeast')
end
print -deps Fig3-28.eps


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3.29
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N=4;
SNRdB=[-5:0.5:10];
SNR = 10.^(SNRdB/10);                   % sigma_s^2/sigma_n^2
ns = length(SNR);
PFA = [1e-2 1e-4 1e-6 1e-8];
np = length(PFA);
rho=[0.7 0.9];
nr = length(rho);
thresh = [0:0.5:25];
nt = length(thresh);

% rho = 0,1
PDC0 = zeros(np,ns);
PDC1 = zeros(np,ns);
gFN = gaminv(1-PFA,N,1);
for n=1:np
    PDC0(n,:) = gammainc(gFN(n)./(1+SNR),N,'upper');
    PDC1(n,:) = PFA(n).^(1./(1+N*SNR));
end

PFC = zeros(nr,ns,np);
PDC = zeros(nr,ns,np);
topt = zeros(nr,ns,np);
for n=1:nr
    K = toeplitz(rho(n).^[0:1:N-1]);
    [u,lam]=eig(K);                            % eigendecomposition
    xi=sort(diag(lam),'descend');              % sort eigenvalues in descending order
    
    for s=1:ns
        PF = zeros(1,nt);
        PD = zeros(1,nt);
        
        alpha0 = SNR(s)*xi./(SNR(s)*xi+1);              % alpha on H0
        alpha1 = SNR(s)*xi;                             % alpha on H1
        A0 = (repmat(alpha0,1,N)-repmat(alpha0.',N,1)); % Aik = (alpha_i-alpha_k)
        A1 = (repmat(alpha1,1,N)-repmat(alpha1.',N,1)); % Aik = (alpha_i-alpha_k)
        b0=zeros(N,1);
        b1=zeros(N,1);
        for i=1:N
            A0(i,i)= alpha0(i);                        % change zeros on diagonal to alpha_i
            b0(i)  = 1/prod(A0(i,:)/alpha0(i));        % ith weight
            A1(i,i)= alpha1(i);                        % change zeros on diagonal to alpha_i
            b1(i)  = 1/prod(A1(i,:)/alpha1(i));        % ith weight
            
            PF = PF+b0(i)*exp(-thresh/(alpha0(i)));
            PD = PD+b1(i)*exp(-thresh/(alpha1(i)));
        end
        
        ind = find(PF<0.5);
        topt(n,s,:) = interp1(log10(PF(ind)),thresh(ind),log10(PFA));
        for i=1:N
            PFC(n,s,:) = PFC(n,s,:)+b0(i)*exp(-topt(n,s,:)/(alpha0(i)));
            PDC(n,s,:) = PDC(n,s,:)+b1(i)*exp(-topt(n,s,:)/(alpha1(i)));
        end
        
    end % for s
end % for n

figure(2)
for n=1:np
    subplot(2,2,n)
    plot(SNRdB,PDC0(n,:),'--','linewidth',lw)
    hold on
    plot(SNRdB,PDC(1,:,n),':','linewidth',lw)
    plot(SNRdB,PDC(2,:,n),'-.','linewidth',lw)
    plot(SNRdB,PDC1(n,:),'-','linewidth',lw)
    hold off
    xlabel('SNR (dB)')
    ylabel('P_{D}')
    title(['N=' int2str(N) ', P_{F}=1e' num2str(log10(PFA(n)))])
    legend(['|\rho|=0'],['|\rho|=' num2str(abs(rho(1)))],...
        ['|\rho|=' num2str(abs(rho(2)))],['|\rho|=1'],'location','northwest')
end
print -deps Fig3-29.eps


