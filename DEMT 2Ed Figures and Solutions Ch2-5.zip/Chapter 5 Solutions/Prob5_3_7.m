%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 5.3.7
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 1.5;
FS = 10;

N=11;

T=1;
sigmaw2=1;

nmax=20;
MSE = zeros(4,nmax);
W = [ones(nmax,1) T*[1:1:nmax].' 0.5*T*T*([1:1:nmax].*[0:1:nmax-1]).'];
J=zeros(3,3);
J(1,1)=N;
J(1,2)=(T/2)*N*(N+1);
J(1,3)=(T^2/6)*N*(N^2-1);
J(2,1)=(T/2)*N*(N+1);
J(2,2)=(T^2/6)*N*(N+1)*(2*N+1);
J(2,3)=(T^3/24)*N*(N^2-1)*(3*N+2);
J(3,1)=(T^2/6)*N*(N^2-1);
J(3,2)=(T^3/24)*N*(N^2-1)*(3*N+2);
J(3,3)=(T^4/60)*N*(N^2-1)*(3*N^2-2);
J=J/sigmaw2;


m=1;
sigmax2 = 1;
sigmav2=1;
sigmaa2=1;
Kthinv = diag([1/sigmax2 1/sigmav2 1/sigmaa2]);
JB = Kthinv+J;
MSE(m,:) = diag(W*inv(JB)*W.').';

m=2;
sigmax2=0.01;
sigmav2=1;
sigmaa2=1;
Kthinv = diag([1/sigmax2 1/sigmav2 1/sigmaa2]);
JB = Kthinv+J;
MSE(m,:) = diag(W*inv(JB)*W.').';

m=3;
sigmax2=1;
sigmav2=0.01;
sigmaa2=1;
Kthinv = diag([1/sigmax2 1/sigmav2 1/sigmaa2]);
JB = Kthinv+J;
MSE(m,:) = diag(W*inv(JB)*W.').';

m=4;
sigmax2=1;
sigmav2=1;
sigmaa2=0.01;
Kthinv = diag([1/sigmax2 1/sigmav2 1/sigmaa2]);
JB = Kthinv+J;
MSE(m,:) = diag(W*inv(JB)*W.').';

VAR = diag(W*inv(J)*W.').';

figure(1)
h(1)=plot([1:1:nmax],VAR,'--r','linewidth',lw);
hold on
h(2)=plot([1:1:nmax],MSE(1,:),'-','linewidth',lw);
hold on
h(3)=plot([1:1:nmax],MSE(3,:),'-.','linewidth',lw);
h(4)=plot([1:1:nmax],MSE(2,:),'-+','linewidth',lw);
h(5)=plot([1:1:nmax],MSE(4,:),'-o','linewidth',lw);
xlabel('Time (n)','Fontsize',FS)
ylabel('MSE(x(n))','Fontsize',FS)
set(gca,'Fontsize',FS)
ylim([0 2])
xlim([0 15])
hold off
legend(['ML: \sigma_x^2=\infty, \sigma_v^2=\infty, \sigma_a^2=\infty'],...
    ['MAP: \sigma_x^2=1, \sigma_v^2=1, \sigma_a^2=1'],...
    ['MAP: \sigma_x^2=1, \sigma_v^2=0.01, \sigma_a^2=1'],...
    ['MAP: \sigma_x^2=0.01, \sigma_v^2=1, \sigma_a^2=1'],...
    ['MAP: \sigma_x^2=1, \sigma_v^2=1, \sigma_a^2=0.01'],...
    'location','northwest')
title('Problem 5.3.7')
print -deps Fig5-3-7.eps
