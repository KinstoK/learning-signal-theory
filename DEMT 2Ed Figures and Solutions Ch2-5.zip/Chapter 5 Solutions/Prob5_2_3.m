%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 5.2.3
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 1.5;
FS = 10;

NN=[6;11;20];

T=1;
sigmaw2=1;

nmax=20;
vx = zeros(3,nmax);
W = [ones(nmax,1) T*[1:1:nmax].' 0.5*T*T*([1:1:nmax].*[0:1:nmax-1]).'];
for m=1:3
    N=NN(m);
    V = [ones(N,1) T*[1:1:N].' 0.5*T*T*([1:1:N].*[0:1:N-1]).'];
    Jc=V'*V;
    J=zeros(3,3);
    J(1,1)=N;
    J(1,2)=(T/2)*N*(N+1);
    J(1,3)=(T^2/6)*N*(N^2-1);
    J(2,1)=(T/2)*N*(N+1);
    J(2,2)=(T^2/6)*N*(N+1)*(2*N+1);
    J(2,3)=(T^3/24)*N*(N^2-1)*(3*N+2);
    J(3,1)=(T^2/6)*N*(N^2-1);
    J(3,2)=(T^3/24)*N*(N^2-1)*(3*N+2);
    J(3,3)=(T^4/60)*N*(N^2-1)*(3*N^2-2);
    vx(m,:) = sigmaw2*diag(W*inv(J)*W.').';
end
%%
figure(1)
plot([1:1:nmax],vx(1,:),'-','linewidth',lw)
hold on
plot([1:1:nmax],vx(2,:),'--','linewidth',lw)
plot([1:1:nmax],vx(3,:),'-.','linewidth',lw)
xlabel('Time (n)','Fontsize',FS)
ylabel('Var(x(n))','Fontsize',FS)
grid on
set(gca,'Fontsize',FS)
ylim([0 2])
hold off
legend(['N=' int2str(NN(1))],['N=' int2str(NN(2))],['N=' int2str(NN(3))],'location','northwest')
title('Problem 5.2.3')
print -deps Fig5-2-3.eps
