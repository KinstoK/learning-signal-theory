%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 5.4.1
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 1.5;
FS = 10;

N=11;

T=1;
sigmaw2=1;

nmax=20;
W = [ones(nmax,1) T*[1:1:nmax].' 0.5*T*T*([1:1:nmax].*[0:1:nmax-1]).'];
J=zeros(3,3);
J(1,1)=N;
J(1,2)=(T/2)*N*(N+1);
J(1,3)=(T^2/6)*N*(N^2-1);
J(2,1)=(T/2)*N*(N+1);
J(2,2)=(T^2/6)*N*(N+1)*(2*N+1);
J(2,3)=(T^3/24)*N*(N^2-1)*(3*N+2);
J(3,1)=(T^2/6)*N*(N^2-1);
J(3,2)=(T^3/24)*N*(N^2-1)*(3*N+2);
J(3,3)=(T^4/60)*N*(N^2-1)*(3*N^2-2);
J=J/sigmaw2;

VAR = diag(W*inv(J)*W.').';

sigmax2=1;
sigmav2=1;
sigmaa2=1;
Kthinv = diag([1/sigmax2 1/sigmav2 1/sigmaa2]);
JB = Kthinv+J;
MSE = diag(W*inv(JB)*W.').';

MSE_S = zeros(1,nmax);

for k=1:N
    J=zeros(3,3);
    J(1,1)=k;
    J(1,2)=(T/2)*k*(k+1);
    J(1,3)=(T^2/6)*k*(k^2-1);
    J(2,1)=(T/2)*k*(k+1);
    J(2,2)=(T^2/6)*k*(k+1)*(2*k+1);
    J(2,3)=(T^3/24)*k*(k^2-1)*(3*k+2);
    J(3,1)=(T^2/6)*k*(k^2-1);
    J(3,2)=(T^3/24)*k*(k^2-1)*(3*k+2);
    J(3,3)=(T^4/60)*k*(k^2-1)*(3*k^2-2);
    J=J/sigmaw2;
    JB = Kthinv+J;
    MSE_S(k) = [1 k*T 0.5*k*(k-1)*T^2]*inv(JB)*[1;k*T;0.5*k*(k-1)*T^2];
end
for k=N+1:nmax
    MSE_S(k) = [1 k*T 0.5*k*(k-1)*T^2]*inv(JB)*[1;k*T;0.5*k*(k-1)*T^2];
end

figure(1)
plot([1:1:nmax],VAR,'--','linewidth',lw)
hold on
plot([1:1:nmax],MSE,'-','linewidth',lw)
hold on
plot([1:1:nmax],MSE_S,'-.','linewidth',lw)
xlabel('k','Fontsize',FS)
ylabel('MSE(x(k))','Fontsize',FS)
set(gca,'Fontsize',FS)
ylim([0 2])
xlim([0 15])
hold off
legend(['Block ML'],...
    ['Block MAP, \sigma_x^2=1, \sigma_v^2=1, \sigma_{a}^2=1'],...
    ['Sequential MAP, \sigma_x^2=1, \sigma_v^2=1, \sigma_{a}^2=1'],'location','northwest')
title('Problem 5.4.1')
print -deps Fig5-4-1.eps

