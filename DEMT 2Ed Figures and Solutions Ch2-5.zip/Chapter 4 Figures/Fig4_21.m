%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.21
% K. Bell
% 5/4/14
% saves/loads Fig4_21_data.mat 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

runsim = 0;      % 1 to run simulation, 0 to use saved data
a = 5;                    % Gamma parameter a

b0 = 1;
alpha0 = [3 10 50];
na = length(alpha0);                    

N = [1 2 4 7 10 20 40 70 100 200 400 700 1000];
nN = length(N);

if runsim
    L =10000;                  % Monte Carlo trials
    
    randn('state',500)
    rand('state',100)
    
    errMAP_mse = zeros(na,nN);
    errMS_mse = zeros(na,nN);
    
    for k=1:na
        for m=1:nN
            n = N(m)              % number of observations
            
            b_MS  = zeros(1,L);
            b_MAP  = zeros(1,L);
            for q=1:L
                b = 1/(gamrnd(alpha0(k),b0));
                R = gamrnd(a,b,1,n);          % data 1 x N
                Rbar = mean(R);
                b_MAP(q) = (n*Rbar+1/b0)/(n*a+alpha0(k)+1);         % MAP
                b_MS(q) = (n*Rbar+1/b0)/(n*a+alpha0(k)-1);         % MSE
                errMAP(q) = b_MAP(q)-b;
                errMS(q) = b_MS(q)-b;
            end % for q
            errMAP_mse(k,m) = sum(errMAP.^2)/L;                 % mse of error over trials
             errMS_mse(k,m) = sum(errMAP.^2)/L;                 % mse of error over trials
            
%             [H,B]=hist(a_ML);
%             bar(B,H)
%             title(['a=' num2str(a(k)) ',N=' int2str(n)])
%             pause
        end
    end
    
    save Fig4_21_data N L errMAP_mse errMS_mse
else
    load Fig4_21_data
end

%%
ECRB_b = zeros(na,nN);     % ECRB, b
BCRB_b = zeros(na,nN);     % BCRB, b
MSE_b = zeros(na,nN);     % BCRB, b


for k=1:na
    for m=1:nN
        BCRB_b(k,m) = 1/((b0^2)*(alpha0(k)*(alpha0(k)+1)*(alpha0(k)+N(m)*a+3)));            % BCRB
        MSE_b(k,m) =1/((b0^2)*((alpha0(k)-1)*(alpha0(k)-2)*(alpha0(k)+N(m)*a-1)));          % MSE
        ECRB_b(k,m) = 1/((b0^2)*((alpha0(k)-1)*(alpha0(k)-2)*(N(m)*a)));                 % ECRB
    end
end
%%
%--------------------
% RMSE, ECRB, BCRB vs SNR Fig 4.21
%--------------------
figure(1)
h1=loglog(N,sqrt(BCRB_b),'-.b','Linewidth',lw);
hold on
h5=loglog(N,sqrt(ECRB_b),'--r','Linewidth',lw);
h2= loglog(N,sqrt(MSE_b),'-k','Linewidth',lw);
h3=loglog(N,sqrt(errMAP_mse),'om','Linewidth',lw);
h4=loglog(N,sqrt(errMS_mse),'+c','Linewidth',lw);
hold off
set(gca,'XTick',10.^([0:1:4]))
set(gca,'XMinorGrid','off')
set(gca,'YMinorGrid','off')
legend([h3(1) h4(1) h2(1) h5(1) h1(1)],'MAP Sim.','MMSE Sim.','MSE','ECRB','BCRB')
xlabel('N','Fontsize',FS)
ylabel('RMSE','Fontsize',FS)
set(gca,'Fontsize',FS)
text(1100,sqrt(MSE_b(1,nN)),['\alpha_0=' num2str(alpha0(1))])
text(1100,sqrt(MSE_b(2,nN)),['\alpha_0=' num2str(alpha0(2))])
text(1100,sqrt(MSE_b(3,nN)),['\alpha_0=' num2str(alpha0(3))])

print -deps Fig4-21.eps




