%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.19
% BB Figure 12 RMSE regions vs. K
% K. Bell
% 5/4/14
% saves/loads Ex2K.mat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
lw = 0.5;
FS = 12;

runsim = 0;      % 1 to run simulation, 0 to use saved data

if ~runsim
    load Ex2K                    % loads omega_a theta_a K SNR M L H h pdf wse wb
    nk = length(K);
    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;

else % run simulation
    omega_a = 0.4*pi;             % actual frequency
    theta_a = pi/6;                 % actual phase (radians)

    K = [[3:1:18] [20:4:40] [50:10:100]];     % snapshots
    nk = length(K);
    SNR = 10.^(0/10);             % SNR
    b = sqrt(2*SNR);              % amplitude

    M = 50000;                    % Monte Carlo trials
    L = 2^15;                     % FFT grid size

    H = 100;                      % number of histogram bins
    h = ((0.5+[0:1:H-1])*2/H)-1;  % histogram bin centers

    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;

    wse = zeros(1,nk);        % sample squared error, omega
    wb  = zeros(1,nk);        % sample squared error, omega
    pdf = zeros(nk,H);        % histogram

    for n=1:nk
        [n K(n)]
        omega_hat = zeros(1,M);  % omega estimate
        k=[0:1:K(n)-1]; 
        for m=1:M
            x = b*exp(j*(omega_a*k+theta_a))+randn(1,K(n))+j*randn(1,K(n));
            F = fft(x,L)/K(n);
            F = fftshift(F);
            A = real(exp(-j*theta_a)*F); % known theta ambiguity surface
            [y,I] = max(A);
            omega_hat(m) = freq(I);
        end % m
        wse(n) = sum((omega_hat-omega_a).^2)/M;
        wb(n) = sum(omega_hat-omega_a)/M;

        pdf(n,:) = hist(omega_hat/pi,h)*(H/(2*M));
        CRB_omega(n) = (1/SNR)*(3/(K(n)*(K(n)-1)*(2*K(n)-1)));

    end % n
    save Ex2K omega_a theta_a K SNR M L H h pdf wse wb
end  %runsim
CRB_omega = zeros(1,nk);  % CRB
for n=1:nk
    CRB_omega(n) = (1/SNR)*(3/(K(n)*(K(n)-1)*(2*K(n)-1)));
end % n

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Plotting
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%--------------------
% RMSE regions Fig 4.19
%--------------------
figure(1)
semilogx(K,10*log10(sqrt(wse)),'-r','Linewidth',lw)
xlabel('N','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
%grid on
set(gca,'XTick',[1;2;5;10;20;50;100])
set(gca,'XTickLabel',[' 1 ';' 2 ';' 5 ';' 10';' 20';' 50';'100'])
axis([2 100 -30 1])
hold on
text(3,-4,'No Information','Fontsize',FS')
text(3,-5.2,'Region','Fontsize',FS')
text(11,-14,'Threshold','Fontsize',FS')
text(11,-15.2,'Region','Fontsize',FS')
text(49,-21.8,'Asymptotic','Fontsize',FS')
text(49,-23,'Region','Fontsize',FS')
hold off
set(gca,'Fontsize',FS)
print -deps Fig4-19.eps

