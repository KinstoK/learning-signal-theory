%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.16
% BB Figure 15 BCRB, ECRB
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
lw = 0.5;
FS = 12;

theta = 0;                 % actual phase (radians)
a = flipud([400;100;20;5]); 
na = length(a);

K = 16;                       % snapshots

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% BCRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SNR = 10.^([15 [10:-1:-55]]/10); % SNR
ns = length(SNR);

J_omega = (SNR)*K*(K-1)*(2*K-1)/3;
BCRB_omega = zeros(na+1,ns);
vv = zeros(na+1,1);
BCRB_omega(1,:)=J_omega.^(-1);
vv(1) = 1000;
for n=1:na
    Jwd = (a(n)-1)*(2*a(n)-1)/(pi*pi*(a(n)-2));
    vv(n+1) = pi*pi/(2*a(n)+1);
    BCRB_omega(n+1,:)=(J_omega+repmat(Jwd,1,ns)).^(-1);
end

%--------------------
% BCRB Fig 4.16
%--------------------
figure(1)
he=plot(10*log10(SNR),10*log10(sqrt(BCRB_omega(1,:))),'--m','Linewidth',lw);
hold on
hb=plot(10*log10(SNR),10*log10(sqrt(flipud(BCRB_omega(2:end,:)))),'-','Linewidth',lw);
for n=1:na
    text(-44,10*log10(sqrt(vv(n+1)))+0.5,['a=' int2str(a(n))],'Fontsize',FS)
end
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
legend([he hb(1)],'ECRB','BCRB')
axis([-45 15 -25 5])
set(gca,'Fontsize',FS)
grid on
print -deps Fig4-16.eps