%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.10
% Corrected BB Figure 4 Noisy Ambiguity Surface
% ML estimation of frequency, known phase
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 12;

K = 16;                  % snapshots
k = [0:1:K-1];

SNR = 10.^([5 -10 -25]/10);
ns = length(SNR);

omega_d = 0.4*pi;           % actual frequency
theta_a = pi/6;             % actual phase (radians)

M = 3;                      % Monte Carlo trials
ls = ['-.b';'--r';' -g'];
L = 2^15;                   % FFT grid size
freq = 2*pi*[-(L/2):1:(L/2)-1]/L;
figure(1)

zz=5556;
s = RandStream('mt19937ar','seed',zz);
RandStream.setGlobalStream(s)
clear hn
for m=1:M
    nn = randn(1,K)+j*randn(1,K);
    for n=1:ns
        b = sqrt(2*SNR(n));
        x = b*exp(j*(omega_d*k+theta_a))+nn;

        F = fft(x,L)/K;
        F = fftshift(F);
        A = abs(F);
        AS = real(exp(-j*theta_a)*F);     % known theta ambiguity surface
        [y,I]=max(AS);
        subplot(ns,1,n)
        hn(n,m)=plot(freq/pi,AS,ls(m,:),'Linewidth',lw);
        hold on
        plot(freq(I)/pi,y,'*k')
        ylabel('A(\omega;R)','Fontsize',FS)
        grid on
    end
end
for n=1:ns
    subplot(ns,1,n)
    if n==1
        h=legend(hn(1,:),'Trial 1','Trial 2','Trial 3','location','northeast');
        set(h,'Fontsize',10)
        axis([-1 1 -1 3])
    end
    hold off
    title(['SNR = ' num2str(10*log10(SNR(n))) ' dB'],'Fontsize',FS)
    set(gca,'Xtick',[-1:0.2:1])
    set(gca,'Fontsize',FS)
end
xlabel('\omega/\pi','FontSize',FS)
print -deps Fig4-10.eps

