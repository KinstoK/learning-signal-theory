%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.14 
% BB Figure 13
% beta prior pdf
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
lw = 0.5;
FS = 12;

omega_d = [-1:0.001:1]*pi;
nw = length(omega_d);
a = [20;5;2;1];
na = length(a);
pwd = zeros(na,nw);
ls = ['--';' -';'-.';' -'];
legs = [];
for m=1:na
    legs = [legs '''a=' num2str(a(m)) ''','];
    c = gamma(2*a(m))/(2*pi*gamma(a(m))^2);
    pwd(m,:) = c*(((pi+omega_d).*(pi-omega_d)/(4*pi*pi)).^(a(m)-1));
    h(m)=plot(omega_d/pi,pwd(m,:),ls(m,:),'Linewidth',lw);
    hold on
end
h(na)=plot([-1:0.2:1],(1/(2*pi))*ones(1,11),'-+','Linewidth',lw);
hold off
legs = legs(1:end-1); % remove last comma
xlabel('\omega/\pi','Fontsize',FS)
ylabel('p_{\omega}(\omega)','Fontsize',FS)
axis([-1 1 0 1])
eval(['legend(h,' legs ');'])
set(gca,'Fontsize',FS)
set(gca,'XTick',[-1:0.2:1])
print -deps Fig4-14.eps

