%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.15 
% BB Figure 14
% Bayesian Ambiguity Surface
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
lw = 0.5;
FS = 12;

lc = ['b';'r';'g'];
K = 16;				% 15 observations
omega_da = 0.4*pi;  % actual omega
omega_d = [-1:0.001:1]*pi;

a=20;
Ba = (gamma(a)^2)/gamma(2*a);
SNR = 10.^([0 -10 -20]/10); % SNR
ns = length(SNR);
LP = zeros(ns,length(omega_d));
figure
for n=1:ns;
    subplot(3,1,n)
    AS = 2*K*SNR(n)*real(sum(exp(j*[0:1:K-1].'*(omega_d-omega_da))))/K;
    PS = (a-1)*(log(pi+omega_d)+log(pi-omega_d))-2*(a-1)*log(2*pi)-log(2*pi*Ba);
    LP(n,:) = AS+PS;
    a1 = ceil(max(LP(n,:)));
    a2 = floor(min(LP(n,:)));
    plot(omega_d/pi,LP(n,:),lc(n,:),'Linewidth',lw)
    grid
    axis([-1 1 -10 max(a1,5)])
    title(['SNR = ' num2str(10*log10(SNR(n))) ' dB'],'Fontsize',FS)
    ylabel('A_{ps}(\omega)','Fontsize',FS)
    set(gca,'XTick',[-1:0.2:1])
    set(gca,'Fontsize',FS)
end
xlabel('\omega/\pi','Fontsize',FS)
print -deps Fig4-15.eps
