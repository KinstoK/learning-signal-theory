%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 4.17, 4.30, 4.31
% BB Figures:
% Figure 16 RMSE, BCRB
% Figure 22 RMSE, WWB
% Figure 26 RMSE, MIE
% MAP estimation of frequency, known phase
%
% K. Bell
% 5/4/14
% saves/loads Ex4a20.mat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
lw = 0.5;
lwW = 0.5;
FS = 12;

runsim = 0;      % 1 to run simulation, 0 to use saved data

a=20;
Ba = beta(a,a);
if ~runsim
    eval(['load Ex4a' int2str(a)])                   % loads a theta_a K SNR M L wseMAP wseML
    ns = length(SNR);
    k = [0:1:K-1];
    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;
else % run simulation
    theta_a = pi/6;              % actual phase (radians)

    K = 16;                      % snapshots
    SNR = 10.^([15 [10:-1:-20] [-25:-5:-45]]/10); % SNR

    M = 10000;                     % Monte Carlo trials
    L = 2^15;                    % FFT grid size

    ns = length(SNR);
    k = [0:1:K-1];
    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;

    wseMAP = zeros(1,ns);        % sample squared error, MAP
    wseML = zeros(1,ns);         % sample squared error, ML

    PS = (a-1)*(log(pi+freq)+log(pi-freq))-2*(a-1)*log(2*pi)-log(2*pi*Ba);

    for n=1:ns
        [n 10*log10(SNR(n))]
        b = sqrt(2*SNR(n));        % amplitude
        omega_ML = zeros(1,M);     % omega estimate
        omega_MAP = zeros(1,M);    % omega estimate
        omega_da = zeros(1,M);     % omega actual

        for m=1:M
            y = rand;
            omega_da(m)= (betainv(y,a,a)-0.5)*2*pi;
            x = b*exp(j*(omega_da(m)*k+theta_a))+randn(1,K)+j*randn(1,K);
            F = fft(x,L)/K;
            F = fftshift(F);
            AS = 2*K*SNR(n)*real(exp(-j*theta_a)*F); 
            [mx,I] = max(AS+PS);
            omega_MAP(m) = freq(I);
            [mx,I] = max(AS);
            omega_ML(m) = freq(I);
        end % m
        wseMAP(n) = sum((omega_MAP-omega_da).^2)/M;
        wseML(n) = sum((omega_ML-omega_da).^2)/M;
    end % n
    eval(['save Ex4a' int2str(a) ' a theta_a K SNR M L wseMAP wseML'])                   % loads a theta_a K SNR M L wseMAP wseML
end  %runsim

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% BCRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
J_omega = (SNR)*K*(K-1)*(2*K-1)/3;
Jwd = (a-1)*(2*a-1)/(pi*pi*(a-2));
BCRB_omega=(J_omega+Jwd).^(-1);

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% ECRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ECRB_omega=(J_omega).^(-1);

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% MIE
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
sigma2 = pi*pi/3;
sigma2w = pi*pi/(2*a+1);
m = sqrt(2*SNR);
qq = zeros(1,ns);
sigma = 1/sqrt(K);
for n=1:ns
    m = sqrt(2*SNR(n));
    del = 0.001;
    dd = [-10:del:10];
    xx = m+dd*sigma;
    int = normpdf(xx,m,sigma).*(normcdf(xx,0,sigma)).^(K-1);
    qq(n) = sum(int)*del*sigma;
end

MIE_omega=(sigma2+sigma2w)*(1-qq)+(min(J_omega.^(-1),sigma2)).*qq;
MIE_MAP_omega=(sigma2w)*(1-qq)+(min(J_omega.^(-1),sigma2w)).*qq;

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% WWB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
cv = 1/Ba;
dd = 0.0001;           % numerical integration grid

SL = zeros(1,K/2-1);   % sidelobe locations (/pi)
for k=1:K/2-1
    SL(k) = 2*(k+0.5-0.25*(1-k/(K/2-1)))/K;
end

rp = [0.1:0.1:1];      % equally spaced points (/pi)
hv=[0.001 0.01 SL rp]*pi;   % test points
r = length(hv);
WWB_omega = zeros(1,ns);
for ss = 1:ns
    snr = SNR(ss);
    Q = zeros(r,r);
    for ii=1:r
        hi = hv(ii);
        h=hi;
        mu_hi = -0.5*K*snr*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));

        d = h/(2*pi);
        d = round(d/dd)*dd;
        v = [0+dd/2:dd:1-d-dd/2];
        ph = cv*(v.*(1-v).*(v+d).*(1-v-d)).^(0.5*(a-1));
        gam_hi = log(sum(ph)*dd);
        eta_hi = mu_hi+gam_hi;

        for jj=1:r
            hj = hv(jj);

            h=hj;
            mu_hj = -0.5*K*snr*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));
            d = h/(2*pi);
            d = round(d/dd)*dd;
            v = [0+dd/2:dd:1-d-dd/2];
            ph = cv*(v.*(1-v).*(v+d).*(1-v-d)).^(0.5*(a-1));
            gam_hj = log(sum(ph)*dd);
            eta_hj = mu_hj+gam_hj;

            h = abs(hi-hj);
            if jj==ii
                mu_himhj = 0;
            else
                mu_himhj = -0.5*K*snr*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));
            end
            d = h/(2*pi);
            d = round(d/dd)*dd;
            d1 = min(hi,hj)/(2*pi);
            d1 = round(d1/dd)*dd;
            v = [d1+dd/2:dd:1-d-dd/2];
            ph = cv*(v.*(1-v).*(v+d).*(1-v-d)).^(0.5*(a-1));
            gam_hihj = log(sum(ph)*dd);
            eta_hihj = mu_himhj+gam_hihj;

            h = hi+hj;
            mu_hiphj = -0.5*K*snr*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));
            d = h/(2*pi);
            d = round(d/dd)*dd;
            v = [0+dd/2:dd:1-d-dd/2];
            ph = cv*(v.*(1-v).*(v+d).*(1-v-d)).^(0.5*(a-1));
            gam_hi_hj = log(sum(ph)*dd);
            eta_hi_hj = mu_hiphj+gam_hi_hj;
            Q(ii,jj) = 2*(exp(eta_hihj)-exp(eta_hi_hj))/exp(eta_hi+eta_hj);
        end % jj
    end % ii
    WWB_omega(1,ss)=hv*inv(Q)*hv.';
end  % SNR

%--------------------
% BCRB Fig 4.17
%--------------------
figure(1)
h3 =plot(10*log10(SNR),10*log10(sqrt(ECRB_omega)),'--r','Linewidth',lw);
hold on
h4 =plot(10*log10(SNR),10*log10(sqrt(BCRB_omega)),'-b','Linewidth',lw);
h1 = plot(10*log10(SNR),10*log10(sqrt(wseML)),'-og','Linewidth',lw);
h2 = plot(10*log10(SNR),10*log10(sqrt(wseMAP)),'-*m','Linewidth',lw);
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
grid on
axis([-45 15 -25 5])
legend([h1 h2 h3 h4],'ML','MAP','ECRB','BCRB')
print -deps Fig4-17.eps

%--------------------
% WWB Fig 4.30
%--------------------
figure(2)
h3 =plot(10*log10(SNR),10*log10(sqrt(ECRB_omega)),'--r','Linewidth',lw);
hold on
h4 =plot(10*log10(SNR),10*log10(sqrt(BCRB_omega)),'-.b','Linewidth',lw);
h5 =plot(10*log10(SNR),10*log10(sqrt(WWB_omega)),'-k','Linewidth',lw);
h1 = plot(10*log10(SNR),10*log10(sqrt(wseML)),'-og','Linewidth',lw);
h2 = plot(10*log10(SNR),10*log10(sqrt(wseMAP)),'-*m','Linewidth',lw);
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
grid on
axis([-45 15 -25 5])
legend([h1 h2 h3 h4 h5],'ML','MAP','ECRB','BCRB','WWB')
set(gca,'Fontsize',FS)
print -deps Fig4-30.eps

%%
%--------------------
% MIE Fig 4.31
%--------------------
figure(3)
h3 =plot(10*log10(SNR),10*log10(sqrt(ECRB_omega)),'--r','Linewidth',lw);
hold on
h4 =plot(10*log10(SNR),10*log10(sqrt(BCRB_omega)),'-.b','Linewidth',lw);
h5 =plot(10*log10(SNR),10*log10(sqrt(WWB_omega)),'-k','Linewidth',lwW);
%h6 =plot(10*log10(SNR),10*log10(sqrt(ZZB_omega)),'-r','Linewidth',lw);
h7 =plot(10*log10(SNR),10*log10(sqrt(MIE_omega)),'-dc','Linewidth',lw);
h8 =plot(10*log10(SNR),10*log10(sqrt(MIE_MAP_omega)),'-+b','Linewidth',lw);
h1 = plot(10*log10(SNR),10*log10(sqrt(wseML)),'-og','Linewidth',lw);
h2 = plot(10*log10(SNR),10*log10(sqrt(wseMAP)),'-*m','Linewidth',lw);
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
grid on
axis([-45 15 -25 5])
legend([h1 h2 h3 h4 h5 h7 h8],'ML','MAP','ECRB','BCRB','WWB','MIE-ML','MIE-MAP')
set(gca,'Fontsize',FS)
print -deps Fig4-31.eps

