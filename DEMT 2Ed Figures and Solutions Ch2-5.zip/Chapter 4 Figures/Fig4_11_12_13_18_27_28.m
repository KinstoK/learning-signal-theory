%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 4.11, 4.12, 4.13, 4.18, 4.27, 4.28
% BB Figures:
% Figure 5 pdfs vs. SNR
% Figure 6 Bias
% Figure 7 RMSE
% Figure 9 Bias
% Figure 10 RMSE
% Figure 11 RMSE regions vs. SNR
%
% K. Bell
% 5/4/14
% saves/loads Ex2RMSE.mat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

FS = 12;
lw = 0.5;
FS11 = 12;
lw11 = 0.5;
runsim = 0;      % 1 to run simulation, 0 to use saved data

if ~runsim
    load Ex2RMSE                  % loads omega_a theta_a K SNR M L H h Hk hk sigmap pdf pdfk pdf_kp pdfk_kp tse wse tb wb wse_kp wb_kp
    ns = length(SNR);
    k = [0:1:K-1];
    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;

else % run simulation
    omega_a = 0.4*pi;             % actual frequency
    theta_a = pi/6;               % actual phase (radians)

    K = 16;                       % snapshots
    SNR = 10.^([15 [10:-1:-25]]/10); % SNR

    M = 10000;                    % Monte Carlo trials
    L = 2^15;                     % FFT grid size

    H = 100;                      % number of histogram bins
    h = ((0.5+[0:1:H-1])*2/H)-1;  % histogram bin centers

    Hk = 1000;                    % number of density evaluation points
    hk = ((0.5+[0:1:Hk-1])*2/Hk)-1; % density evaluation points
    sigmap = 0.1*(2/K);           % st. dev. of Gaussian kernel for density estimator

    ns = length(SNR);
    k = [0:1:K-1];
    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;

    wse    = zeros(1,ns);        % sample squared error, omega
    tse    = zeros(1,ns);        % sample squared error, theta
    wb     = zeros(1,ns);        % sample bias, omega
    tb     = zeros(1,ns);        % sample bias, theta
    wse_kp = zeros(1,ns);        % sample squared error, omega, known phase
    wb_kp  = zeros(1,ns);        % sample bias, omega, known phase

    pdf = zeros(ns,H);        % histogram
    pdfk = zeros(ns,Hk);      % density estimate
    pdf_kp = zeros(ns,H);        % histogram
    pdfk_kp = zeros(ns,Hk);      % density estimate

    for n=1:ns
        [n 10*log10(SNR(n))]
        b = sqrt(2*SNR(n));         % amplitude
        omega_hat = zeros(1,M);     % omega estimate
        theta_hat = zeros(1,M);     % theta estimate
        omega_hat_kp = zeros(1,M);  % omega estimate, known phase

        for m=1:M
            x = b*exp(j*(omega_a*k+theta_a))+randn(1,K)+j*randn(1,K);
            F = fft(x,L)/K;
            F = fftshift(F);
            A = abs(F);                   % unknown theta ambiguity surface
            [y,I] = max(A);
            omega_hat(m) = freq(I);
            theta_hat(m) = angle(F(I));
            pdfk(n,:) = pdfk(n,:)+exp(-((hk-omega_hat(m)/pi).^2)/(2*sigmap^2))/(sqrt(2*pi)*sigmap);
            AS = real(exp(-j*theta_a)*F); % known theta ambiguity surface
            [y,I] = max(AS);
            omega_hat_kp(m) = freq(I);
            pdfk_kp(n,:) = pdfk_kp(n,:)+exp(-((hk-omega_hat_kp(m)/pi).^2)/(2*sigmap^2))/(sqrt(2*pi)*sigmap);
        end % m
        wse(n) = sum((omega_hat-omega_a).^2)/M;
        tse(n) = sum((theta_hat-theta_a).^2)/M;
        wse_kp(n) = sum((omega_hat_kp-omega_a).^2)/M;
        wb(n) = sum(omega_hat-omega_a)/M;
        tb(n) = sum(theta_hat-theta_a)/M;
        wb_kp(n) = sum(omega_hat_kp-omega_a)/M;

        pdf(n,:) = hist(omega_hat/pi,h)*(H/(2*M));
        pdfk(n,:) = pdfk(n,:)/M;
        pdf_kp(n,:) = hist(omega_hat_kp/pi,h)*(H/(2*M));
        pdfk_kp(n,:) = pdfk_kp(n,:)/M;
    end % n
    save Ex2RMSE omega_a theta_a K SNR M L H h Hk hk sigmap pdf pdfk pdf_kp pdfk_kp tse wse tb wb wse_kp wb_kp
end  %runsim

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% CRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
CRB_omega = (SNR.^(-1))*6/(K*(K^2-1));
CRB_theta = (SNR.^(-1))*(2*K-1)/(K*(K+1));
CRB_omega_kp = (SNR.^(-1))*3/(K*(K-1)*(2*K-1));

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Plotting
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

%--------------------
% pdfs vs SNR Fig 4.11
%--------------------
figure(1)
imagesc(hk,10*log10(SNR(2:ns)),pdfk_kp(2:ns,:),[0 1.5])
xlabel('\omega/\pi')
ylabel('SNR (dB)')
set(gca,'Ydir','normal')
title('Distribution of frequency estimates')

ni = 0;
axmax = [35 10 1];
for n=[7 22 37]
    ni=ni+1;
    subplot(1,3,ni)
    plot(hk,pdfk_kp(n,:),'Linewidth',lw)
    title(['SNR = ' num2str(10*log10(SNR(n))) ' dB'],'Fontsize',FS)
    axis([-1 1 0 axmax(ni)])
    xlabel('\omega/\pi','FontSize',FS)
    set(gca,'Fontsize',FS)
end
print -deps Fig4-11.eps



%--------------------
% Frequency bias, known phase Fig 4.12
%--------------------
figure(2)
plot(10*log10(SNR),wb_kp,'--*','Linewidth',lw)
xlabel('SNR (dB)','Fontsize',FS)
ylabel('Bias','Fontsize',FS)
grid on
set(gca,'Fontsize',FS)
print -deps Fig4-12.eps

%--------------------
% Frequency RMSE, known phase Fig 4.13
%--------------------
figure(3)
h1=plot(10*log10(SNR),10*log10(sqrt(CRB_omega_kp)),'r','Linewidth',lw);
hold on
h2=plot(10*log10(SNR),10*log10(sqrt(wse_kp)),'--*','Linewidth',lw);
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
grid on
legend([h2 h1],'Simulation','CRB')
axis([-25 15 -25 5])
set(gca,'Fontsize',FS)
print -deps Fig4-13.eps


%--------------------
% Frequency and phase bias Fig 4.27
%--------------------
figure(4)
subplot(2,1,1)
plot(10*log10(SNR),wb,'--*','Linewidth',lw)
xlabel('SNR (dB)','Fontsize',FS)
ylabel('Bias','Fontsize',FS)
title('Frequency','Fontsize',FS)
set(gca,'Fontsize',FS)
grid on

subplot(2,1,2)
plot(10*log10(SNR),tb,'--*','Linewidth',lw)
title('Phase','Fontsize',FS)
xlabel('SNR (dB)','Fontsize',FS)
ylabel('Bias','Fontsize',FS)
grid on
set(gca,'Fontsize',FS)
print -deps Fig4-27.eps


%--------------------
% Frequency and phase RMSE Fig 4.28
%--------------------
figure(5)
subplot(2,1,1)
h1=plot(10*log10(SNR),10*log10(sqrt(CRB_omega_kp)),'r','Linewidth',lw);
hold on
h2=plot(10*log10(SNR),10*log10(sqrt(CRB_omega)),'r','Linewidth',lw);
h3=plot(10*log10(SNR),10*log10(sqrt(wse_kp)),'--og','Linewidth',lw);
h4=plot(10*log10(SNR),10*log10(sqrt(wse)),'--*b','Linewidth',lw);
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
title('Frequency','Fontsize',FS)
grid on
legend([h4 h3 h2], 'Unknown phase','Known phase','CRBs')
set(gca,'Fontsize',FS)
axis([-25 15 -25 5])

subplot(2,1,2)
plot(10*log10(SNR),10*log10(sqrt(tse)),'--*b','Linewidth',lw)
hold on
plot(10*log10(SNR),10*log10(sqrt(CRB_theta)),'r','Linewidth',lw)
hold off
title('Phase','Fontsize',FS)
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
grid on
axis([-25 15 -15 5])
legend('Simulation','CRB')
set(gca,'Fontsize',FS)
print -deps Fig4-28.eps


%--------------------
% RMSE regions Fig 4.18
%--------------------
figure(6)
plot(10*log10(SNR),10*log10(sqrt(wse_kp)),'-','Linewidth',lw11)
xlabel('SNR (dB)','Fontsize',FS11)
ylabel('10*log_{10}(RMSE)','Fontsize',FS11)
axis([-25 10 -25 5])
%grid on
hold on
text(-23,2,'No Information','Fontsize',FS11')
text(-23,0.8,'Region','Fontsize',FS11')
text(-6,-11,'Threshold','Fontsize',FS11')
text(-6,-12.2,'Region','Fontsize',FS11')
text(3,-16,'High SNR','Fontsize',FS11')
text(3,-17.2,'Region','Fontsize',FS11')
hold off
set(gca,'Fontsize',FS11)
print -deps Fig4-18.eps


