%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 4.40, 4.41, 4.44
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

% Example 4.46
N=10;
lambda = [2 10 25];
xvals = [0:0.1:100];
F1N=fpdf(xvals,1,N-1);
mu0 = (N-1)/(N-3);
mu1 = mu0*(1+lambda);
figure(1)
h(1)=plot(xvals,F1N,'-b');
ls = ['--';'-.';'b-'];
hold on
for n=1:3
    F1Nlambda = ncfpdf(xvals,1,N-1,lambda(n));
    h(n+1)=plot(xvals,F1Nlambda,ls(n,:));
end
plot(xvals(1:50:1001),F1Nlambda(1:50:1001),'+')
h(4)= plot(xvals(1001),F1Nlambda(1001),'+-');

hold off
xlabel('x')
legend(h,'F_{1,N-1}(x)',['F''_{1,N-1}(x,' int2str(lambda(1)) ')'],['F''_{1,N-1}(x,' int2str(lambda(2)) ')'],...
    ['F''_{1,N-1}(x,' int2str(lambda(3)) ')'])
axis([0 60 0 0.4])
print -deps Fig4-40.eps
%%
PFA = 1e-4;
lambda = [1:1:64];
dd = sqrt(lambda);
g2 = norminv(1-PFA/2,0,1);
PD2 = 1-normcdf(g2+dd)+1-normcdf(g2-dd);
g3 = norminv(1-PFA,0,1)-dd/2;
PD3 = 1-normcdf(g3-dd/2,0,1);
figure(2)
plot(dd,norminv(PD3),'--k')
hold on
plot(dd,norminv(PD2),'-.r')
xlabel('sqrt(\lambda)')
ylabel('P_D')
ylim(norminv([1e-3 0.9999]))
set(gca,'Ytick',norminv([1e-3 1e-2 0.1 0.3 0.5 0.7 0.9 0.99 0.999 0.9999]))
set(gca,'YtickLabel',[' 0.001';'  0.01';'   0.1';'   0.3';'   0.5';'   0.7';'   0.9';'  0.99';' 0.999';'0.9999'])
text(7.6,3.85,'N=\infty')
for N=[10 20 50];
    gstar = finv(1-PFA,1,N-1);
    PD = 1-ncfcdf(gstar,1,N-1,lambda);
    plot(dd,norminv(PD))
    text(8.05,norminv(PD(end)),['N=' int2str(N)])
end
hold off
title(['P_{F}=1e' int2str(log10(PFA))])
legend('Perfect meas.','GLRT M','GLRT M,\sigma^2','location','northwest')
print -deps Fig4-41.eps
%%
% Example 4.47
N=10;
D=5;
lambda = [2 10 25];
xvals = [0:0.1:100];
FDN=fpdf(xvals,D,N-D);
mu0 = (N-D)/(N-D-2);
mu1 = mu0*(D+lambda)/D;
figure(3)
plot(xvals,FDN,'-b')
ls = ['--';'-.';'k:'];
hold on
for n=1:3
FDNlambda = ncfpdf(xvals,D,N-D,lambda(n));
plot(xvals,FDNlambda,ls(n,:))
end
hold off
xlabel('x')
legend('F_{D,N-D}(x)',['F''_{D,N-D}(x,' int2str(lambda(1)) ')'],['F''_{D,N-D}(x,' int2str(lambda(2)) ')'],...
    ['F''_{D,N-D}(x,' int2str(lambda(3)) ')'])
axis([0 60 0 0.4])

%%
PFA = 1e-4;
lambda = [1:1:64];
dd = sqrt(lambda);
g2 = norminv(1-PFA/2,0,1);
PD2 = 1-normcdf(g2+dd)+1-normcdf(g2-dd);
g3 = norminv(1-PFA,0,1)-dd/2;
PD3 = 1-normcdf(g3-dd/2,0,1);
figure(4)
plot(dd,norminv(PD3),'--k')
hold on
xlabel('sqrt(\lambda)')
ylabel('P_D')
ylim(norminv([1e-3 0.9999]))
set(gca,'Ytick',norminv([1e-3 1e-2 0.1 0.3 0.5 0.7 0.9 0.99 0.999 0.9999]))
set(gca,'YtickLabel',[' 0.001';'  0.01';'   0.1';'   0.3';'   0.5';'   0.7';'   0.9';'  0.99';' 0.999';'0.9999'])
text(7.8,4.1,'N=\infty')
text(7.6,3.85,'D=1')
N=10000;
for D=[1 2 4]
    gstar = finv(1-PFA,D,N-D);
    PD = 1-ncfcdf(gstar,D,N-D,lambda);
    plot(dd,norminv(PD))
    if D~=1
    text(8.05,norminv(PD(end)),['D=' int2str(D)])
    end
end
N=10;
gstar = finv(1-PFA,1,N-1);
PD1 = 1-ncfcdf(gstar,1,N-1,lambda);
plot(dd,norminv(PD1),':g')
text(8.05,norminv(PD1(end))+0.25,['N=' int2str(N) ])
for D=[1 2 4]
    gstar = finv(1-PFA,D,N-D);
    PD = 1-ncfcdf(gstar,D,N-D,lambda);
    plot(dd,norminv(PD))
    text(8.05,norminv(PD(end)),['D=' int2str(D)])
end
hold off
title(['P_{F}=1e' int2str(log10(PFA))])
legend('Perfect meas.','GLRT M,\theta,\sigma^2','location','northwest')
print -deps Fig4-44.eps

