%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.20
% Example 4.25 Inverse gamma prior
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

alpha = [5 3 1];
beta = 1;

na = length(alpha);
x=[0:0.01:5];
pth = zeros(na,length(x));

for n=1:na
    c=(beta^(alpha(n)))/gamma(alpha(n));
    pth(n,:)=c*(x.^(-(alpha(n)+1))).*exp(-beta./x);
end

figure(1)
plot(x,pth(1,:),'-','Linewidth',lw)
hold on
plot(x,pth(2,:),'--','Linewidth',lw)
plot(x,pth(3,:),'-.','Linewidth',lw)
hold off
legend(['\alpha=' num2str(alpha(1))],['\alpha=' num2str(alpha(2))],['\alpha=' num2str(alpha(3))])
xlabel('\theta','Fontsize',FS)
ylabel('p(\theta)','Fontsize',FS)
set(gca,'Fontsize',FS)
print -deps Fig4-20.eps

