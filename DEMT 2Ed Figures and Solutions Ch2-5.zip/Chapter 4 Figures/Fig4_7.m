%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.7
% Example 4.12  ML estimation of Gamma parameter A
% K. Bell
% 5/4/14
% saves/loads Fig4_7_data.mat 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

runsim = 0;      % 1 to run simulation, 0 to use saved data

b = 1;                % Gamma parameter b
a = [0.5 2 8];                    % Gamma parameter a
na = length(a);                    

N = [1 2 4 7 10 20 40 70 100 200 400 700 1000];
nN = length(N);

a_vals = [0:0.001:30];
psi_vals = psi(a_vals);
if runsim
    L = 5000;                  % Monte Carlo trials
    
    randn('state',500)
    rand('state',100)
    
    errML_sm = zeros(na,nN);
    errML_sv = zeros(na,nN);
    errML_mse = zeros(na,nN);
    
    for k=1:na
        for m=1:nN
            n = N(m)              % number of observations
            
            a_ML  = zeros(1,L);
            for q=1:L
                R = gamrnd(a(k),b,1,n);          % data 1 x N
                lRbar = mean(log(R/b));
                a_ML(q) = interp1(psi_vals,a_vals,lRbar);         % Find a_ML using linear interpolation
            end % for q
            errML = a_ML-a(k);
            errML_sm(k,m) = sum(errML)/L;                     % average error over trials
            errML_sv(k,m) = sum((errML-errML_sm(k,m)).^2)/L;    % sample variance of error over trials
            errML_mse(k,m) = sum(errML.^2)/L;                 % mse of error over trials
            
%             [H,B]=hist(a_ML);
%             bar(B,H)
%             title(['a=' num2str(a(k)) ',N=' int2str(n)])
%             pause
        end
    end
    
    save Fig4_7_data N L errML_sm errML_sv
else
    load Fig4_7_data
end

CRB_a = (psi(1,a).'*N).^(-1);     % CRB
%%
%--------------------
% Bias vs SNR
%--------------------
figure(2)
subplot(2,1,1)
semilogx(N,errML_sm(1,:)/a(1),'*-g','Linewidth',lw)
hold on
semilogx(N,errML_sm(2,:)/a(2),'o-b','Linewidth',lw)
semilogx(N,errML_sm(3,:)/a(3),'+-r','Linewidth',lw)
hold off

legend(['A=' num2str(a(1))], ['A=' num2str(a(2))],['A=' num2str(a(3))])
xlabel('N','Fontsize',FS)
ylabel('Norm. Bias','Fontsize',FS)
axis([1 1000 -0.1 0.8])
set(gca,'Fontsize',FS)

%%
%--------------------
% CRB vs SNR Fig 4.7
%--------------------
subplot(2,1,2)
h1=loglog(N,sqrt(CRB_a),'-b','Linewidth',lw);
hold on
h2=loglog(N,sqrt(errML_sv),'*--g','Linewidth',lw);
hold off
set(gca,'XTick',10.^([0:1:3]))
set(gca,'XMinorGrid','off')
set(gca,'YMinorGrid','off')
legend([h2(1) h1(1)],'ML Sim.','CRB')
xlabel('N','Fontsize',FS)
ylabel('Std. Dev.','Fontsize',FS)
axis([1 1000 1e-2 3])
text(1100,sqrt(CRB_a(1,nN)),['A=' num2str(a(1))])
text(1100,sqrt(CRB_a(2,nN)),['A=' num2str(a(2))])
text(1100,sqrt(CRB_a(3,nN)),['A=' num2str(a(3))])
set(gca,'Fontsize',FS)
print -deps Fig4-7.eps


