%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.29
% BB Figure 21 WWB
% MAP estimation of frequency, known phase
%
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
lw = 0.5;
lwW = 0.5;
FS = 12;

theta = 0;                      % actual phase (radians)
a = flipud([400;100;20;5;2;1]); % gamma doesn't like 2a>170
na = length(a);

K = 16;                       % snapshots

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% BCRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SNR = 10.^([15 [10:-1:-55]]/10); % SNR
ns = length(SNR);

J_omega = (SNR)*K*(K-1)*(2*K-1)/3;
BCRB_omega = zeros(na+1,ns);
vv = zeros(na+1,1);
BCRB_omega(1,:)=J_omega.^(-1);
vv(1) = 1000;
for n=1:na
    Jwd = (a(n)-1)*(2*a(n)-1)/(pi*pi*(a(n)-2));
    vv(n+1) = pi*pi/(2*a(n)+1);
    BCRB_omega(n+1,:)=(J_omega+repmat(Jwd,1,ns)).^(-1);
end


%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% WWB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SNR = 10.^([15 [10:-1:-55]]/10); % SNR
ns = length(SNR);

dd = 0.0001;
dw = 0.0001;
del = 0.001;
del = round(del/dw)*dw;
h = del*2*pi;
s = 0.5;
mu_sh = -2*K*SNR*s*(1-s)*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));
mu_s2h = -2*K*SNR*s*(1-s)*(1-cos(2*h*(K-1)/2)*sin(2*h*K/2)/(K*sin(2*h/2)));

SL = zeros(1,K/2-1);
for k=1:K/2-1
    SL(k) = 2*(k+0.5-0.25*(1-k/(K/2-1)))/K;
end
rp = [0.1:0.1:1];

rp = [0.1 0.2 0.4 0.5 0.6 0.7 0.9];
hv = [0.001 0.01 SL(1:4)]*pi;
r = length(hv);
WWB_omega = zeros(na,ns);
for ss = 1:ns
    snr = SNR(ss);
    for n=1:na
        c = 1/(beta(a(n),a(n))*2*pi);
        cv = 1/beta(a(n),a(n));
        Q = zeros(r,r);
        for ii=1:r
            hi = hv(ii);
            h=hi;
            mu_hi = -0.5*K*snr*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));

            d = h/(2*pi);
            d = round(d/dd)*dd;
            v = [0+dd/2:dd:1-d-dd/2];
            ph = cv*(v.*(1-v).*(v+d).*(1-v-d)).^(0.5*(a(n)-1));
            exp_gam_hi = sum(ph)*dd;
            exp_eta_hi = exp(mu_hi)*exp_gam_hi;

            for jj=1:r
                hj = hv(jj);
                
                h=hj;
                mu_hj = -0.5*K*snr*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));
                d = h/(2*pi);
                d = round(d/dd)*dd;
                v = [0+dd/2:dd:1-d-dd/2];
                ph = cv*(v.*(1-v).*(v+d).*(1-v-d)).^(0.5*(a(n)-1));
                exp_gam_hj = sum(ph)*dd;
                exp_eta_hj = exp(mu_hj)*exp_gam_hj;

                h = abs(hi-hj);
                if jj==ii
                    mu_himhj = 0;
                else
                    mu_himhj = -0.5*K*snr*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));
                end
                d = h/(2*pi);
                d = round(d/dd)*dd;
                d1 = min(hi,hj)/(2*pi);
                d1 = round(d1/dd)*dd;
                v = [d1+dd/2:dd:1-d-dd/2];
                ph = cv*(v.*(1-v).*(v+d).*(1-v-d)).^(0.5*(a(n)-1));
                exp_gam_hihj = sum(ph)*dd;
                exp_eta_hihj = exp(mu_himhj)*exp_gam_hihj;
                
                h = hi+hj;
                mu_hiphj = -0.5*K*snr*(1-cos(h*(K-1)/2)*sin(h*K/2)/(K*sin(h/2)));
                d = h/(2*pi);
                d = round(d/dd)*dd;
                v = [0+dd/2:dd:1-d-dd/2];
                ph = cv*(v.*(1-v).*(v+d).*(1-v-d)).^(0.5*(a(n)-1));
                exp_gam_hi_hj = sum(ph)*dd;
                exp_eta_hi_hj = exp(mu_hiphj)*exp_gam_hi_hj;
                Q(ii,jj) = 2*(exp_eta_hihj-exp_eta_hi_hj)/(exp_eta_hi*exp_eta_hj);
            end % jj
        end % ii
        WWB_omega(n,ss)=hv*inv(Q)*hv.';
    end
end

%--------------------
% WWB Fig 4.29
%--------------------
figure(1)
he=plot(10*log10(SNR),10*log10(sqrt(BCRB_omega(1,:))),'--m','Linewidth',lw);
hold on
ind = find(a>2);
hb=plot(10*log10(SNR),10*log10(sqrt(flipud(BCRB_omega(ind+1:end,:)))),'-.','Linewidth',lw);
hw=plot(10*log10(SNR),10*log10(sqrt(flipud(WWB_omega))),'-','Linewidth',lw);
for n=1:na
    text(-44,10*log10(sqrt(vv(n+1)))+0.5,['a=' int2str(a(n))],'Fontsize',FS)
end
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
legend([he hb(1) hw(1)],'ECRB','BCRB','WWB')
set(gca,'Fontsize',FS)
grid on
axis([-45 15 -25 5])
print -deps Fig4-29.eps


