%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.9
% BB Figure 3 Noise-free Ambiguity Surface
% ML estimation of frequency, known phase
% K. Bell
% 5/4/14
% calls sinc.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

lw = 0.5;
FS = 12;

K = 16;				           % 16 observations
omega_da = 0.4*pi;             % actual omega
omega_d = [-1:0.001:1]*pi;

ASreal = cos((omega_d-omega_da)*(K-1)/2).*sinc((omega_d-omega_da)*K/(2*pi))./sinc((omega_d-omega_da)/(2*pi));

figure(1)
plot(omega_d/pi,ASreal,'Linewidth',lw)
grid
xlabel('\omega/\pi','Fontsize',FS)
ylabel('A_{sn}(\omega)','Fontsize',FS)
axis([-1 1 -0.2 1])
set(gca,'YTick',[-0.2:0.2:1],'Fontsize',FS)
set(gca,'XTick',[-1:0.2:1],'Fontsize',FS)

print -deps Fig4-9.eps

