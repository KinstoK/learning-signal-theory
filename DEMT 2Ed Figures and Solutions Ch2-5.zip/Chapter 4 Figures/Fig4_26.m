%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.26 
% Noise-free Ambiguity Surface
% ML estimation of frequency and phase
% K. Bell
% 5/4/14
% calls sinc.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
FS = 12;

K = 16;				% 16 observations
omega_da = 0.4*pi;  % actual omega
omega_d = [-1:0.001:1]*pi;
ASabs = abs(sinc((omega_d-omega_da)*K/(2*pi))./sinc((omega_d-omega_da)/(2*pi)));

figure(1)
plot(omega_d/pi,ASabs)
grid
xlabel('\omega/\pi','Fontsize',FS)
ylabel('A_{sn}(\omega)','Fontsize',FS)
axis([-1 1 0 1])
set(gca,'YTick',[0:0.2:1])
set(gca,'XTick',[-1:0.2:1])
set(gca,'Fontsize',FS)
print -deps Fig4-26.eps
