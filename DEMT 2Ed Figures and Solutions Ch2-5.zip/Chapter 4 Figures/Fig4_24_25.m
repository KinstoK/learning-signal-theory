%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 4.24, 4.25
% K. Bell
% 5/4/14
% saves/loads Fig4_24_25_data.mat 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

runsim = 0;      % 1 to run simulation, 0 to use saved data

b = 1;                % Gamma parameter b
a = [0.5 2 8];                    % Gamma parameter a
na = length(a);                    

N = [2 4 7 10 20 40 70 100 200 400 700 1000];
nN = length(N);

a_vals = [0.001:0.001:40];
psi_log_vals = psi(a_vals)-log(a_vals);
if runsim
    L = 500;                  % Monte Carlo trials
    
    randn('state',500)
    rand('state',100)
    
    errMLa_sm = zeros(na,nN);
    errMLa_sv = zeros(na,nN);
    errMLa_mse = zeros(na,nN);

    errMLb_sm = zeros(na,nN);
    errMLb_sv = zeros(na,nN);
    errMLb_mse = zeros(na,nN);
    
    for k=1:na
        for m=1:nN
            n = N(m)              % number of observations
            
            a_ML  = zeros(1,L);
            for q=1:L
                R = gamrnd(a(k),b,1,n);          % data 1 x N
                Rbar = mean(R);
                logRbar = mean(log(R));
                a_ML(q) = interp1(psi_log_vals,a_vals,logRbar-log(Rbar),'linear','extrap');         % Find a_ML using linear interpolation
                b_ML(q) = Rbar/a_ML(q);
            end % for q
            errMLa = a_ML-a(k);
            errMLa_sm(k,m) = sum(errMLa)/L;                       % sample mean error (bias) over trials
            errMLa_sv(k,m) = sum((errMLa-errMLa_sm(k,m)).^2)/L;    % sample variance of error over trials
            errMLa_mse(k,m) = sum(errMLa.^2)/L;                   % mse of error over trials

            errMLb = b_ML-b;
            errMLb_sm(k,m) = sum(errMLb)/L;                       % sample mean error (bias) over trials
            errMLb_sv(k,m) = sum((errMLb-errMLb_sm(k,m)).^2)/L;    % sample variance of error over trials
            errMLb_mse(k,m) = sum(errMLb.^2)/L;                   % mse of error over trials
            
%             [H,B]=hist(a_ML);
%             bar(B,H)
%             title(['a=' num2str(a(k)) ',N=' int2str(n)])
%             pause
        end
    end
    
    save Fig4_24_25_data a b N L errMLa_sm errMLa_sv errMLb_sm errMLb_sv
else
    load Fig4_24_25_data
end
%%
v = (a.*psi(1,a)).';
psi_fact = v./(v-1);
CRB_a = repmat(psi_fact,1,nN)./(psi(1,a).'*N);     % CRB
CRB_b = repmat(psi_fact,1,nN).*(b*b./(a.'*N));     % CRB
%%
%--------------------
% Bias vs SNR
%--------------------
figure(1)
subplot(2,1,1)
semilogx(N,errMLa_sm(1,:)/a(1),'*-g','Linewidth',lw)
hold on
semilogx(N,errMLa_sm(2,:)/a(2),'o-b','Linewidth',lw)
semilogx(N,errMLa_sm(3,:)/a(3),'+-r','Linewidth',lw)
hold off

legend(['A=' num2str(a(1))], ['A=' num2str(a(2))],['A=' num2str(a(3))])
xlabel('N','Fontsize',FS)
ylabel('Norm. Bias a','Fontsize',FS)
axis([1 1000 -1 4])
set(gca,'Fontsize',FS)
subplot(2,1,2)
semilogx(N,errMLb_sm(1,:),'*-g','Linewidth',lw)
hold on
semilogx(N,errMLb_sm(2,:),'o-b','Linewidth',lw)
semilogx(N,errMLb_sm(3,:),'+-r','Linewidth',lw)
hold off

legend(['A=' num2str(a(1))], ['A=' num2str(a(2))],['A=' num2str(a(3))],'location','southeast')
xlabel('N','Fontsize',FS)
ylabel('Bias b','Fontsize',FS)
axis([1 1000 -0.5 0.1])
set(gca,'Fontsize',FS)
print -deps Fig4-24.eps

%%
%--------------------
% CRB vs SNR Fig 4.25
%--------------------
figure(2)
subplot(2,1,1)
h1=loglog(N,sqrt(CRB_a(1,:)),'-g','Linewidth',lw);
hold on
h1=loglog(N,sqrt(CRB_a(2,:)),'-b','Linewidth',lw);
h1=loglog(N,sqrt(CRB_a(3,:)),'-r','Linewidth',lw);
h2=loglog(N,sqrt(errMLa_sv(1,:)),'*--g','Linewidth',lw);
h2=loglog(N,sqrt(errMLa_sv(2,:)),'*--b','Linewidth',lw);
h2=loglog(N,sqrt(errMLa_sv(3,:)),'*--r','Linewidth',lw);
hold off
set(gca,'XTick',10.^([0:1:3]))
set(gca,'XMinorGrid','off')
set(gca,'YMinorGrid','off')
legend([h2(1) h1(1)],'ML Sim.','CRB')
xlabel('N','Fontsize',FS)
ylabel('Std. Dev. a','Fontsize',FS)
axis([1 1000 1e-2 50])
text(1100,sqrt(CRB_a(1,nN)),['A=' num2str(a(1))])
text(1100,sqrt(CRB_a(2,nN)),['A=' num2str(a(2))])
text(1100,sqrt(CRB_a(3,nN)),['A=' num2str(a(3))])
set(gca,'Fontsize',FS)

subplot(2,1,2)
h1=loglog(N,sqrt(CRB_b(1,:)),'-g','Linewidth',lw);
hold on
h1=loglog(N,sqrt(CRB_b(2,:)),'-b','Linewidth',lw);
h1=loglog(N,sqrt(CRB_b(3,:)),'-r','Linewidth',lw);
h2=loglog(N,sqrt(errMLb_sv(1,:)),'*--g','Linewidth',lw);
h2=loglog(N,sqrt(errMLb_sv(2,:)),'*--b','Linewidth',lw);
h2=loglog(N,sqrt(errMLb_sv(3,:)),'*--r','Linewidth',lw);
hold off
set(gca,'XTick',10.^([0:1:3]))
set(gca,'XMinorGrid','off')
set(gca,'YMinorGrid','off')
legend([h2(1) h1(1)],'ML Sim.','CRB')
xlabel('N','Fontsize',FS)
ylabel('Std. Dev. b','Fontsize',FS)
axis([1 1000 4e-2 2])
text(1100,sqrt(CRB_b(1,nN)),['A=' num2str(a(1))])
text(1100,sqrt(CRB_b(2,nN)),['A=' num2str(a(2)) ',' num2str(a(3))])
set(gca,'Fontsize',FS)
print -deps Fig4-25.eps


