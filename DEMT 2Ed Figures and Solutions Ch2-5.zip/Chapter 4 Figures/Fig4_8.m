%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4.8
% Example 4.14 MAP, MS, ML estimation of Poisson parameter A, Gamma prior
% RMSE and bounds
% K. Bell
% 5/4/14
% saves/loads Fig4_8_data.mat 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

runsim = 0;      % 1 to run simulation, 0 to use saved data

theta = 0.1;                % Gamma parameter theta
k = 3;                    % Gamma parameter k

M = [1 2 4 7 10 20 40 70 100 200 400 700 1000];
nM = length(M);

if runsim
    L = 5000;                  % Monte Carlo trials
    
    randn('state',500)
    rand('state',100)
    
    errML_sm = zeros(1,nM);
    errML_sv = zeros(1,nM);
    errML_mse = zeros(1,nM);
    errMS_sm = zeros(1,nM);
    errMS_sv = zeros(1,nM);
    errMS_mse = zeros(1,nM);
    errMAP_sm = zeros(1,nM);
    errMAP_sv = zeros(1,nM);
    errMAP_mse = zeros(1,nM);
    
    for m=1:nM
        n = M(m)              % number of observations
        
        a_ML  = zeros(1,L);
        a_MAP = zeros(1,L);
        a_MS = zeros(1,L);
        for q=1:L
            a(q) = gamrnd(k,theta);             % a
            N = poissrnd(a(q),1,M(m));          % data 1 x M
            Nbar = mean(N);
            kp = k+M(m)*Nbar;
            thetap = theta/(M(m)*theta+1);
            a_MS(q) = kp*thetap;
            a_MAP(q) = (kp-1)*thetap;
            a_ML(q) = Nbar;
        end % for q
        errML = a_ML-a;
        errML_sm(m) = sum(errML)/L;                     % average error over trials
        errML_sv(m) = sum((errML-errML_sm(m)).^2)/L;    % sample variance of error over trials
        errML_mse(m) = sum(errML.^2)/L;                 % mse of error over trials
        errMAP = a_MAP-a;
        errMAP_sm(m) = sum(errMAP)/L;                   % average error over trials
        errMAP_sv(m) = sum((errMAP-errMAP_sm(m)).^2)/L; % sample variance of error over trials
        errMAP_mse(m) = sum(errMAP.^2)/L;               % mse of error over trials
        errMS = a_MS-a;
        errMS_sm(m) = sum(errMS)/L;                   % average error over trials
        errMS_sv(m) = sum((errMS-errMS_sm(m)).^2)/L; % sample variance of error over trials
        errMS_mse(m) = sum(errMS.^2)/L;               % mse of error over trials
%         subplot(2,1,1)
%         plot(a_MAP,a_MS,'.')
%         hold on
%         plot([0 8],[0 8],'k')
%         hold off
%         xlabel('a_{MAP}')
%         ylabel('a_{MS}')
%         subplot(2,1,2)
%         plot(a_MAP,a_ML,'.')
%         hold on
%         plot([0 8],[0 8],'k')
%         xlabel('a_{MAP}')
%         ylabel('a_{ML}')
%         hold off
%         
%         pause
    end
    save Fig4_8_data M L errML_sm errMAP_sm errMS_sm errML_mse errMAP_mse errMS_mse
else
    load Fig4_8_data
end

ECRB_a = zeros(1,nM);     % ECRB, a
BCRB_a = zeros(1,nM);     % BCRB, a
MSE_a = zeros(1,nM);     % MMSE, a

for m=1:nM
    BCRB_a(m) = (theta^2)/(M(m)*theta/(k-1)+1/(k-2));            % BCRB
    ECRB_a(m) = k*theta/M(m);                                % ECRB
    MSE_a(m) = k*(theta^2)/(M(m)*theta+1);                                % ECRB
end
%%
%--------------------
% RMSE, ECRB, BCRB vs SNR 
%--------------------
figure(2)
loglog(M,sqrt(ECRB_a),'--r','Linewidth',lw)
hold on
loglog(M,sqrt(MSE_a),'-k','Linewidth',lw)
loglog(M,sqrt(BCRB_a),'-.b','Linewidth',lw)
loglog(M,sqrt(errML_mse),'*g','Linewidth',lw)
loglog(M,sqrt(errMAP_mse),'om','Linewidth',lw)
loglog(M,sqrt(errMS_mse),'+c','Linewidth',lw)
hold off
set(gca,'XTick',10.^([0:1:4]))
set(gca,'XMinorGrid','off')
set(gca,'YMinorGrid','off')
legend('ECRB','MMSE','BCRB','ML Sim.','MAP Sim.','MMSE Sim.')
xlabel('M','Fontsize',FS)
ylabel('RMSE','Fontsize',FS)
axis([1 1000 1e-2 1])
set(gca,'Fontsize',FS)
print -deps Fig4-8.eps

%%
%--------------------
% Bias vs SNR
%--------------------
figure(3)
semilogx(M,errML_sm,'*g','Linewidth',lw)
hold on
semilogx(M,errMS_sm,'+c','Linewidth',lw)
semilogx(M,errMAP_sm,'om','Linewidth',lw)
hold off
legend('ML Sim.','MS Sim.','MAP Sim.')
xlabel('M','Fontsize',FS)
ylabel('Bias','Fontsize',FS)
axis([1 1000 -0.1 0.1])
set(gca,'Fontsize',FS)

