%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 2.2.23
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

alpha = [2;1.5;1.25;1];
ls = ['--';'-b';'-.';':b'];
M = length(alpha);
b0=1;
b1=10;  

r=[0:0.01:2];

LLR = zeros(M,length(r));
for m=1:M
    LLR(m,:) = log(b0/b1)-(abs(r).^alpha(m))*(b1^(-alpha(m))-b0^(-alpha(m)));
end

figure(1)
for m=1:M
    plot(r,LLR(m,:),ls(m,:),'linewidth',1.5)
    hold on
end
hold off
xlabel('|R_i|')
ylabel('ln \Lambda(R_{i})')
legend(['\alpha=' num2str(alpha(1))],['\alpha=' num2str(alpha(2))],...
    ['\alpha=' num2str(alpha(3))],['\alpha=' num2str(alpha(4))],'location','Northwest')
axis([0 2 -2.5 2])
print -deps Fig2-2-23.eps

