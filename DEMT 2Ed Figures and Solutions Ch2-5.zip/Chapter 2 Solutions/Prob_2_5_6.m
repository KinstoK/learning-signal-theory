%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 2.5.6
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
clear all
%close all
% note: need to set states of both rand and randn for betarnd
t=1251;
rand('twister',t)  % set state of uniform random number generator
randn('seed',t)    % set state of normal random number generator
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numerical Parameter Setup
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------------------
% Beta Distribution Parameters
%-------------------------------------------------------------
a0=4;
b0=1;
a1=2;
b1=3;
N=10;

dx = 0.0001;
x= [dx/2:dx:1-dx/2];
pxiH0 = betapdf(x,a0,b0);
pxiH1 = betapdf(x,a1,b1);
 
figure(1)
clf
subplot(1,2,1)
plot(x,pxiH0,'linewidth',1.5)
xlabel('R_i')
ylabel('p(R_{i}|H_{0})')
title(['a_0=' int2str(a0) ',b_0=' int2str(b0)])
subplot(1,2,2)
plot(x,pxiH1,'linewidth',1.5)
xlabel('R_{i}')
ylabel('p(R_{i}|H_{1})')
title(['a_1=' int2str(a1) ',b_1=' int2str(b1)])
print -deps Fig2-5-6-a.eps

sp=0.7;
a_sp = sp*a1+(1-sp)*a0;
b_sp = sp*b1+(1-sp)*b0;

ptilt = betapdf(x,a_sp,b_sp);
figure(2)
clf
plot(x,ptilt,'linewidth',1.5)
xlabel('R_{i}')
ylabel('p(R_{i}|s_{*})')
title(['a_0=' int2str(a0) ',b_0=' int2str(b0) ',a_1=' int2str(a1) ',b_1=' int2str(b1)])

print -deps Fig2-5-6-b.eps

%-------------------------------------------------------------
% Importance Sampling Confidence Interval Parameters
%-------------------------------------------------------------
alpha = 0.1;                   % percent tolerance for CI
c=2;                            % CI SD 2:95.45%

%-------------------------------------------------------------
% mu(s) Parameters
%-------------------------------------------------------------
% plotting values
ds = 0.01;
s = [0:ds:1];
a_s = s*a1+(1-s)*a0;
b_s = s*b1+(1-s)*b0;

a10=a1-a0;
b10=b1-b0;
log_beta_0 = log(beta(a0,b0));
log_beta_1 = log(beta(a1,b1));


mu=N*(log(beta(a_s,b_s))-s*log_beta_1-(1-s)*log_beta_0);
mudot = N*(a10*psi(0,a_s)+b10*psi(0,b_s)-(a10+b10)*psi(0,a_s+b_s)-log_beta_1+log_beta_0);
muddot = N*(a10*a10*psi(1,a_s)+b10*b10*psi(1,b_s)-((a10+b10)^2)*psi(1,a_s+b_s));

PFapprox_s = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));
PMapprox_s = exp(mu+(1-s).*mudot+0.5*((1-s).^2).*muddot).*normcdf(-(1-s).*sqrt(muddot));

% simulation values
s = [[0.05:0.1:0.55] [0.6:0.05:0.8] [0.83:0.03:0.98]];
a_s = s*a1+(1-s)*a0;
b_s = s*b1+(1-s)*b0;
mu=N*(log(beta(a_s,b_s))-s*log_beta_1-(1-s)*log_beta_0);
mudot = N*(a10*psi(0,a_s)+b10*psi(0,b_s)-(a10+b10)*psi(0,a_s+b_s)-log_beta_1+log_beta_0);
muddot = N*(a10*a10*psi(1,a_s)+b10*b10*psi(1,b_s)-((a10+b10)^2)*psi(1,a_s+b_s));

gammat = mudot;

PFapprox = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));
PMapprox = exp(mu+(1-s).*mudot+0.5*((1-s).^2).*muddot).*normcdf(-(1-s).*sqrt(muddot));

IFapprox = exp(2*mu-2*s.*mudot+2*(s.^2).*muddot).*normcdf(-2*s.*sqrt(muddot));
IMapprox = exp(2*mu+2*(1-s).*mudot+2*((1-s).^2).*muddot).*normcdf(-2*(1-s).*sqrt(muddot));
KF = ceil(((c/alpha)^2)*(IFapprox-PFapprox.^2)./PFapprox.^2);
KM = ceil(((c/alpha)^2)*(IMapprox-PMapprox.^2)./PMapprox.^2);
Ksim = max([KF;KM]);

for n=1:length(s)
    IF_star =0;
    IM_star =0;
    D_star =0;
    A_star =0;
    K=Ksim(n);
    for k =1:K
        r_star = betarnd(a_s(n),b_s(n),1,N);
        l_star = N*log_beta_0-N*log_beta_1+a10*sum(log(r_star))+b10*sum(log(1-r_star));
        W0 = exp(mu(n)-s(n)*l_star);
        W1 = exp(mu(n)+(1-s(n))*l_star);
        D_star = D_star+(l_star>=gammat(n))*W0;
        A_star = A_star+(l_star<gammat(n))*W1;
        IF_star = IF_star+(l_star>=gammat(n))*W0^2;
        IM_star = IM_star+(l_star<gammat(n))*W1^2;
    end
    IFhat = IF_star/K;
    IMhat = IM_star/K;
    PFhat(n) = max(0,min(1,D_star/K));
    PMhat(n) = max(0,min(1,A_star/K));


    PFstar_var = (IFhat-PFhat(n)^2)/K;
    PFstar_sd(n) = sqrt(PFstar_var);
    alphahatF = c*PFstar_sd(n)/PFhat(n);
    PMstar_var = (IMhat-PMhat(n)^2)/K;
    PMstar_sd(n) = sqrt(PMstar_var);
    alphahatM = c*PMstar_sd(n)/PMhat(n);
end
%%
figure(3)
clf
semilogx(PFapprox_s,1-PMapprox_s,'-','linewidth',1.5)
xlabel('P_F')
ylabel('P_D')
hold on
semilogx(PFhat,1-PMhat,'--+','linewidth',1.5)
hold off
legend('Approx','Sim')
title(['N=' int2str(N) ',a_0=' int2str(a0) ',b_0=' int2str(b0) ',a_1=' int2str(a1) ',b_1=' int2str(b1)])

print -deps Fig2-5-6-c.eps
