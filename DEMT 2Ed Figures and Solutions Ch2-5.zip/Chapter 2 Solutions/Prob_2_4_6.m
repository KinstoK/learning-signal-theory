%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 2.4.6
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

alpha = [2;1.5;1.25;1];
ls = ['--';'-b';'-.';':b'];
lc = ['b';'r';'g';'k'];
M = length(alpha);
b0=1;
b1=10;
N=5;

s = [0.001:0.001:0.999];

PFapprox = zeros(M,length(s));
PMapprox = zeros(M,length(s));
for m=1:M
    mu = N*(s*log(b0)+(1-s)*log(b1)-(1/alpha(m))*log(s*b0^(alpha(m))+(1-s)*b1^(alpha(m))));
    mudot = N*(log(b0/b1)-(b0^(alpha(m))-b1^(alpha(m)))./(alpha(m)*(s*b0^(alpha(m))+(1-s)*b1^(alpha(m)))));
    muddot =(N/alpha(m))*((b0^(alpha(m))-b1^(alpha(m)))./(alpha(m)*(s*b0^(alpha(m))+(1-s)*b1^(alpha(m))))).^2;
    PFapprox(m,:) = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));
    PMapprox(m,:) = exp(mu+(1-s).*mudot+0.5*((1-s).^2).*muddot).*normcdf(-(1-s).*sqrt(muddot));
end

% Analytical solution for N=1
gammat=[0:0.05:20];
PF_1 = zeros(M,length(gammat));
PM_1 = zeros(M,length(gammat));
for m=1:M
    PF_1(m,:) = 1-gammainc((gammat/b0).^(alpha(m)),1/alpha(m));
    PM_1(m,:) = gammainc((gammat/b1).^(alpha(m)),1/alpha(m));
end

%%
figure(1)
for m=1:M
    if N<=2
    plot(PFapprox(m,:),1-PMapprox(m,:),ls(m,:),'linewidth',1.5)
    else
          semilogx(PFapprox(m,:),1-PMapprox(m,:),ls(m,:),'linewidth',1.5)
          xlim([1e-10 1])
    end
    hold on
    
end
hold off
legend(['\alpha=' num2str(alpha(1))],['\alpha=' num2str(alpha(2))],...
    ['\alpha=' num2str(alpha(3))],['\alpha=' num2str(alpha(4))],'location','southeast')
xlabel('P_F')
ylabel('P_D')
title(['N=' int2str(N)])
print -deps Fig2-4-6.eps

if N==1
    figure(2)
    for m=1:M
        plot(PF_1(m,:),1-PM_1(m,:),['--' lc(m,:)],'linewidth',1.5)
        hold on
        plot(PFapprox(m,:),1-PMapprox(m,:),['-' lc(m,:)],'linewidth',1.5)
        
    end
    hold off
    legend('Exact','Approx (0<s<1)','location','southeast')
    xlabel('P_F')
    ylabel('P_D')
end

