%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 2.4.5
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

s = [0.001:0.001:0.999];  

mu = log(gamma(s+1));
mudot = psi(0,s+1);
muddot = psi(1,s+1);

PFapprox = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));
PMapprox = exp(mu+(1-s).*mudot+0.5*((1-s).^2).*muddot).*normcdf(-(1-s).*sqrt(muddot));

PF = [0.001 [0.01:0.01:1]];
PM = gammainc(-log(PF),2);

%%
figure(1)
% semilogx(PFapprox,1-PMapprox,'-')
% hold on
%semilogx(PF,1-PM,'--')
plot(PF,1-PM,'--','linewidth',1.5)
hold on
plot(PFapprox,1-PMapprox,'-','linewidth',1.5)
hold off
legend('Exact','Approx (0<s<1)','location','northwest')
xlabel('P_F')
ylabel('P_D')


print -deps Fig2-4-5.eps

