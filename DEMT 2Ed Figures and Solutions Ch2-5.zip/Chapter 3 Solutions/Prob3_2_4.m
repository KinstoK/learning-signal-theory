%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3.2.4
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all 
close all

lw=1.5;

N=10;
SNR=1;                     % |b|^2/sigma_w^2
psia=[-1:0.01:1]*pi;
v0 = ones(N,1);
va = exp(-j*[0:1:N-1].'*psia);
Bc = real(v0'*va/N);
dsq = 2*N*SNR*Bc.^2;


figure(1)
h1=plot(psia/pi,dsq,'-','linewidth',lw);
hold on
xlabel('\psi_a/\pi')
ylabel('d^2')
title(['N=' int2str(N) ])
grid on
print -deps Fig3-2-4.eps

