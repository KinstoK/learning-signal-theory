%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3.2.6
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all 
close all

ls = ['--';'-b';'-.';':b'];
lw=1.5;

T=1;
N = [1:1:10];
dv_sigmaw = [0.5 1 2];
nd=length(dv_sigmaw);
Pe=zeros(nd,length(N));
figure(1)
for n=1:nd
    d=dv_sigmaw(n)*T*sqrt(N.*(N+1).*(2*N+1)/6);
    Pe(n,:) = normcdf(-d/2,0,1);
    semilogy(N,Pe(n,:),ls(n,:),'linewidth',lw)
    hold on
end
hold off
xlabel('N')
ylabel('Pr(\epsilon)')
ylim([1e-10 1])

legend(['{\Delta}v/\sigma_w=' num2str(dv_sigmaw(1))],...
    ['{\Delta}v/\sigma_w=' num2str(dv_sigmaw(2))],...
    ['{\Delta}v/\sigma_w=' num2str(dv_sigmaw(3))])
print -deps Fig3-2-6.eps


