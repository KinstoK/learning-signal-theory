%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3.2.1
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all 
close all

d = [0:0.01:9];
PF = [1e-1 1e-2 1e-3 1e-4 1e-6 1e-8 1e-10 1e-12 1e-14];
nF = length(PF);

for n1 = 1:nF
    zF = norminv(1-PF(n1),0,1);
    PD = 1-normcdf(zF-d);

    figure(1)
    plot(d,d-zF,'linewidth',1.5)
    hold on
    xlabel('d')
    ylabel('P_D')
    ylim(norminv([1e-4 0.9999]))
    set(gca,'Ytick',norminv([1e-4 1e-3 1e-2 0.1 0.3 0.5 0.7 0.9 0.98 0.99 0.999 0.9999]))
    set(gca,'YtickLabel',['      ';' 0.001';'  0.01';'   0.1';'   0.3';'   0.5';'   0.7';'   0.9';'  0.98';'  0.99';' 0.999';'0.9999'])
end
xlim([0 9])
set(gcf,'Position',[680 200 560 660])
set(gcf,'PaperPosition',[0.25 1.0 8 9])
hold off
h=text(1.45,0.5,'P_{F}=10^{-1}');
set(h,'Rotation',54)
h=text(2.5,0.5,'P_{F}=10^{-2}');
set(h,'Rotation',54)
h=text(3.23,0.5,'P_{F}=10^{-3}');
set(h,'Rotation',54)
h=text(3.9,0.5,'P_{F}=10^{-4}');
set(h,'Rotation',54)
h=text(4.95,0.5,'P_{F}=10^{-6}');
set(h,'Rotation',54)
h=text(5.7,0.5,'P_{F}=10^{-8}');
set(h,'Rotation',54)
h=text(6.5,0.5,'P_{F}=10^{-10}');
set(h,'Rotation',54)
h=text(7.2,0.5,'P_{F}=10^{-12}');
set(h,'Rotation',54)
h=text(7.85,0.5,'P_{F}=10^{-14}');
set(h,'Rotation',54)
print -deps Fig3-2-1.eps


