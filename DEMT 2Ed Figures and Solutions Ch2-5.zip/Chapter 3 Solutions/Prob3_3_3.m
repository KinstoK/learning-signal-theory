%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3.3.3
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
lw=1.5;

SNR = [1:1:100];                   % sigma_b^2/sigma_w^2
nS = length(SNR);
PF = [1e-4 1e-6].';
log10PF = log10(PF);

PD=exp(log(PF)*(1+SNR).^(-1));

figure(1)
plot(SNR,PD(1,:),'linewidth',lw)
hold on
plot(SNR,PD(2,:),'--','linewidth',lw)
hold off
xlabel('\sigma_b^2/\sigma_w^2')
ylabel('P_{D}')
legend('P_F=10^{-4}','P_F=10^{-6}','location','northwest')

print -deps Fig3-3-3-d.eps

s = [[0:0.01:1]];
ns = length(s);
PDapprox = zeros(2,nS);

for m=1:nS
    mu=zeros(1,ns);
    mudot=zeros(1,ns);
    muddot=zeros(1,ns);
    for q=1:ns
        tmp=1+(1-s(q))*SNR(m);
        mu(q) = (1-s(q))*log(1+SNR(m))-log(tmp);
        mudot(q) = -log(1+SNR(m))+SNR(m)/tmp;
        muddot(q) = (SNR(m)/tmp)^2;
        
    end
    
    log10PFapprox = (mu-s.*mudot+0.5*(s.^2).*muddot)*log10(exp(1))+log10(normcdf(-s.*sqrt(muddot)));
    idx=find(isfinite(log10PFapprox));
    log10PFapprox=log10PFapprox(idx);
    s=s(idx);
    ns=length(s);
    sopt = interp1(log10PFapprox,s,log10PF).';
    mu=zeros(1,2);
    mudot=zeros(1,2);
    muddot=zeros(1,2);
    for q=1:2
        tmp=1+(1-sopt(q))*SNR(m);
        mu(q) = (1-sopt(q))*log(1+SNR(m))-log(tmp);
        mudot(q) = -log(1+SNR(m))+SNR(m)/tmp;
        muddot(q) = (SNR(m)/tmp)^2;
    end
    log10PFapprox = (mu-sopt.*mudot+0.5*(sopt.^2).*muddot)*log10(exp(1))+log10(normcdf(-sopt.*sqrt(muddot)));
    PDapprox(:,m) = 1-(exp(mu+(1-sopt).*mudot+0.5*((1-sopt).^2).*muddot).*normcdf(-(1-sopt).*sqrt(muddot))).';
end
%%
 figure(2)
 subplot(2,1,1)
 plot(SNR,PDapprox(1,:),'--','linewidth',lw)
 hold on
 plot(SNR,PD(1,:),'-','linewidth',lw)
hold off
 axis([0 100 0 1])
 xlabel('\sigma_b^2/\sigma_w^2')
 ylabel('P_{D}')
 legend('approx','exact','location','southeast')
 title('P_F=10^{-4}')
 
 subplot(2,1,2)
 plot(SNR,PDapprox(2,:),'--','linewidth',lw)
 hold on
plot(SNR,PD(2,:),'-','linewidth',lw)
hold off
 axis([0 100 0 1])
 xlabel('\sigma_b^2/\sigma_w^2')
 ylabel('P_{D}')
 legend('approx','exact','location','southeast')
 title('P_F=10^{-6}')

 print -deps Fig3-3-3-e.eps

