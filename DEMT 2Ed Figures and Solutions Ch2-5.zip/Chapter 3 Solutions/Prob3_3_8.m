%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3.3.8
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
lw=1.5;

NSNR = [0.25 1 4 10];                   % N sigma_b^2/sigma_w^2
nS = length(NSNR);
K=[4 2 1];
nk = length(K);
thresh = [0:0.1:10];
nt = length(thresh);



PF = zeros(nk,nt);
PD = zeros(nk,nS,nt);
for k=1:nk
    PF(k,:) = gammainc(thresh,K(k),'upper');
    for n=1:nS
        threshD = thresh/(1+NSNR(n));
        PD(k,n,:) = gammainc(threshD,K(k),'upper');
    end
end



figure(1)
for m=1:nS
    subplot(2,2,m)
    plot(PF(1,:),squeeze(PD(1,m,:)),'--','linewidth',lw)
    hold on
    plot(PF(2,:),squeeze(PD(2,m,:)),'-.','linewidth',lw)
    plot(PF(3,:),squeeze(PD(3,m,:)),'-','linewidth',lw)
    hold off
    xlabel('P_{F}')
    ylabel('P_{D}')
    title(['N*SNR=' num2str(NSNR(m))])
    legend(['K= ' int2str(K(1))],...
        ['K= ' int2str(K(2))],['K= ' int2str(K(3))],...
        'location','southeast')
end

print -deps Fig3-3-8.eps


