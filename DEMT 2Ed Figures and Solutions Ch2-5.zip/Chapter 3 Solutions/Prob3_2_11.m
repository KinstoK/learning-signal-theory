%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3.2.11
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all
close all
lw=1.5;

SINR=1;                     % |Delta m|^2/(sigma_I^{2}+sigma_w^2)
N=3;
rho=[[0:0.01:0.99] 0.999];
nr = length(rho);
INR = [1 100];
nI = length(INR);

% (a) given mean vector
Delta_m = (1/sqrt(N))*ones(N,1);
Delta_m_sq=Delta_m'*Delta_m;
dsqmin = zeros(1,nr);
dsqmax = zeros(1,nr);
dsq = zeros(1,nr);
for m=1:nI
    sigmaw2 = 1/(SINR*(1+INR(m)));
    sigmaI2 = INR(m)*sigmaw2;
    for n=1:nr
        KI=toeplitz(rho(n).^[0:1:N-1]);
        K = sigmaw2*eye(N)+sigmaI2*KI;
        Q = inv(K);
        dsq(m,n) = Delta_m.'*Q*Delta_m;
        [u,lam]=eig(KI);                             % eigendecomposition
        [lam,ind]=sort(diag(lam),'descend');        % sort eigenvalues in descending order
        dsqmax(m,n) = Delta_m_sq/(sigmaw2+sigmaI2*lam(N));
        dsqmin(m,n) = Delta_m_sq/(sigmaw2+sigmaI2*lam(1));
    end
end

figure(1)
h1=semilogy(abs(rho),dsqmax,'-.','linewidth',lw);
hold on
h3=semilogy(abs(rho),dsq,'-','linewidth',lw);
h2=semilogy(abs(rho),dsqmin,'--','linewidth',lw);
hold off
xlabel('|\rho|')
ylabel('d^2')
legend([h1(1) h3(1) h2(1)],'d^{2}_{max}','d^{2}','d^{2}_{min}','location','northwest')
ylim([0.1 100])
text(1.01,0.32,'\sigma_{I}^{2}/\sigma_{w}^{2}=100')
text(1.01,0.5,'\sigma_{I}^{2}/\sigma_{w}^{2}=1')
text(1.01,100,'\sigma_{I}^{2}/\sigma_{w}^{2}=100')
text(1.01,2,'\sigma_{I}^{2}/\sigma_{w}^{2}=1')

print -deps Fig3-2-11-a.eps


% (b) optimum mean vextor
dsqopt = zeros(1,nr);
for m=1:nI
    sigmaw2 = 1/(SINR*(1+INR(m)));
    sigmaI2 = INR(m)*sigmaw2;
    for n=1:nr
        KI=toeplitz(rho(n).^[0:1:N-1]);
        K = sigmaw2*eye(N)+sigmaI2*KI;
        Q = inv(K);
        [u,lam]=eig(KI);                            % eigendecomposition
        [lam,ind]=sort(diag(lam),'descend');        % sort eigenvalues in descending order
        Delta_m = u(:,ind(N));                           % eigenvector with smallest eigenvalue
        dsqopt(m,n) = Delta_m.'*Q*Delta_m;
    end
end

figure(2)
h1=semilogy(abs(rho),dsqmax,'-.','linewidth',lw);
hold on
h3=semilogy(abs(rho),dsqopt,'-','linewidth',lw);
h2=semilogy(abs(rho),dsqmin,'--','linewidth',lw);
hold off
xlabel('|\rho|')
ylabel('d^2')
legend([h1(1) h3(1) h2(1)],'d^{2}_{max}','d^{2}_{opt}','d^{2}_{min}','location','northwest')
ylim([0.1 100])
text(1.01,0.32,'\sigma_{I}^{2}/\sigma_{w}^{2}=100')
text(1.01,0.5,'\sigma_{I}^{2}/\sigma_{w}^{2}=1')
text(1.01,100,'\sigma_{I}^{2}/\sigma_{w}^{2}=100')
text(1.01,2,'\sigma_{I}^{2}/\sigma_{w}^{2}=1')

print -deps Fig3-2-11-b.eps
