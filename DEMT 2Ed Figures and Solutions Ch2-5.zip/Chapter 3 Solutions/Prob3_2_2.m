%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3.2.2
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all 
close all


X = [0:0.01:10];
Pe = normcdf(-sqrt(X),0,1);
figure(1)
semilogy(X,Pe,'linewidth',1.5)
hold on
xlabel('E/\sigma_{w}^{2}')
ylabel('Pr(\epsilon)')
ylim([1e-3 1])

print -deps Fig3-2-2.eps


