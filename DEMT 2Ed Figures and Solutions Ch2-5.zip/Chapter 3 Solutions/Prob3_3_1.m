%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3.3.1
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
lw=1.5;

N=10;
sigmaw2=1;                        % sigma_w^2
SNR = [1 3 10];                   % sigma_s^2/sigma_w^2
nS = length(SNR);
rho=[0.3 0.7 0.9];
nr = length(rho);
s = [0:0.01:1];
ns = length(s);
PFapprox = zeros(nr,nS,ns);
PMapprox = zeros(nr,nS,ns);
K0 = sigmaw2*eye(N);
lndetK0 = N*log(sigmaw2);

for n=1:nr
    K = toeplitz(rho(n).^[0:1:N-1]);
    
    for m=1:nS
        sigmas2=SNR(m)*sigmaw2;
        K1=sigmas2*K+K0;
        lndetK1 = log(det(K1));
        mu=zeros(1,ns);
        mudot=zeros(1,ns);
        muddot=zeros(1,ns);
        
        for q=1:ns
            Ks = s(q)*K0+(1-s(q))*K1;
            lndetKs = log(det(Ks));
            Ks_K1_K0 = inv(Ks)*(K1-K0);
            mu(q) = 0.5*(s(q)*lndetK0+(1-s(q))*lndetK1-lndetKs);
            mudot(q) = 0.5*(lndetK0-lndetK1+trace(Ks_K1_K0));
            muddot(q) = 0.5*trace(Ks_K1_K0*Ks_K1_K0);
            
        end % q
        PFapprox(n,m,:) = exp(mu-s.*mudot+0.5*(s.^2).*muddot).*normcdf(-s.*sqrt(muddot));
        PMapprox(n,m,:) = exp(mu+(1-s).*mudot+0.5*((1-s).^2).*muddot).*normcdf(-(1-s).*sqrt(muddot));
        
    end  % m
end %n

figure(1)
for m=1:nS
    subplot(2,2,m)
    plot(squeeze(PFapprox(1,m,:)),1-squeeze(PMapprox(1,m,:)),'--','linewidth',lw)
    hold on
    plot(squeeze(PFapprox(2,m,:)),1-squeeze(PMapprox(2,m,:)),'-.','linewidth',lw)
    plot(squeeze(PFapprox(3,m,:)),1-squeeze(PMapprox(3,m,:)),'-','linewidth',lw)
    hold off
    xlabel('P_{F}')
    ylabel('P_{D}')
    axis([0 0.5 0.5 1])
    title(['N=' int2str(N) ', SNR=' num2str(SNR(m))])
    legend(['\rho= ' num2str(abs(rho(1)))],...
        ['\rho= ' num2str(abs(rho(2)))],['\rho= ' num2str(abs(rho(3)))],...
        'location','southeast')
end

 subplot(2,2,3)
  axis([0 0.5 0.9 1])
print -deps Fig3-3-1.eps


