function [omega1_hat,omega2_hat]=TwoComplexExponentialsAP(x,L)
% TwoComplexExponentialsAP.m
%
% AP implementation of MLE for two complex exponentials
%
% K. Bell 5/4/14
%
% Inputs:
%   x: 1xN complex data samples
%   L: FFT size.  Freq resolution = 2*pi/L

N=length(x);

k = [0:1:N-1];
freq = 2*pi*[-(L/2):1:(L/2)-1]/L;

v=exp(j*(k.'*freq));         % NxL "frequency response" vectors

F = fft(x,L);
F = fftshift(F);              % 1xL

% initialize
A1 = N*abs(F).^2;             % 1xL

[val1,n1]=max(A1);
omega1_hat = freq(n1);

Bn1 = v(:,n1)'*v;
Dn1 = N^2-abs(Bn1).^2;
A12n1 = 2*real((F(n1)'*F).*Bn1);
T= (A1(n1)+A1-A12n1)./Dn1;
T(n1)=-Inf;

[val2,n2]=max(T);
omega2_hat=freq(n2);
if n2<n1
    omega1_hat=freq(n2);
    omega2_hat=freq(n1);
    tmp=n1;
    n1=n2;
    n2=tmp;
end


% iterate
converged = false;
n=1;
n1old=n1;
n2old=n2;
while ~converged
    n=n+1;
    
    Bn2 = v(:,n2)'*v;
    Dn2 = N^2-abs(Bn2).^2;
    A12n2 = 2*real((F(n2)'*F).*Bn2);
    T1= (A1(n2)+A1-A12n2)./Dn2;
    T1(n2)=-Inf;
    [val1,n1]=max(T1);
    omega1_hat(n)=freq(n1);
    
    Bn1 = v(:,n1)'*v;
    Dn1 = N^2-abs(Bn1).^2;
    A12n1 = 2*real((F(n1)'*F).*Bn1);
    T2= (A1(n1)+A1-A12n1)./Dn1;
    T2(n1)=-Inf;
    [val2,n2]=max(T2);
    omega2_hat(n)=freq(n2);
    
    if n1==n1old & n2==n2old
        converged=true;
    else
        n1old=n1;
        n2old=n2;
    end
end
