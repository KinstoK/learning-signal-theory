%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 5.24
% Example 5.20 MAP estimation of Gaussian Variance, Inverse gamma prior
% RMSE and bounds
% K. Bell
% 5/4/14
% saves/loads Fig5_24_data.mat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

runsim = 0;      % 1 to run simulation, 0 to use saved data

mu = 0;                   % zero mean
alpha = 5;
beta = 1;

N = [2 5 10 20 50 100 200 500 1000 2000 5000 10000];
nN = length(N);

c = [0:0.1:11];
nc = length(c);

if runsim
    M = 5000;                  % Monte Carlo trials
    
    randn('state',500)
    rand('state',100)
    
    sigma2_sv = zeros(1,nN);       % sample variance, sigma^2
    
    %     % set up numerical integration
    %     dt = 0.0001;
    %     th = [0+dt/2:dt:1-dt/2];
    %     N = length(th);
    %     C = gamma(2*a)/(gamma(a)^2);
    %     pth = C*((th.*(1-th)).^(a-1));         % p(theta)
    
    for k=1:nN
        n = N(k)
        
        sigma2_ML = zeros(1,M);
        sigma2_MAP = zeros(1,M);
        sigma2_MSE = zeros(1,M);
        for m=1:M
            tmp = gamrnd(alpha,1/beta);        % gamma random value
            sigma2(m) = 1/tmp;                   % sigma^2 = inverse Gamma RV
            x = randn(1,N(k))*sqrt(sigma2(m));          % data
            sk = sum(x.^2)/N(k);
            sigma2_ML(m) = sk;                                 % MLE
            sigma2_MAP(m) = (2*beta/N(k)+sk)/((alpha+1)*2/N(k)+1);   % MAP
            sigma2_MSE(m) = (2*beta/N(k)+sk)/((alpha-1)*2/N(k)+1);                  % MSE
        end
        errML = sigma2_ML-sigma2;
        errML_sm(k) = sum(errML)/M;                     % average error over trials
        errML_sv(k) = sum((errML-errML_sm(k)).^2)/M;    % sample variance of error over trials
        errML_mse(k) = sum(errML.^2)/M;                 % mse of error over trials
        errMAP = sigma2_MAP-sigma2;
        errMAP_sm(k) = sum(errMAP)/M;                   % average error over trials
        errMAP_sv(k) = sum((errMAP-errMAP_sm(k)).^2)/M; % sample variance of error over trials
        errMAP_mse(k) = sum(errMAP.^2)/M;               % mse of error over trials
        errMSE = sigma2_MSE-sigma2;
        errMSE_sm(k) = sum(errMSE)/M;                   % average error over trials
        errMSE_sv(k) = sum((errMSE-errMSE_sm(k)).^2)/M; % sample variance of error over trials
        errMSE_mse(k) = sum(errMSE.^2)/M;               % mse of error over trials
        figure(3)
        subplot(2,1,1)
        plot(sigma2_MAP,sigma2_MSE,'.')
        hold on
        plot([0 15],[0 15],'k')
        hold off
        subplot(2,1,2)
        plot(sigma2_MAP,sigma2_ML,'.')
        hold on
        plot([0 15],[0 15],'k')
        hold off
        
        pause
    end
    save Fig5_24_data N M errML_sm errMAP_sm errMSE_sm errML_mse errMAP_mse errMSE_mse
else
    load Fig5_24_data
end

ECRB_sigma2 = zeros(1,nN);     % ECRB, sigma^2
BCRB_sigma2 = zeros(1,nN);     % BCRB, sigma^2

for k=1:nN
    ECRB_sigma2(k) = ((beta^2)/((alpha-1)*(alpha-2)))*2/N(k);            % ECRB
    BCRB_sigma2(k) =  (beta^2)/((alpha)*(alpha+1)*(alpha+3+N(k)/2));  % BCRB
end


%--------------------
% RMSE, ECRB, BCRB vs SNR Fig 2 (a=5)
%--------------------
figure(1)
loglog(N,sqrt(ECRB_sigma2),'--r','Linewidth',lw)
hold on
loglog(N,sqrt(BCRB_sigma2),'-b','Linewidth',lw)
loglog(N,sqrt(errML_mse),'*g','Linewidth',lw)
loglog(N,sqrt(errMAP_mse),'om','Linewidth',lw)
loglog(N,sqrt(errMSE_mse),'+c','Linewidth',lw)
hold off
grid on
set(gca,'XTick',10.^([0:1:4]))
set(gca,'XMinorGrid','off')
set(gca,'YMinorGrid','off')
legend('ECRB','BCRB','ML Sim.','MAP Sim.','MMSE Sim.')
xlabel('N','Fontsize',FS)
ylabel('RMSE','Fontsize',FS)
%axis([1 10000 5e-3 1])
set(gca,'Fontsize',FS)
print -deps Fig5-24.eps

%--------------------
% Bias vs SNR
%--------------------
figure(2)
semilogx(N,errML_sm,'*g','Linewidth',lw)
hold on
semilogx(N,errMAP_sm,'om','Linewidth',lw)
semilogx(N,errMSE_sm,'+c','Linewidth',lw)
hold off
legend('ML Sim.','MAP Sim.')
xlabel('N','Fontsize',FS)
ylabel('Bias','Fontsize',FS)
title('\theta= \sigma^2')
%axis([1 10000 -0.03 0.03])
set(gca,'Fontsize',FS)

