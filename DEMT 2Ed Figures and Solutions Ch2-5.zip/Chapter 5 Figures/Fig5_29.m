%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 5.29
% Example 5.24 scalar sequential
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

K=30;
SNRdB = [10:-10:-10];
SNR = 10.^(SNRdB/10);
nsnr=length(SNR);
Sigma = zeros(nsnr,K+1);

sigmaw2=1;
for n=1:3
    Sigma(n,1) = SNR(n)*sigmaw2;
     Sigma2(n,1) = SNR(n)*sigmaw2;
    for k=1:K
    G=Sigma(n,k)/(Sigma(n,k)+sigmaw2);
    Sigma(n,k+1)=(1-G)*Sigma(n,k);
    Sigma2(n,k+1)=SNR(n)*sigmaw2*sigmaw2/(k*SNR(n)*sigmaw2+sigmaw2);
    end
end

figure(1)
plot([0:1:K],10*log10(Sigma(1,:)/sigmaw2),'-','linewidth',lw)
hold on
plot([0:1:K],10*log10(Sigma(2,:)/sigmaw2),'--','linewidth',lw)
plot([0:1:K],10*log10(Sigma(3,:)/sigmaw2),'-.','linewidth',lw)
xlabel('k','Fontsize',FS)
ylabel('\Sigma(k)/\sigma_{w}^{2} (dB)','Fontsize',FS)
set(gca,'Fontsize',FS)
hold off
legend(['SNR=' num2str(SNRdB(1)) ' dB'],['SNR=' num2str(SNRdB(2)) ' dB'],['SNR=' num2str(SNRdB(3)) ' dB'],'location','northeast')
print -deps Fig5-29.eps

