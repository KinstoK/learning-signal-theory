function [omega1_hat,omega2_hat]=TwoComplexExponentialsEM(x,L)
% TwoComplexExponentialsEM.m
%
% EM implementation of MLE for two complex exponentials
%
% K. Bell 5/4/14
%
% Inputs:
%   x: 1xN complex data samples
%   L: FFT size.  Freq resolution = 2*pi/L

N=length(x);

k = [0:1:N-1];
freq = 2*pi*[-(L/2):1:(L/2)-1]/L;

v=exp(j*(k.'*freq));         % NxL "frequency response" vectors

F = fft(x,L);
F = fftshift(F);              % 1xL

% initialize
A1 = N*abs(F).^2;             % 1xL

[val1,n1]=max(A1);
omega1_hat = freq(n1);

Bn1 = v(:,n1)'*v;
Dn1 = N^2-abs(Bn1).^2;
A12n1 = 2*real((F(n1)'*F).*Bn1);
T= (A1(n1)+A1-A12n1)./Dn1;
T(n1)=-Inf;

[val2,n2]=max(T);
omega2_hat=freq(n2);
if n2<n1
    omega1_hat=freq(n2);
    omega2_hat=freq(n1);
    tmp=n1;
    n1=n2;
    n2=tmp;
end
R=x.';
V=v(:,[n1 n2]);
b=inv(V'*V)*V'*R;


% iterate
converged = false;
n=1;
n1old=n1;
n2old=n2;
while ~converged
    n=n+1;
%    [n1 n2]
    V=v(:,[n1 n2]);

    W = R-V*b;
    Y1 = V(:,1)*b(1)+0.5*W;
    Y2 = V(:,2)*b(2)+0.5*W;
    F1 = fft(Y1,L);
    F1 = fftshift(F1);              % 1xL
    F1a=abs(F1);
    [val1,n1]=max(F1a);
%    n1
    omega1_hat(n) = freq(n1);
    b(1) = F1(n1)/N;
%     figure(2)
%     subplot(2,1,1)
%     plot(freq,F1a)
%     hold on
%     plot(freq(n1),val1,'*r')
%     hold off
    
    
    F2 = fft(Y2,L);
    F2 = fftshift(F2);              % 1xL
    F2a=abs(F2);
    [val2,n2]=max(F2a);
%    n2
    omega2_hat(n) = freq(n2);
     b(2) = F2(n2)/N;

%     subplot(2,1,2)
%     plot(freq,F2a)
%     hold on
%     plot(freq(n2),val2,'*r')
%     hold off
    if n1==n1old & n2==n2old
        converged=true;
    else
        n1old=n1;
        n2old=n2;
    end
end
