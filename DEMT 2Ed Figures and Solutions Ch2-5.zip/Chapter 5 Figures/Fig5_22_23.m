%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 5.22, 5.23
% Examples 5.17, 5.18
% Sensor perturbations and DL
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;
runSim=0;

%------------------------------------------
% Array
%------------------------------------------
N=10;   % Number of elements
d_lambda = 0.5;
DN = [-(N-1)/2:1:(N-1)/2].';       % uniformly spaced linear array, half wavelength
D = DN*d_lambda;                   % uniformly spaced linear array, half wavelength
sigma_d = 0.15;                    % perturbation st. dev. wrt spacing (d)

%------------------------------------------
% Signal and Interference
%------------------------------------------
psi_s = 0.5*pi;
SNRdB = 0;
SNR = 10^(SNRdB/10);
vs = exp(-j*DN*psi_s);
bs = sqrt(SNR)*exp(j*0);
xis2 = exp(-(psi_s*sigma_d)^2);
xis = sqrt(xis2);

INRdB =30;
INR = 10^(INRdB/10);
NINR = N*INR;
alpha = NINR/(NINR+1);

%------------------------------------------
% Calcs
%------------------------------------------

wCBF = vs/N;
wnormCBF = real(wCBF'*wCBF);
Vwn_CBF = wnormCBF;

psi_I = [-1:0.001:1]*pi;
vI = exp(-j*DN*psi_I);
BcI = wCBF'*vI;
BcIsq = abs(BcI).^2;

V_CBF = wnormCBF+INR*BcIsq;
V_MLE = 1./(N*(1-BcIsq*NINR/(NINR+1)));                     % same as CRB
wnorm = (1-(2*alpha-alpha^2)*BcIsq)./(N*(1-alpha*BcIsq).^2);


%%

nI = length(psi_I);
T = 500; %trials
DL = 1000;

bias_CBF = zeros(1,nI);
bias_ML = zeros(1,nI);
bias_DL = zeros(1,nI);
bias_BL = zeros(1,nI);
wnormML = zeros(1,nI);
wnormDL = zeros(1,nI);
wnormBL = zeros(1,nI);
Vwn_ML = zeros(1,nI);
Vwn_DL = zeros(1,nI);
Vwn_BL = zeros(1,nI);
VI_CBF = zeros(1,nI);
VI_ML = zeros(1,nI);
VI_DL = zeros(1,nI);
VI_BL = zeros(1,nI);
Vs_CBF = zeros(1,nI);
Vs_ML = zeros(1,nI);
Vs_DL = zeros(1,nI);
Vs_BL = zeros(1,nI);

VI_CBF_sim = zeros(1,nI);
VI_ML_sim = zeros(1,nI);
VI_DL_sim = zeros(1,nI);
VI_BL_sim = zeros(1,nI);

BL = zeros(1,nI);
DL2 = zeros(1,nI);
NT0=3;
xiI2 = exp(-(psi_I*sigma_d).^2);
for n=1:nI
    Kn = eye(N)+INR*vI(:,n)*vI(:,n)';
    Kninv=inv(Kn);
    wML = (Kninv*vs)/(vs'*Kninv*vs);
    BL(n) = ((1+INR)*(1-xiI2(n))+SNR*(1-xis2))/xiI2(n);
    KIBL = Kn+BL(n)*eye(N);
    KIBLinv=inv(KIBL);
    wBLUE = (KIBLinv*vs)/(xis*vs'*KIBLinv*vs);
    KIDL = Kn+DL*eye(N);
    KIDLinv=inv(KIDL);
    wMLDL = (KIBLinv*vs)/(vs'*KIBLinv*vs);
    wMSE = (KIBLinv*vs)*(SNR*xis/xiI2(n))/(1+(SNR*xis2/xiI2(n))*vs'*KIBLinv*vs);
    wnormML(n)=real(wML'*wML);
    
    Qlim =NT0/(1-xiI2(n));
    if  wnormML(n)*N>= Qlim
        a=min(roots([BcIsq(n)*(Qlim*BcIsq(n)-1) -2*BcIsq(n)*(Qlim-1) (Qlim-1)]) );
        DL2(n)=NINR*(1-a)/a-1;
    end
    KIDL = Kn+DL2(n)*eye(N);
    KIDLinv=inv(KIDL);
    wMLDL = (KIDLinv*vs)/(vs'*KIDLinv*vs);
    wnormDL(n)=real(wMLDL'*wMLDL);
    wnormBL(n)=real(wBLUE'*wBLUE);
    wnormMS(n)=real(wMSE'*wMSE);
    
    
    bias_CBF(n) = bs*(xis*wCBF'*vs-1);
    bias_ML(n)  = bs*(xis*wML'*vs-1);
    bias_DL(n)  = bs*(xis*wMLDL'*vs-1);
    bias_BL(n)  = bs*(xis*wBLUE'*vs-1);
    bias_MS(n)  = bs*(xis*wMSE'*vs-1);
    Vwn_ML(n) = wnormML(n);
    Vwn_DL(n) = wnormDL(n);
    Vwn_BL(n) = wnormBL(n);
    Vwn_MS(n) = wnormMS(n);
    VI_CBF(n) = INR*(xiI2(n)*(abs(wCBF'*vI(:,n))^2) +(1-xiI2(n))*wnormCBF);
    VI_ML(n)  = INR*(xiI2(n)*(abs(wML'*vI(:,n))^2)  +(1-xiI2(n))*wnormML(n));
    VI_DL(n)  = INR*(xiI2(n)*(abs(wMLDL'*vI(:,n))^2)+(1-xiI2(n))*wnormDL(n));
    VI_BL(n)  = INR*(xiI2(n)*(abs(wBLUE'*vI(:,n))^2)+(1-xiI2(n))*wnormBL(n));
    VI_MS(n)  = INR*(xiI2(n)*(abs(wMSE'*vI(:,n))^2)+(1-xiI2(n))*wnormMS(n));
    Vs_CBF(n) = SNR*(1-xis2)*wnormCBF;
    Vs_ML(n)  = SNR*(1-xis2)*wnormML(n);
    Vs_DL(n)  = SNR*(1-xis2)*wnormDL(n);
    Vs_BL(n)  = SNR*(1-xis2)*wnormBL(n);
    Vs_MS(n)  = SNR*(1-xis2)*wnormMS(n);
    
    if runSim
        sI = sqrt(INR/2)*(randn(1,T)+j*randn(1,T));  % 1xK interference signal
        nn = sqrt(1/2)*(randn(N,T)+j*randn(N,T));    % NxK noise signals
        R = zeros(N,T);
        for t=1:T
            Dp = D+sigma_d*d_lambda*randn(N,1);
            DNp = Dp/d_lambda;
            vsp(:,t) = exp(-j*DNp*psi_s);
            vIp(:,t) = exp(-j*DNp*psi_I(n));
        end
        R = vsp*bs+vIp.*repmat(sI,N,1)+nn;                                        % Nx1 freq domain data
        VI_CBF_sim(n)=INR*sum(abs(wCBF'*vIp).^2)/T;
        VI_ML_sim(n) =INR*sum(abs(wML'*vIp).^2)/T;
        VI_DL_sim(n) =INR*sum(abs(wMLDL'*vIp).^2)/T;
        VI_BL_sim(n) =INR*sum(abs(wBLUE'*vIp).^2)/T;
        VI_MS_sim(n) =INR*sum(abs(wMSE'*vIp).^2)/T;
        shatML  = wML'*R;
        shatDL  = wMLDL'*R;
        shatCBF = wCBF'*R;
        shatBL  = wBLUE'*R;
        shatMS  = wMSE'*R;
        muBL(n) = sum(shatBL)/T;
        muML(n) = sum(shatML)/T;
        muDL(n) = sum(shatDL)/T;
        muCBF(n)= sum(shatCBF)/T;
        muMS(n)= sum(shatMS)/T;
        varML(n) = sum(abs(shatML-muML(n)).^2)/T;
        varBL(n) = sum(abs(shatBL-muBL(n)).^2)/T;
        varDL(n) = sum(abs(shatDL-muDL(n)).^2)/T;
        varCBF(n)= sum(abs(shatCBF-muCBF(n)).^2)/T;
        varMS(n)= sum(abs(shatMS-muMS(n)).^2)/T;
    end % if runSim
end
if runSim
    mseBL = varBL+abs(muBL-bs).^2;
    mseML = varML+abs(muML-bs).^2;
    mseDL = varDL+abs(muDL-bs).^2;
    mseCBF = varCBF+abs(muCBF-bs).^2;
    mseMS = varCBF+abs(muMS-bs).^2;
end

VTOT_CBF = Vwn_CBF+VI_CBF+Vs_CBF;
VTOT_ML = Vwn_ML+VI_ML+Vs_ML;
VTOT_DL = Vwn_DL+VI_DL+Vs_DL;
VTOT_BL = Vwn_BL+VI_BL+Vs_BL;
VTOT_MS = Vwn_MS+VI_MS+Vs_MS;
MSE_CBF = VTOT_CBF+abs(bias_CBF).^2;
MSE_ML = VTOT_ML+abs(bias_ML).^2;
MSE_DL = VTOT_DL+abs(bias_DL).^2;
MSE_BL = VTOT_BL+abs(bias_BL).^2;
MSE_MS = VTOT_MS+abs(bias_MS).^2;

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Variances
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fig=1;
figure(fig)
subplot(2,1,1)
plot(psi_I/pi,10*log10(V_MLE),'-','linewidth',lw)
hold on
plot(psi_I/pi,10*log10(V_CBF),':','linewidth',lw)
plot(psi_I/pi,10*log10(VTOT_ML),'--','linewidth',lw)
plot(psi_I/pi,10*log10(VTOT_CBF),'-.','linewidth',lw)
hold off
legend('MLE nom','CBF nom','MLE pert','CBF pert','location','northwest')
ylabel('10 log10{var(b_{s})}','Fontsize',FS)
title(['N=' int2str(N) ', \psi_{s}/\pi=' num2str(psi_s/pi) ...
    ', INR=' num2str(INRdB) ' dB, \sigma_d=' num2str(sigma_d)])
set(gca,'Fontsize',FS)
ylim([-15 50])
subplot(2,1,2)
plot(psi_I/pi,10*log10(wnorm),'-','linewidth',lw)
hold on
plot([-1 1],10*log10(wnormCBF)*[1 1],':','linewidth',lw)
hold off
legend('MLE','CBF','location','northwest')
ylabel('10 log10(|h|^2)','Fontsize',FS)
xlabel('\psi_{I}/\pi','Fontsize',FS)
set(gca,'Fontsize',FS)
ylim([-15 30])
print -deps Fig5-22.eps;

fig=fig+1;

figure(fig)
subplot(2,1,1)
plot(psi_I/pi,10*log10(VTOT_ML),'--','linewidth',lw)
hold on
plot(psi_I/pi,10*log10(VTOT_CBF),'-.','linewidth',lw)
plot(psi_I/pi,10*log10(VTOT_DL),'-','linewidth',lw)
hold off
legend('MLE pert','CBF pert','MLE DL pert','location','northwest')
ylabel('10 log10{var(b_{s})}','Fontsize',FS)
title(['N=' int2str(N) ', \psi_{s}/\pi=' num2str(psi_s/pi) ...
    ', INR=' num2str(INRdB) ' dB, \sigma_d=' num2str(sigma_d)])
set(gca,'Fontsize',FS)
ylim([-15 50])
subplot(2,1,2)
plot(psi_I/pi,10*log10(wnorm),'--','linewidth',lw)
hold on
plot([-1 1],10*log10(wnormCBF)*[1 1],'-.','linewidth',lw)
plot(psi_I/pi,10*log10(wnormDL),'-','linewidth',lw)
hold off
legend('MLE','CBF','MLE DL','location','northwest')
ylabel('10 log10(|h|^2)','Fontsize',FS)
xlabel('\psi_{I}/\pi','Fontsize',FS)
set(gca,'Fontsize',FS)
ylim([-15 30])
print -deps Fig5-23.eps;

fig=fig+1;
figure(fig)
plot(psi_I/pi,10*log10(V_MLE),'--r','linewidth',lw)
hold on
plot(psi_I/pi,10*log10(V_CBF),'--k','linewidth',lw)
plot(psi_I/pi,10*log10(MSE_ML),'-r','linewidth',lw)
plot(psi_I/pi,10*log10(MSE_DL),'-g','linewidth',lw)
plot(psi_I/pi,10*log10(MSE_CBF),'-c','linewidth',lw)
plot(psi_I/pi,10*log10(MSE_BL),'-b','linewidth',lw)
plot(psi_I/pi,10*log10(MSE_MS),'-m','linewidth',lw)
if runSim
    plot(psi_I/pi,10*log10(mseML),'-r','linewidth',lw)
    plot(psi_I/pi,10*log10(mseDL),'-g','linewidth',lw)
    plot(psi_I/pi,10*log10(mseCBF),'-c','linewidth',lw)
    plot(psi_I/pi,10*log10(mseBL),'-b','linewidth',lw)
    plot(psi_I/pi,10*log10(mseMS),'-m','linewidth',lw)
    plot(psi_I/pi,10*log10(varML),'-r','linewidth',lw)
    plot(psi_I/pi,10*log10(varDL),'-g','linewidth',lw)
    plot(psi_I/pi,10*log10(varCBF),'-c','linewidth',lw)
    plot(psi_I/pi,10*log10(varBL),'-b','linewidth',lw)
    plot(psi_I/pi,10*log10(varMS),'-m','linewidth',lw)
end
hold off
legend('MLE Nom','CBF Nom','MLE','UDL','CBF','BLUE','MSE','location','northwest')
ylabel('10 log10{var(b_{s})}','Fontsize',FS)
title(['N=' int2str(N) ',\psi_{s}=' num2str(psi_s/pi) '\pi, INR=' num2str(INRdB) ' dB, SNR = ' num2str(SNRdB) ' dB'])
xlabel('\psi_{I}/\pi','Fontsize',FS)
set(gca,'Fontsize',FS)
grid on



%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weight vector norms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fig=fig+1;
figure(fig)
plot(psi_I/pi,10*log10(wnormML),'-r','linewidth',lw)
hold on
plot(psi_I/pi,10*log10(wnormDL),'-g','linewidth',lw)
plot([-1 1],10*log10(wnormCBF)*[1 1],'-c','linewidth',lw)
plot(psi_I/pi,10*log10(wnormBL),'-b','linewidth',lw)
plot(psi_I/pi,10*log10(wnormMS),'-m','linewidth',lw)
plot(psi_I/pi,10*log10(NT0./(N*(1-xiI2))),'-k','linewidth',lw)
hold off
legend('MLE','UDL','CBF','BLUE','MSE','T0','location','northwest')
ylabel('10 log10(|w|^2)','Fontsize',FS)
title(['N=' int2str(N) ',\psi_{s}=' num2str(psi_s/pi) '\pi, INR=' num2str(INRdB) ' dB, SNR = ' num2str(SNRdB) ' dB'])
xlabel('\psi_{I}/\pi','Fontsize',FS)
set(gca,'Fontsize',FS)
grid on

