%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 5.27
% Example 5.23 position and velocity
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

N=11;

sigmaw2=1;
ii = [1:1:20];
vx = (6*ii.^2-6*(N+1)*ii+(N+1)*(2*N+1))*2/(N*(N^2-1));

vxB = zeros(3,length(ii));
MTX = [N 0.5*N*(N+1); 0.5*N*(N+1) N*(N+1)*(2*N+1)/6];

n=1;
sigmax2 = 1;
sigmav2=1;
Kthinv = diag([1/sigmax2 1/sigmav2]);

JB = Kthinv+MTX/sigmaw2;
for k=ii
    vxB(n,k) = [1 k]*inv(JB)*[1;k];
end

n=2;
sigmax2=0.1;
sigmav2=1;
Kthinv = diag([1/sigmax2 1/sigmav2]);

JB = Kthinv+MTX/sigmaw2;
for k=ii
    vxB(n,k) = [1 k]*inv(JB)*[1;k];
end

n=3;
sigmax2=1;
sigmav2=0.1;
Kthinv = diag([1/sigmax2 1/sigmav2]);

JB = Kthinv+MTX/sigmaw2;
for k=ii
    vxB(n,k) = [1 k]*inv(JB)*[1;k];
end



figure(1)
h(1)=plot(ii,vx,'--r','linewidth',lw);
hold on
h(2)=plot(ii,vxB(1,:),'-','linewidth',lw);
hold on
h(3)=plot(ii,vxB(3,:),'-.','linewidth',lw);
h(4)=plot(ii,vxB(2,:),'-+','linewidth',lw)
xlabel('Time (n)','Fontsize',FS)
ylabel('Var(x(n))','Fontsize',FS)
set(gca,'Fontsize',FS)
ylim([0 2])
hold off
legend(['\sigma_x^2=\infty, \sigma_v^2=\infty'],...
    ['\sigma_x^2=1, \sigma_v^2=1'],...
    ['\sigma_x^2=1, \sigma_v^2=0.1'],...
    ['\sigma_x^2=0.1, \sigma_v^2=1'],'location','northwest')
print -deps Fig5-27.eps

