% Figures 5.16, 5.18
% Examples 5.15, 5.16
%
% Compares convergence of 4 implementation of MLE for two complex exponentials
%  - 2D max
%  - AP
%  - EM
%  - SAGE
%
% K. Bell 
% 5/4/14
%
% saves/loads TwoExpConv
% calls TwoComplexExponentials2DMax, TwoComplexExponentialsAP, TwoComplexExponentialsEM, TwoComplexExponentialsSAGE, 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all


FS = 10;
lw = 0.5;
FS11 = 12;
lw11 = 0.5;
runsim = 0;      % 1 to run simulation, 0 to use saved data

if runsim
    
    omega1 = 0.0*pi;             % actual frequency
    omega2 = 0.3*pi             % actual frequency
    theta1 = 0;               % actual phase (radians)
    
    N = 10;                       % snapshots
    k = [0:1:N-1];
    V = exp(j*(k.'*[omega1 omega2]));
    D = j*V.*repmat(k.',1,2);
    H = D'*D-D'*V*inv(V'*V)*V'*D;
    
    theta2 = -angle(H(1,2));
    
    SNRdB0 = 5;
    SNR1 = 10^(SNRdB0/10); % SNR1
    SNR2 = SNR1; % SNR2
    L = 2^11;                     % FFT grid size
    
    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;
    v=exp(j*(k.'*freq));         % KxL "frequency response" vectors
    
    b1 = sqrt(SNR1)*exp(j*theta1);         % amplitude
    b2 = sqrt(SNR2)*exp(j*theta2);         % amplitude
    x = b1*exp(j*(omega1*k))+b2*exp(j*(omega2*k))+sqrt(1/2)*(randn(1,N)+j*randn(1,N));
    
    [omega1_hat_2DM,omega2_hat_2DM]=TwoComplexExponentials2DMax(x,L);
    [omega1_hat_AP,omega2_hat_AP]=TwoComplexExponentialsAP(x,L);
    [omega1_hat_EM,omega2_hat_EM]=TwoComplexExponentialsEM(x,L);
    [omega1_hat_SAGE,omega2_hat_SAGE]=TwoComplexExponentialsSAGE(x,L);
    save TwoExpConv omega1 omega2 theta1 theta2 SNR1 SNR2 N x L omega1_hat_2DM omega2_hat_2DM omega1_hat_AP omega2_hat_AP omega1_hat_EM omega2_hat_EM omega1_hat_SAGE omega2_hat_SAGE

else
    load  TwoExpConv % omega1 omega2 theta1 theta2 SNR1 SNR2 N x L omega1_hat_2DM omega2_hat_2DM omega1_hat_AP omega2_hat_AP omega1_hat_EM omega2_hat_EM omega1_hat_SAGE omega2_hat_SAGE
end
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Plotting
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%%
%--------------------
% Convergence AP only
%--------------------
figure(1)
TA=length(omega1_hat_AP);
TE=length(omega1_hat_EM);
TS=length(omega1_hat_SAGE);
subplot(2,1,1)
h1=plot([0:1:TA-1],omega1_hat_AP/pi,'r--','Linewidth',lw);
hold on
h4=plot([0 TA-1],omega1_hat_2DM*[1 1]/pi,'b','Linewidth',lw);
hold off
xlabel('Iteration','Fontsize',FS)
ylabel('\omega_{1}/\pi','Fontsize',FS)
title(['\omega_1=' num2str(omega1/pi) '\pi'],'Fontsize',FS)
grid on
legend([h1 h4],'AP','2DMax')
set(gca,'Fontsize',FS)

subplot(2,1,2)
h1=plot([0:1:TA-1],omega2_hat_AP/pi,'r--','Linewidth',lw);
hold on
h4=plot([0 TA-1],omega2_hat_2DM*[1 1]/pi,'b','Linewidth',lw);
hold off
xlabel('Iteration','Fontsize',FS)
ylabel('\omega_{2}/\pi','Fontsize',FS)
title(['\omega_2=' num2str(omega2/pi) '\pi'],'Fontsize',FS)
grid on
legend([h1 h4],'AP','2DMax','location','southeast')
set(gca,'Fontsize',FS)

subplot(2,1,1)
ylim([-0.01 0.01])
set(gca,'XTick',[0:1:TA])
subplot(2,1,2)
ylim([0.3 0.32])
set(gca,'XTick',[0:1:TA])

print -deps Fig5-16.eps
%%
%--------------------
% Convergence AP only
%--------------------
figure(2)
TA=length(omega1_hat_AP);
TE=length(omega1_hat_EM);
TS=length(omega1_hat_SAGE);
subplot(2,1,1)
h1=plot([0:1:TA-1],omega1_hat_AP/pi,'r--','Linewidth',lw);
hold on
h2=plot([0:1:TE-1],omega1_hat_EM/pi,'g-.','Linewidth',lw);
h3=plot([0:1:TS-1],omega1_hat_SAGE/pi,'k-+','Linewidth',lw);
h4=plot([0 max([TA TE TS])-1],omega1_hat_2DM*[1 1]/pi,'b','Linewidth',lw);
hold off
xlabel('Iteration','Fontsize',FS)
ylabel('\omega_{1}/\pi','Fontsize',FS)
title(['\omega_1=' num2str(omega1/pi) '\pi'],'Fontsize',FS)
grid on
legend([h2 h3 h1 h4],'EM','SAGE','AP','2DMax')
set(gca,'Fontsize',FS)

subplot(2,1,2)
h1=plot([0:1:TA-1],omega2_hat_AP/pi,'r--','Linewidth',lw);
hold on
h2=plot([0:1:TE-1],omega2_hat_EM/pi,'g-.','Linewidth',lw);
h3=plot([0:1:TS-1],omega2_hat_SAGE/pi,'k-+','Linewidth',lw);
h4=plot([0 max([TA TE TS])-1],omega2_hat_2DM*[1 1]/pi,'b','Linewidth',lw);
hold off
xlabel('Iteration','Fontsize',FS)
ylabel('\omega_{2}/\pi','Fontsize',FS)
title(['\omega_2=' num2str(omega2/pi) '\pi'],'Fontsize',FS)
grid on
legend([h2 h3 h1 h4],'EM','SAGE','AP','2DMax','location','southeast')
set(gca,'Fontsize',FS)

subplot(2,1,1)
ylim([-0.01 0.01])
subplot(2,1,2)
ylim([0.3 0.32])

print -deps Fig5-18.eps