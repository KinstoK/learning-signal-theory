%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figures 5.8a,b 5.9a,b, 5.10
% Example 5.10 ML
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

N=10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Frequency Response, Figs 5.8, 5.9
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
INR =[10 0.1];
Delta_psi_I = [0.5 0.1]*pi;

Delta_psi = [-1:0.01:1]*pi;
Bc = (1/N)*sin(N*Delta_psi/2)./sin(Delta_psi/2);
Bc(find(Delta_psi==0))=1;

fig=1;
for i1 = 1:2
    BcI = (1/N)*sin(N*(Delta_psi-Delta_psi_I(i1))/2)./sin((Delta_psi-Delta_psi_I(i1))/2);
    BcI(find((Delta_psi-Delta_psi_I(i1))==0))=1;
    
    Bc_psiI = (1/N)*sin(N*Delta_psi_I(i1)/2)./sin(Delta_psi_I(i1)/2);
    
    for i2=1:2
        NINR = N*INR(i2);
        BI = BcI*Bc_psiI*NINR/(NINR+1);
        
        scale = 1/(1-Bc_psiI*Bc_psiI*NINR/(NINR+1));
        Bml = scale*(Bc-BI);
        
        figure(fig)
        clf
        subplot(3,1,1)
        plot(Delta_psi/pi,Bc,'linewidth',lw)
        hold on
        plot(Delta_psi/pi,BI,'--','linewidth',lw)
        legend(['B_{c}(\Delta\psi)'],['B_{I}(\Delta\psi)'],'location','northwest')
        ylim([-0.8 1.2]);
        yy=ylim;
        plot([-1 1],[0 0],':k')
        plot([-1 1],[1 1],':k')
        plot([1 1]*Delta_psi_I(i1)/pi,yy,':k')
        plot([0 0],yy,':k')
        hold off
        xlabel('\Delta\psi/\pi','Fontsize',FS)
        ylabel('B_{c}(\Delta\psi)','Fontsize',FS)
        title(['N=' int2str(N) ', INR=' num2str(INR(i2)) ', \Delta\psi_{I}/\pi=' num2str(Delta_psi_I(i1)/pi)])
        set(gca,'Xtick',[-1:0.2:1])
        set(gca,'Fontsize',FS)
        
        subplot(3,1,2)
        plot(Delta_psi/pi,Bml,'linewidth',lw)
        ylim([-0.8 1.2]);
        yy=ylim;
        hold on
        plot([-1 1],[0 0],':k')
        plot([1 1]*Delta_psi_I(i1)/pi,yy,':k')
        plot([0 0],yy,':k')
        plot([-1 1],[1 1],':k')
        hold off
        xlabel('\Delta\psi/\pi','Fontsize',FS)
        ylabel('B_{ml}(\Delta\psi)','Fontsize',FS)
        set(gca,'Xtick',[-1:0.2:1])
        set(gca,'Fontsize',FS)
        
        subplot(3,1,3)
        plot(Delta_psi/pi,10*log10(Bml.^2),'linewidth',lw)
        ylim([-35 5]);
        yy=ylim;
        hold on
        plot([-1 1],[0 0],':k')
        plot([1 1]*Delta_psi_I(i1)/pi,yy,':k')
        plot([0 0],yy,':k')
        hold off
        xlabel('\Delta\psi/\pi','Fontsize',FS)
        ylabel('B_{ml}(\Delta\psi)^{2} (dB)','Fontsize',FS)
        set(gca,'Xtick',[-1:0.2:1])
        set(gca,'Fontsize',FS)
        
        if i1==1
            if i2==1
                filename = 'Fig5-8a.eps';
            else
                filename = 'Fig5-8b.eps';
            end
        else
            if i2==1
                filename = 'Fig5-9a.eps';
            else
                filename = 'Fig5-9b.eps';
            end
        end
        eval(['print -deps ' filename])
        fig=fig+1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Variance, Fig 5.10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
INR =[10 1 0.1];
Delta_psi_I = [0:0.001:1]*pi;

BcI = (1/N)*sin(N*(Delta_psi_I)/2)./sin(Delta_psi_I/2);
BcI(find(Delta_psi_I==0))=1;

CRB = zeros(3,length(Delta_psi_I));
V_CBF = zeros(3,length(Delta_psi_I));
for i2 = 1:3
    
    NINR = N*INR(i2);
    
    CRB(i2,:) = 1./(N*(1-BcI.*BcI*NINR/(NINR+1)));
    V_CBF(i2,:) =(1+BcI.*BcI*NINR)/N;
    
    
end
figure(fig)
yy=[11 1.5 0.25];
for ii=1:3
    subplot(3,1,ii)
    plot(Delta_psi_I/pi,10*log10(CRB(ii,:)),'-','linewidth',lw)
    hold on
    plot(Delta_psi_I/pi,10*log10(V_CBF(ii,:)),'-.r','linewidth',lw)
    hold off
    legend('MLE','Conv.','location','northeast')
    ylabel('10 log10{var(b_{s}}','Fontsize',FS)
    if ii==1
        title(['N=' int2str(N) ', INR=' num2str(INR(ii))])
    else
        title(['N=' int2str(N) ', INR=' num2str(INR(ii))])
    end
    if ii==3
        xlabel('\Delta\psi_{I}/\pi','Fontsize',FS)
    end
    set(gca,'Fontsize',FS)
    grid on
end

fig=fig+1;

figure(fig)
yy=[11 1.5 0.25];
for ii=1:2
    subplot(2,1,ii)
    if ii==1
        plot(Delta_psi_I/pi,10*log10(CRB(1,:)),'-.','linewidth',lw)
        hold on
        plot(Delta_psi_I/pi,10*log10(CRB(2,:)),'--','linewidth',lw)
        plot(Delta_psi_I/pi,10*log10(CRB(3,:)),'-','linewidth',lw)
        hold off
    else
        plot(Delta_psi_I/pi,10*log10(V_CBF(1,:)),'-.r','linewidth',lw)
        hold on
        plot(Delta_psi_I/pi,10*log10(V_CBF(2,:)),'--r','linewidth',lw)
        plot(Delta_psi_I/pi,10*log10(V_CBF(3,:)),'-r','linewidth',lw)
        hold off
    end
    legend(['INR=' num2str(INR(1))],['INR=' num2str(INR(2))],['INR=' num2str(INR(3))],'location','northeast')
    ylabel('10 log10{var(b_{s})}','Fontsize',FS)
    xlabel('\Delta\psi_{I}/\pi','Fontsize',FS)
    set(gca,'Fontsize',FS)
    ylim([-11 11])
    grid on
    if ii==1
        title(['MLE, N=' int2str(N)])
    else
        title(['Conv., N=' int2str(N)])
    end
    
end


print -deps Fig5-10.eps

