function [omega1_hat,omega2_hat]= TwoComplexExponentials2DMax(x,L)
% TwoComplexExponentials2DMax.m
%
% 2D Maximization implementation of MLE for two complex exponentials
%
% K. Bell 5/4/14
%
% Inputs:
%   x: 1xN complex data samples
%   L: FFT size.  Freq resolution = 2*pi/L

N=length(x);
k = [0:1:N-1];
freq = 2*pi*[-(L/2):1:(L/2)-1]/L;

v=exp(j*(k.'*freq));         % KxL "frequency response" vectors
B = v'*v;                      
D = N^2-abs(B).^2;
Mask = zeros(L,L);           % Forces omega_2 > omega_1
for ll=1:L
    Mask(ll,1:ll)=repmat(-Inf,1,ll);
end
F = fft(x,L);
F = fftshift(F);              % 1xL
A1 = N*abs(F).^2;             % 1xL 
A12 = 2*real((F'*F).*B);      % LxL
S = (repmat(A1.',1,L)+repmat(A1,L,1)-A12)./D;   % ML surface, NAN on diagonal (div by 0)
S([1:L+1:L^2])=repmat(-Inf,1,L);
S=S+Mask;
[v1,n1]=max(S,[],1);
[v2,n2]=max(v1);
 omega1_hat = freq(n1(n2));
 omega2_hat = freq(n2);

