%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 5.21a,b Beampatterns
% Example 5.17
% Sensor perturbations and DL
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

%------------------------------------------
% Array
%------------------------------------------
N=10;   % Number of elements
d_lambda = 0.5;
DN = [-(N-1)/2:1:(N-1)/2].';       % uniformly spaced linear array, half wavelength
D = DN*d_lambda;                   % uniformly spaced linear array, half wavelength
sigma_d = 0.15;                    % perturbation st. dev. wrt spacing 

%------------------------------------------
% Signal + Interferer
%------------------------------------------
psi_s = [0 0.8]*pi;
ns = length(psi_s);

Delta_psi_I = 0.1*pi;
INRdB =30;
INR = 10^(INRdB/10);
NINR = N*INR;

%------------------------------------------
% Beampatterns
%------------------------------------------
psi = [-1:0.001:1]*pi;

fig=1;
for n=1:ns
    Delta_psi = psi-psi_s(n);
    Bc = (1/N)*sin(N*Delta_psi/2)./sin(Delta_psi/2);
    Bc(find(Delta_psi==0))=1;
    
    BcI = (1/N)*sin(N*(Delta_psi_I-Delta_psi)/2)./sin((Delta_psi_I-Delta_psi)/2);
    BcI(find((Delta_psi_I-Delta_psi)==0))=1;
    Bc_psiI = (1/N)*sin(N*Delta_psi_I/2)./sin(Delta_psi_I/2);
    BI = BcI*Bc_psiI*NINR/(NINR+1);
    
    scale = 1/(1-Bc_psiI*Bc_psiI*NINR/(NINR+1));
    Bml = scale*(Bc-BI);
    
    xi2 = exp(-(psi*sigma_d).^2);
    Ba2p =   (1-xi2)*scale;
    Ba =    xi2.*abs(Bml).^2 +Ba2p;
    Bbar =  xi2.*abs(Bml).^2;

    figure(fig)
    plot(psi/pi,10*log10(Bbar),'linewidth',lw)
    hold on
    plot(psi/pi,10*log10(abs(Bml).^2),'--','linewidth',lw)
    plot(psi/pi,10*log10(xi2),'-.r','linewidth',lw)
    ylim([-35 5]);
    yy=ylim;
    hold on
    plot([-1 1],[0 0],':k')
    plot([1 1]*(psi_s(n)+Delta_psi_I)/pi,yy,':k')
    plot([1 1]*(psi_s(n))/pi,yy,':k')
    hold off
    set(gca,'Xtick',[-1:0.2:1])
    set(gca,'Fontsize',FS)
    legend('|B(\psi) bar|^{2}',['|B^{n}(\psi)|^{2}'],'\xi^{2}','location','southwest')
    title(['N=' int2str(N) ', \psi_{s}/\pi=' num2str(psi_s(n)/pi) ...
        ', \psi_{I}/\pi=' num2str((psi_s(n)+Delta_psi_I)/pi) ...
        ', INR=' num2str(INRdB) ' dB, \sigma_d=' num2str(sigma_d)])
    
    xlabel('\psi/\pi','Fontsize',FS)
    if n==1
        filename = 'Fig5Y2c.eps';
    else
        filename = 'Fig5Y2d.eps';
    end
    %eval(['print -deps ' filename])
    
    figure(fig+1)
    plot(psi/pi,10*log10(Ba),'linewidth',lw)
    hold on
    plot(psi/pi,10*log10((1-xi2)*scale),'-.r','linewidth',lw)
    plot(psi/pi,10*log10(Bml.^2),'--','linewidth',lw)
    ylim([-35 5]);
    yy=ylim;
    hold on
    plot([-1 1],[0 0],':k')
    plot([1 1]*(psi_s(n)+Delta_psi_I)/pi,yy,':k')
    plot([1 1]*(psi_s(n))/pi,yy,':k')
    hold off
    xlabel('\psi/\pi','Fontsize',FS)
    set(gca,'Xtick',[-1:0.2:1])
    set(gca,'Fontsize',FS)
    legend(['|B(\psi)|^{2} bar'],['|B_{h}(\psi)|^{2} bar'],['|B^{n}(\psi)|^{2}'],'location','southwest')
    title(['N=' int2str(N) ', \psi_{s}/\pi=' num2str(psi_s(n)/pi) ...
        ', \psi_{I}/\pi=' num2str((psi_s(n)+Delta_psi_I)/pi) ...
        ', INR=' num2str(INRdB) ' dB, \sigma_d=' num2str(sigma_d)])
    
    if n==1
        filename = 'Fig5-21a.eps';
    else
        filename = 'Fig5-21b.eps';
    end
    eval(['print -deps ' filename])
    fig=fig+2;
end
