% Figure 5.14, 5.19
% Examples 5.13, 5.16
%
% Compares MSE of 4 implementations of MLE for two complex exponentials
%  - 2D max
%  - AP
%  - EM
%  - SAGE
%
% K. Bell
% 5/4/14
%
% saves/loads EX5ZRMSE_2D, EX5ZRMSE_IT,
% calls TwoComplexExponentials2DMax, TwoComplexExponentialsAP, TwoComplexExponentialsEM, TwoComplexExponentialsSAGE,
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
runsim = 0;      % 1 to run simulation, 0 to use saved data
run2DMax=1;

FS = 10;
lw = 0.5;
FS11 = 12;
lw11 = 0.5;

if ~runsim
    if run2DMax
        load Ex5ZRMSE_2D
    else
        load Ex5ZRMSE_IT                  % loads omega_a theta_a K SNR M L H h Hk hk sigmap pdf pdfk pdf_kp pdfk_kp tse wse tb wb wse_kp wb_kp
    end
    ns = length(SNR1);
    k = [0:1:N-1];
    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;
    
else % run simulation
    omega1 = 0.0*pi;             % actual frequency
    omega2 = 0.3*pi;             % actual frequency
    theta1 = 0;               % actual phase (radians)
    
    N = 10;                       % snapshots
    k = [0:1:N-1];
    V = exp(j*(k.'*[omega1 omega2]));
    D = j*V.*repmat(k.',1,2);
    H = D'*D-D'*V*inv(V'*V)*V'*D;
    
    theta2 = -angle(H(1,2));
    
    
    SNR1 = 10.^([[15:-5:10] [5:-1:-5] [-10:-5:-15]]/10); % SNR
    SNR2 = SNR1; % SNR
    
    M = 1000;                    % Monte Carlo trials
    L = 2^11;                     % FFT grid size
    
    ns = length(SNR1);
    freq = 2*pi*[-(L/2):1:(L/2)-1]/L;
    v=exp(j*(k.'*freq));         % KxL "frequency response" vectors
    
    if run2DMax
        wse1.MDM   = zeros(1,ns);        % sample squared error, omega1
        wse2.MDM   = zeros(1,ns);        % sample squared error, omega2
    end
    wse1.AP    = zeros(1,ns);        % sample squared error, omega1
    wse2.AP    = zeros(1,ns);        % sample squared error, omega2
    wse1.EM    = zeros(1,ns);        % sample squared error, omega1
    wse2.EM    = zeros(1,ns);        % sample squared error, omega2
    wse1.SAGE  = zeros(1,ns);        % sample squared error, omega1
    wse2.SAGE  = zeros(1,ns);        % sample squared error, omega2
    
    t0=tic;
    for n=1:ns
        [n 10*log10(SNR1(n))]
        toc(t0)
        b1 = sqrt(SNR1(n))*exp(j*theta1);         % amplitude
        b2 = sqrt(SNR2(n))*exp(j*theta2);         % amplitude
        if run2DMax
            omega1_hat.MDM = zeros(1,M);     % omega1 estimate
            omega2_hat.MDM = zeros(1,M);     % omega1 estimate
        end
        omega1_hat.AP = zeros(1,M);     % omega1 estimate
        omega2_hat.AP = zeros(1,M);     % omega1 estimate
        omega1_hat.EM = zeros(1,M);     % omega1 estimate
        omega2_hat.EM = zeros(1,M);     % omega1 estimate
        omega1_hat.SAGE = zeros(1,M);     % omega1 estimate
        omega2_hat.SAGE = zeros(1,M);     % omega1 estimate
        
        for m=1:M
            
            x = b1*exp(j*(omega1*k))+b2*exp(j*(omega2*k))+sqrt(1/2)*(randn(1,N)+j*randn(1,N));
            if run2DMax
                [omega1_hat.MDM(m),omega2_hat.MDM(m)]=TwoComplexExponentials2DMax(x,L);
            end
            [tmp1,tmp2]=TwoComplexExponentialsAP(x,L);
            omega1_hat.AP(m)=tmp1(end);
            omega2_hat.AP(m)=tmp2(end);
            [tmp1,tmp2]=TwoComplexExponentialsEM(x,L);
            omega1_hat.EM(m)=tmp1(end);
            omega2_hat.EM(m)=tmp2(end);
            [tmp1,tmp2]=TwoComplexExponentialsSAGE(x,L);
            omega1_hat.SAGE(m)=tmp1(end);
            omega2_hat.SAGE(m)=tmp2(end);
        end % m
        if run2DMax
            wse1.MDM(n) = sum((omega1_hat.MDM-omega1).^2)/M;
            wse2.MDM(n) = sum((omega2_hat.MDM-omega2).^2)/M;
        end
        wse1.AP(n) = sum((omega1_hat.AP-omega1).^2)/M;
        wse2.AP(n) = sum((omega2_hat.AP-omega2).^2)/M;
        wse1.EM(n) = sum((omega1_hat.EM-omega1).^2)/M;
        wse2.EM(n) = sum((omega2_hat.EM-omega2).^2)/M;
        wse1.SAGE(n) = sum((omega1_hat.SAGE-omega1).^2)/M;
        wse2.SAGE(n) = sum((omega2_hat.SAGE-omega2).^2)/M;
        
    end % n
    toc(t0)
    if run2DMax
        save Ex5ZRMSE_2D omega1 theta1 omega2 theta2 N SNR1 SNR2 M L wse1 wse2
    else
        save Ex5ZRMSE_IT omega1 theta1 omega2 theta2 N SNR1 SNR2 M L wse1 wse2
    end
end  %runsim
%%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% CRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
CRB_omega1 = (SNR1.^(-1))*6/(N*(N^2-1));
CRB_omega2 = (SNR2.^(-1))*6/(N*(N^2-1));
CRB = zeros(2,2,ns);
V = exp(j*(k.'*[omega1 omega2]));
D = j*V.*repmat(k.',1,2);
H = D'*D-D'*V*inv(V'*V)*V'*D;
for n=1:ns
    b1 = sqrt(SNR1(n))*exp(j*theta1);         % amplitude
    b2 = sqrt(SNR2(n))*exp(j*theta2);         % amplitude
    b=[b1;b2];
    B=b*b';
    A = H.*(B.');
    
    CRB(:,:,n) = 0.5*inv(real(A));
end


CRB1 = squeeze(CRB(1,1,:));
CRB2 = squeeze(CRB(2,2,:));

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Plotting
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%%
%--------------------
% Frequency  RMSE
%--------------------
figure(1)
subplot(2,1,1)
h0=plot(10*log10(SNR1),10*log10(sqrt(CRB1)),'g--','Linewidth',lw);
hold on
if run2DMax
    h2=plot(10*log10(SNR1),10*log10(sqrt(wse1.MDM)),'b-*','Linewidth',lw);
else
    h2=plot(10*log10(SNR1),10*log10(sqrt(wse1.AP)),'b-*','Linewidth',lw);
end
h5=plot(10*log10(SNR1),10*log10(sqrt(CRB_omega1)),'c','Linewidth',lw);
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
title(['\omega_1=' num2str(omega1/pi) '\pi'],'Fontsize',FS)
grid on
legend([h2 h0 h5], 'Sim','CRB2s, wc \Delta\theta','CRB1s')
set(gca,'Fontsize',FS)
axis([-15 15 -20 5])

subplot(2,1,2)
h0=plot(10*log10(SNR1),10*log10(sqrt(CRB2)),'g--','Linewidth',lw);
hold on
if run2DMax
    h2=plot(10*log10(SNR1),10*log10(sqrt(wse2.MDM)),'b-*','Linewidth',lw);
else
    h2=plot(10*log10(SNR1),10*log10(sqrt(wse2.AP)),'b-*','Linewidth',lw);
end
h5=plot(10*log10(SNR1),10*log10(sqrt(CRB_omega2)),'c','Linewidth',lw);
hold off
title(['\omega_2=' num2str(omega2/pi) '\pi'],'Fontsize',FS)
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
grid on
axis([-15 15 -20 5])
legend([h2 h0 h5], 'Sim','CRB2s, wc \Delta\theta','CRB1s')
set(gca,'Fontsize',FS)
print -deps Fig5-14.eps

%%
%--------------------
% Frequency  RMSE All algs
%--------------------
figure(2)
subplot(2,1,1)
h0=plot(10*log10(SNR1),10*log10(sqrt(CRB1)),'g','Linewidth',lw);
hold on
if run2DMax
    h1=plot(10*log10(SNR1),10*log10(sqrt(wse1.MDM)),'b-*','Linewidth',lw);
end
h2=plot(10*log10(SNR1),10*log10(sqrt(wse1.AP)),'r--','Linewidth',lw);
h3=plot(10*log10(SNR1),10*log10(sqrt(wse1.EM)),'g-.','Linewidth',lw);
h4=plot(10*log10(SNR1),10*log10(sqrt(wse1.SAGE)),'k-+','Linewidth',lw);
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
title(['\omega_1=' num2str(omega1/pi) '\pi'],'Fontsize',FS)
grid on
if run2DMax
    legend([h1 h2 h3 h4 h0], '2DMax','AP','EM','SAGE','CRB')
else
    legend([h2 h3 h4 h0], 'AP','EM','SAGE','CRB')
end
set(gca,'Fontsize',FS)
axis([-15 15 -20 5])

subplot(2,1,2)
h0=plot(10*log10(SNR1),10*log10(sqrt(CRB2)),'g','Linewidth',lw);
hold on
if run2DMax
    h1=plot(10*log10(SNR1),10*log10(sqrt(wse2.MDM)),'b-*','Linewidth',lw);
end
h2=plot(10*log10(SNR1),10*log10(sqrt(wse2.AP)),'r--','Linewidth',lw);
h3=plot(10*log10(SNR1),10*log10(sqrt(wse2.EM)),'g-.','Linewidth',lw);
h4=plot(10*log10(SNR1),10*log10(sqrt(wse2.SAGE)),'k-+','Linewidth',lw);
hold off
title(['\omega_2=' num2str(omega2/pi) '\pi'],'Fontsize',FS)
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(RMSE)','Fontsize',FS)
grid on
axis([-15 15 -20 5])
if run2DMax
    legend([h1 h2 h3 h4 h0], '2DMax','AP','EM','SAGE','CRB')
else
    legend([h2 h3 h4 h0], 'AP','EM','SAGE','CRB')
end
set(gca,'Fontsize',FS)
print -deps Fig5-19.eps


