%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 5.3
% Example 5.8 position and velocity
% K. Bell
% 5/4/11
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 0.5;
FS = 10;

NN=[6;11;20];

ii = [1:1:20];
vx = zeros(3,length(ii));
for n=1:3
    N=NN(n);
    vx(n,:) = (6*ii.^2-6*(N+1)*ii+(N+1)*(2*N+1))*2/(N*(N^2-1));
end

figure(1)
plot(ii,vx(1,:),'-','linewidth',lw)
hold on
plot(ii,vx(2,:),'--','linewidth',lw)
plot(ii,vx(3,:),'-.','linewidth',lw)
xlabel('Time (n)','Fontsize',FS)
ylabel('Var(x(n))','Fontsize',FS)
grid on
set(gca,'Fontsize',FS)
ylim([0 2])
hold off
legend(['N=' int2str(NN(1))],['N=' int2str(NN(2))],['N=' int2str(NN(3))],'location','northwest')
print -deps Fig5-3.eps

