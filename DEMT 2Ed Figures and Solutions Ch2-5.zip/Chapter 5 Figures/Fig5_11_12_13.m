% Figures 5.11, 5.12, 5.13
% Example 5.13
%
% Computes CRB for two complex exponentials
%
% K. Bell 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

FS = 10;
lw = 0.5;
FS11 = 12;
lw11 = 0.5;

Delw0 = -0.3*pi;
SNRdB0 = 0;

omega1 = 0.3*pi;             % actual frequency
omega2 = omega1+Delw0;             % actual frequency
theta1 = 0;               % actual phase (radians)

N = 10;                       % snapshots
SNR1 = 10.^([[15:-5:10] [5:-1:-5] [-10:-5:-15]]/10); % SNR
SNR2 = SNR1; % SNR

ns = length(SNR1);
k = [0:1:N-1];

V = exp(j*(k.'*[omega1 omega2]));
D = j*V.*repmat(k.',1,2);
H = D'*D-D'*V*inv(V'*V)*V'*D;

theta2_wc = -angle(H(1,2));
theta2_bc = -angle(H(1,2))-pi/2;
 
CRB_wc = zeros(2,2,ns);
CRB_bc = zeros(2,2,ns);
for n=1:ns
    
    b1 = sqrt(SNR1(n))*exp(j*theta1);         % amplitude
    b2 = sqrt(SNR2(n))*exp(j*theta2_wc);         % amplitude
    b=[b1;b2];
    B=b*b';
    A = H.*(B.');
    
    CRB_wc(:,:,n) = 0.5*inv(real(A));
    
    b1 = sqrt(SNR1(n))*exp(j*theta1);         % amplitude
    b2 = sqrt(SNR2(n))*exp(j*theta2_bc);         % amplitude
    b=[b1;b2];
    B=b*b';
    A = H.*(B.');
    
    CRB_bc(:,:,n) = 0.5*inv(real(A));

end % n
%%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 1S CRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
CRB_omega1 = (SNR1.^(-1))*6/(N*(N^2-1));
CRB_omega2 = (SNR2.^(-1))*6/(N*(N^2-1));

CRB1_wc = squeeze(CRB_wc(1,1,:));
CRB2_wc = squeeze(CRB_wc(2,2,:));
CRB1_bc = squeeze(CRB_bc(1,1,:));
CRB2_bc = squeeze(CRB_bc(2,2,:));

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Plotting
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%%
%--------------------
% Frequency  RMSE vs snr
%--------------------
figure(1)
h0=plot(10*log10(SNR1),10*log10(sqrt(CRB_omega1)),'b','Linewidth',lw);
hold on
h2=plot(10*log10(SNR1),10*log10(sqrt(CRB1_wc)),'r--','Linewidth',lw);
h3=plot(10*log10(SNR1),10*log10(sqrt(CRB1_bc)),'k-.','Linewidth',lw);
hold off
xlabel('SNR (dB)','Fontsize',FS)
ylabel('10*log_{10}(CRB)','Fontsize',FS)
title(['\Delta\omega=' num2str((omega1-omega2)/pi) '\pi'],'Fontsize',FS)
legend([h2 h3 h0],'CRB2s, wc \Delta\theta','CRB2s, bc \Delta\theta','CRB1s')
set(gca,'Fontsize',FS)
axis([-15 15 -20 5])
print -deps Fig5-13.eps



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% vs. Phase
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
omega2a = omega1+Delw0;             % actual frequency
theta2 =[-1:0.01:1]*pi;               % actual phase (radians)

N = 10;                       % snapshots
SNR1_dB=SNRdB0;
SNR1 = 10.^(SNR1_dB/10); % SNR
SNR2 = SNR1; % SNR


nt = length(theta2);

V = exp(j*(k.'*[omega1 omega2a]));
D = j*V.*repmat(k.',1,2);
H = D'*D-D'*V*inv(V'*V)*V'*D;
CRBa = zeros(2,2,nt);
for n=1:nt
    b1 = sqrt(SNR1)*exp(j*theta1);         % amplitude
    b2 = sqrt(SNR2)*exp(j*theta2(n));         % amplitude
    b=[b1;b2];
    B=b*b';
    CRBa(:,:,n) = 0.5*inv(real(H.*(B.')));
    
end % n
omega2b = omega1-0.1*pi;             % actual frequency

V = exp(j*(k.'*[omega1 omega2b]));
D = j*V.*repmat(k.',1,2);
H = D'*D-D'*V*inv(V'*V)*V'*D;
CRBba = zeros(2,2,nt);
for n=1:nt
    b1 = sqrt(SNR1)*exp(j*theta1);         % amplitude
    b2 = sqrt(SNR2)*exp(j*theta2(n));         % amplitude
    b=[b1;b2];
    B=b*b';
    CRBb(:,:,n) = 0.5*inv(real(H.*(B.')));
    
end % n

%%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 1S CRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
CRB_omega1 = repmat((SNR1.^(-1))*6/(N*(N^2-1)),1,nt);
CRB_omega2 = repmat((SNR2.^(-1))*6/(N*(N^2-1)),1,nt);

CRB1a = squeeze(CRBa(1,1,:));
CRB2a = squeeze(CRBa(2,2,:));
CRB1b = squeeze(CRBb(1,1,:));
CRB2b = squeeze(CRBb(2,2,:));


%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Plotting
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%%
%--------------------
% Frequency  RMSE vs theta2
%--------------------
figure(2)
h0=plot((theta1-theta2)/pi,10*log10(sqrt(CRB_omega1)),'b','Linewidth',lw);
hold on
h2=plot((theta1-theta2)/pi,10*log10(sqrt(CRB1a)),'r--','Linewidth',lw);
h3=plot((theta1-theta2)/pi,10*log10(sqrt(CRB1b)),'k-.','Linewidth',lw);
hold off
xlabel('\Delta\theta/\pi','Fontsize',FS)
ylabel('10*log_{10}(CRB)','Fontsize',FS)
title(['SNR=' num2str(SNR1_dB) ' dB'],'Fontsize',FS)
legend([h3 h2 h0],['CRB2s, \Delta\omega=' num2str((omega1-omega2b)/pi) '\pi'],['CRB2s, \Delta\omega=' num2str((omega1-omega2a)/pi) '\pi'],'CRB1s')
set(gca,'Fontsize',FS)
axis([-1 1 -15 5])
print -deps Fig5-11.eps

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% vs. Separation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delw = [0:0.01:1]*pi;
omega2 = omega1-delw;             % actual frequency


N = 10;                       % snapshots
SNR1_dB=SNRdB0;
SNR1 = 10.^(SNR1_dB/10); % SNR
SNR2 = SNR1; % SNR

nt = length(delw);

CRB_wc = zeros(2,2,nt);
CRB_bc = zeros(2,2,nt);
tmp1= zeros(1,nt);
tmp2 = zeros(1,nt);
for n=1:nt
    V = exp(j*(k.'*[omega1 omega2(n)]));
    D = j*V.*repmat(k.',1,2);
    H = D'*D-D'*V*inv(V'*V)*V'*D;
    theta2 = -angle(H(1,2));
    
    b1 = sqrt(SNR1)*exp(j*theta1);         % amplitude
    b2 = sqrt(SNR2)*exp(j*theta2);         % amplitude
    b=[b1;b2];
    B=b*b';
    A = H.*(B.');
    
    CRB_wc(:,:,n) = 0.5*inv(real(A));
    theta2 = -angle(H(1,2))-pi/2;
    
    b1 = sqrt(SNR1)*exp(j*theta1);         % amplitude
    b2 = sqrt(SNR2)*exp(j*theta2);         % amplitude
    b=[b1;b2];
    B=b*b';
    A = H.*(B.');
    
    CRB_bc(:,:,n) = 0.5*inv(real(A));
    
end % n
%%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 1S CRB
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
CRB_omega1 = repmat((SNR1.^(-1))*6/(N*(N^2-1)),1,nt);
CRB_omega2 = repmat((SNR2.^(-1))*6/(N*(N^2-1)),1,nt);

CRB1_wc = squeeze(CRB_wc(1,1,:));
CRB2_wc = squeeze(CRB_wc(2,2,:));
CRB1_bc = squeeze(CRB_bc(1,1,:));
CRB2_bc = squeeze(CRB_bc(2,2,:));


%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Plotting
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%%
%--------------------
% Frequency  RMSE vs delw
%--------------------
figure(3)
h0=plot(delw/pi,10*log10(sqrt(CRB_omega1)),'b','Linewidth',lw);
hold on
h2=plot(delw/pi,10*log10(sqrt(CRB1_bc)),'k-.','Linewidth',lw);
h3=plot(delw/pi,10*log10(sqrt(CRB1_wc)),'r--','Linewidth',lw);
hold off
xlabel('\Delta\omega/\pi','Fontsize',FS)
ylabel('10*log_{10}(CRB)','Fontsize',FS)
title(['SNR=' num2str(SNR1_dB) ' dB'],'Fontsize',FS)
legend([h3 h2 h0],'CRB2s, wc \Delta\theta','CRB2s, bc \Delta\theta','CRB1s')
set(gca,'Fontsize',FS)
axis([0 1 -15 5])
print -deps Fig5-12.eps
