%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 4.2.11
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 1.5;
FS = 10;

NM = [1 2 4 7 10 20 40 70 100 200 400 700 1000];
nN = length(NM);

a0 = [3 40 40];
np = length(a0);

b0 = [3 40 3];

BCRB_a = zeros(np,nN);     % BCRB, a
MSE_a = zeros(np,nN);     % MMSE, a

for q=1:np
    for m=1:nN
        tmp1 = (a0(q)-1)*(b0(q)-1)*(a0(q)-2)*(b0(q)-2);
        tmp2 = (a0(q)+b0(q)-1)*(a0(q)+b0(q)-2);
        tmp3 = (a0(q)-1)*(b0(q)-1)*(a0(q)+b0(q)-4)+(a0(q)-2)*(b0(q)-2)*NM(m);
        BCRB_a(q,m) = tmp1/(tmp2*tmp3);            % BCRB
        MSE_a(q,m) = (a0(q)*b0(q))/((a0(q)+b0(q))*(a0(q)+b0(q)+1)*(a0(q)+b0(q)+NM(m)));           % MSE
    end
end
%%
%--------------------
% RMSE, BCRB vs N 
%--------------------
figure(1)
h1=loglog(NM,sqrt(MSE_a),'-k','Linewidth',lw);
hold on
h2=loglog(NM,sqrt(BCRB_a),'--b','Linewidth',lw);
hold off
set(gca,'XTick',10.^([0:1:4]))
set(gca,'XMinorGrid','off')
set(gca,'YMinorGrid','off')
legend([h1(1) h2(1)],'MMSE','BCRB')
xlabel('MN','Fontsize',FS)
ylabel('RMSE','Fontsize',FS)
axis([1 1000 5e-3 3e-1])
set(gca,'Fontsize',FS)
text(1.1,1.9e-1,'a_{0}=3, b_{0}=3')
text(1.1,6.5e-2,'a_{0}=40, b_{0}=40')
text(1.1,3e-2,'a_{0}=40, b_{0}=3')
title('Problem 4.2.11')
print -deps Fig4-2-11.eps
