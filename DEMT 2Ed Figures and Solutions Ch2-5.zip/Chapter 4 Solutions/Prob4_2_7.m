%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 4.2.7
% K. Bell
% 5/4/14
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

lw = 1.5;
FS = 10;

N = [1 2 4 7 10 20 40 70 100 200 400 700 1000];
nN = length(N);

a0 = [3 20 40];
np = length(a0);

b0=1;

alpha = 1;

BCRB_a = zeros(np,nN);     % BCRB, a
MSE_a = zeros(np,nN);     % MMSE, a

for q=1:np
    for m=1:nN
        BCRB_a(q,m) = 1/((b0^2)*a0(q)*(a0(q)+1)*(a0(q)+N(m)*alpha+3));            % BCRB
        MSE_a(q,m) = 1/((b0^2)*(a0(q)-1)*(a0(q)-2)*(a0(q)+N(m)*alpha-1));           % MSE
    end
end
%%
%--------------------
% RMSE, BCRB vs N 
%--------------------
figure(1)
h1=loglog(N,sqrt(MSE_a),'-k','Linewidth',lw);
hold on
h2=loglog(N,sqrt(BCRB_a),'--b','Linewidth',lw);
hold off
set(gca,'XTick',10.^([0:1:4]))
set(gca,'XMinorGrid','off')
set(gca,'YMinorGrid','off')
legend([h1(1) h2(1)],'MMSE','BCRB')
xlabel('N','Fontsize',FS)
ylabel('RMSE','Fontsize',FS)
axis([1 1000 5e-4 1])
set(gca,'Fontsize',FS)
text(1100,1.4e-2,'a_{0}=3')
text(1100,1.5e-3,'a_{0}=20')
text(1100,7e-4,'a_{0}=40')
title('Problem 4.2.7')
print -deps Fig4-2-7.eps
